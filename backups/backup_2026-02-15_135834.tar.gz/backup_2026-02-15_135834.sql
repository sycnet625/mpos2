-- RESPALDO BASE DE DATOS PALWEB
-- Fecha: 2026-02-15 13:58:34

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `almacenes`;
CREATE TABLE `almacenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sucursal` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `id_sucursal` (`id_sucursal`),
  CONSTRAINT `1` FOREIGN KEY (`id_sucursal`) REFERENCES `sucursales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `almacenes` VALUES ('1', '1', 'almacen de pruebas', '1');
INSERT INTO `almacenes` VALUES ('2', '2', 'insumos roly', '1');
INSERT INTO `almacenes` VALUES ('3', '2', 'terminados roly', '1');
INSERT INTO `almacenes` VALUES ('4', '4', 'Almacén 4 El MArinero', '1');

DROP TABLE IF EXISTS `auditoria_pos`;
CREATE TABLE `auditoria_pos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accion` varchar(50) DEFAULT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  `datos` longtext DEFAULT NULL CHECK (json_valid(`datos`)),
  `fecha` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `auditoria_pos` VALUES ('1', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"1\"}', '2026-01-29 22:53:23');
INSERT INTO `auditoria_pos` VALUES ('2', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"2\"}', '2026-01-29 22:58:20');
INSERT INTO `auditoria_pos` VALUES ('3', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"3\"}', '2026-01-29 23:30:04');
INSERT INTO `auditoria_pos` VALUES ('4', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"4\"}', '2026-01-29 23:34:58');
INSERT INTO `auditoria_pos` VALUES ('5', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"1\"}', '2026-01-29 23:42:59');
INSERT INTO `auditoria_pos` VALUES ('6', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"5\"}', '2026-01-29 23:48:01');
INSERT INTO `auditoria_pos` VALUES ('7', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"2\"}', '2026-01-30 10:55:57');
INSERT INTO `auditoria_pos` VALUES ('8', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"6\",\"fecha\":\"2026-01-02 11:36:03\"}', '2026-01-30 11:36:03');
INSERT INTO `auditoria_pos` VALUES ('9', 'COMPRA_CANCELADA', 'Admin', '{\"id\":4}', '2026-01-31 09:52:34');
INSERT INTO `auditoria_pos` VALUES ('10', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660037\",\"nuevo_stock\":16}', '2026-01-31 10:06:57');
INSERT INTO `auditoria_pos` VALUES ('11', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660023\",\"nuevo_stock\":0}', '2026-01-31 10:07:09');
INSERT INTO `auditoria_pos` VALUES ('12', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"7\"}', '2026-01-31 10:08:03');
INSERT INTO `auditoria_pos` VALUES ('13', 'COMPRA_CANCELADA', 'Admin', '{\"id\":7}', '2026-01-31 10:08:32');
INSERT INTO `auditoria_pos` VALUES ('14', 'COMPRA_CANCELADA', 'Admin', '{\"id\":6}', '2026-01-31 10:09:08');
INSERT INTO `auditoria_pos` VALUES ('15', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"756058841446\",\"nuevo_stock\":0}', '2026-01-31 10:09:38');
INSERT INTO `auditoria_pos` VALUES ('16', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"8\"}', '2026-02-01 08:39:18');
INSERT INTO `auditoria_pos` VALUES ('17', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"9\"}', '2026-02-01 20:38:55');
INSERT INTO `auditoria_pos` VALUES ('18', 'COMPRA_CANCELADA', 'Admin', '{\"id\":8}', '2026-02-01 20:39:04');
INSERT INTO `auditoria_pos` VALUES ('19', 'COMPRA_CANCELADA', 'Admin', '{\"id\":4}', '2026-02-01 21:26:22');
INSERT INTO `auditoria_pos` VALUES ('20', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"10\"}', '2026-02-01 21:37:20');
INSERT INTO `auditoria_pos` VALUES ('21', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"11\"}', '2026-02-02 18:41:43');
INSERT INTO `auditoria_pos` VALUES ('22', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"12\"}', '2026-02-02 18:44:49');
INSERT INTO `auditoria_pos` VALUES ('23', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"3\"}', '2026-02-02 18:45:38');
INSERT INTO `auditoria_pos` VALUES ('24', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"13\"}', '2026-02-02 19:09:47');
INSERT INTO `auditoria_pos` VALUES ('25', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660033\",\"nuevo_stock\":26}', '2026-02-02 19:13:50');
INSERT INTO `auditoria_pos` VALUES ('26', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"4\"}', '2026-02-02 19:16:32');
INSERT INTO `auditoria_pos` VALUES ('27', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660012\",\"nuevo_stock\":12}', '2026-02-02 19:17:07');
INSERT INTO `auditoria_pos` VALUES ('28', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"14\"}', '2026-02-02 19:20:45');
INSERT INTO `auditoria_pos` VALUES ('29', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660012\",\"nuevo_stock\":7}', '2026-02-02 19:39:49');
INSERT INTO `auditoria_pos` VALUES ('30', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660018\",\"nuevo_stock\":2}', '2026-02-02 19:40:46');
INSERT INTO `auditoria_pos` VALUES ('31', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660002\",\"nuevo_stock\":28}', '2026-02-02 19:42:02');
INSERT INTO `auditoria_pos` VALUES ('32', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"5\"}', '2026-02-02 19:42:25');
INSERT INTO `auditoria_pos` VALUES ('33', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660034\",\"nuevo_stock\":127}', '2026-02-02 19:43:22');
INSERT INTO `auditoria_pos` VALUES ('34', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660032\",\"nuevo_stock\":17}', '2026-02-02 19:43:44');
INSERT INTO `auditoria_pos` VALUES ('35', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"660035\",\"nuevo_stock\":21}', '2026-02-02 19:45:12');
INSERT INTO `auditoria_pos` VALUES ('36', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"756058841478\",\"nuevo_stock\":2}', '2026-02-02 19:46:32');
INSERT INTO `auditoria_pos` VALUES ('37', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"15\"}', '2026-02-04 09:55:48');
INSERT INTO `auditoria_pos` VALUES ('38', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"6\"}', '2026-02-04 09:57:03');
INSERT INTO `auditoria_pos` VALUES ('39', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"7\"}', '2026-02-04 09:58:42');
INSERT INTO `auditoria_pos` VALUES ('40', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"8\"}', '2026-02-04 10:00:47');
INSERT INTO `auditoria_pos` VALUES ('41', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"9\"}', '2026-02-04 10:01:18');
INSERT INTO `auditoria_pos` VALUES ('42', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"10\"}', '2026-02-04 10:01:52');
INSERT INTO `auditoria_pos` VALUES ('43', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"11\"}', '2026-02-04 10:02:42');
INSERT INTO `auditoria_pos` VALUES ('44', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"12\"}', '2026-02-04 10:22:30');
INSERT INTO `auditoria_pos` VALUES ('45', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"16\"}', '2026-02-04 10:24:06');
INSERT INTO `auditoria_pos` VALUES ('46', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"17\"}', '2026-02-04 10:51:07');
INSERT INTO `auditoria_pos` VALUES ('47', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"18\"}', '2026-02-04 10:59:41');
INSERT INTO `auditoria_pos` VALUES ('48', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"19\"}', '2026-02-04 11:04:23');
INSERT INTO `auditoria_pos` VALUES ('49', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660016\",\"nuevo_precio\":730}', '2026-02-04 11:09:07');
INSERT INTO `auditoria_pos` VALUES ('50', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660101\",\"nuevo_precio\":40}', '2026-02-04 11:49:45');
INSERT INTO `auditoria_pos` VALUES ('51', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660101\",\"nuevo_precio\":30}', '2026-02-04 11:50:16');
INSERT INTO `auditoria_pos` VALUES ('52', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660101\",\"nuevo_precio\":40}', '2026-02-04 12:37:42');
INSERT INTO `auditoria_pos` VALUES ('53', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660101\",\"nuevo_precio\":35}', '2026-02-04 12:40:00');
INSERT INTO `auditoria_pos` VALUES ('54', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660101\",\"nuevo_precio\":40}', '2026-02-04 12:43:04');
INSERT INTO `auditoria_pos` VALUES ('55', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"20\"}', '2026-02-07 09:48:07');
INSERT INTO `auditoria_pos` VALUES ('56', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"14\"}', '2026-02-07 09:57:23');
INSERT INTO `auditoria_pos` VALUES ('57', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"21\"}', '2026-02-07 11:06:14');
INSERT INTO `auditoria_pos` VALUES ('58', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"22\"}', '2026-02-08 09:07:39');
INSERT INTO `auditoria_pos` VALUES ('59', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"23\"}', '2026-02-08 14:33:49');
INSERT INTO `auditoria_pos` VALUES ('60', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"24\"}', '2026-02-08 19:25:31');
INSERT INTO `auditoria_pos` VALUES ('61', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660014\",\"nuevo_precio\":370}', '2026-02-10 11:55:36');
INSERT INTO `auditoria_pos` VALUES ('62', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"25\"}', '2026-02-10 12:21:55');
INSERT INTO `auditoria_pos` VALUES ('63', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"26\"}', '2026-02-10 12:22:41');
INSERT INTO `auditoria_pos` VALUES ('64', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"27\"}', '2026-02-12 13:02:40');
INSERT INTO `auditoria_pos` VALUES ('65', 'MERMA_REGISTRADA', 'Admin', '{\"id\":\"15\"}', '2026-02-12 13:03:48');
INSERT INTO `auditoria_pos` VALUES ('66', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"28\"}', '2026-02-12 13:06:53');
INSERT INTO `auditoria_pos` VALUES ('67', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"29\"}', '2026-02-12 13:13:46');
INSERT INTO `auditoria_pos` VALUES ('68', 'STOCK_AJUSTE_INLINE', 'Admin', '{\"sku\":\"756058841446\",\"nuevo_stock\":9}', '2026-02-12 13:19:22');
INSERT INTO `auditoria_pos` VALUES ('69', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660021\",\"nuevo_precio\":250}', '2026-02-12 13:19:31');
INSERT INTO `auditoria_pos` VALUES ('70', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660005\",\"nuevo_precio\":150}', '2026-02-12 13:33:57');
INSERT INTO `auditoria_pos` VALUES ('71', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"660010\",\"nuevo_precio\":150}', '2026-02-12 13:57:22');
INSERT INTO `auditoria_pos` VALUES ('72', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"30\"}', '2026-02-12 14:09:11');
INSERT INTO `auditoria_pos` VALUES ('73', 'PRECIO_UPDATE', 'Admin', '{\"sku\":\"440001\",\"nuevo_precio\":140}', '2026-02-12 14:12:32');
INSERT INTO `auditoria_pos` VALUES ('75', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"991118\",\"qty\":1000,\"note\":\"ajuste manual\"}', '2026-02-13 12:40:11');
INSERT INTO `auditoria_pos` VALUES ('76', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"31\"}', '2026-02-15 09:40:12');
INSERT INTO `auditoria_pos` VALUES ('77', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660101\",\"qty\":6,\"note\":\"error anterior\\r\\n\"}', '2026-02-15 12:53:14');
INSERT INTO `auditoria_pos` VALUES ('78', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"32\"}', '2026-02-15 13:25:03');
INSERT INTO `auditoria_pos` VALUES ('79', 'LISTA_COMPRA_GUARDADA', 'Admin', '{\"id\":\"33\"}', '2026-02-15 13:27:54');
INSERT INTO `auditoria_pos` VALUES ('80', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660015\",\"qty\":-1,\"note\":\"error\"}', '2026-02-15 13:34:54');
INSERT INTO `auditoria_pos` VALUES ('81', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660017\",\"qty\":-8,\"note\":\"error\"}', '2026-02-15 13:36:27');
INSERT INTO `auditoria_pos` VALUES ('82', 'COMPRA_REGISTRADA', 'Admin', '{\"id\":\"34\"}', '2026-02-15 13:38:34');
INSERT INTO `auditoria_pos` VALUES ('83', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660012\",\"qty\":-2,\"note\":\"por error de entrada\"}', '2026-02-15 13:40:51');
INSERT INTO `auditoria_pos` VALUES ('84', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660001\",\"qty\":1,\"note\":\"entarda\\r\\n\"}', '2026-02-15 13:51:47');
INSERT INTO `auditoria_pos` VALUES ('85', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660033\",\"qty\":-1,\"note\":\"me lo pago extra.por error\"}', '2026-02-15 13:52:01');
INSERT INTO `auditoria_pos` VALUES ('86', 'STOCK_AJUSTE_KARDEX', 'Admin', '{\"sku\":\"660018\",\"qty\":-1,\"note\":\"la pago extra\"}', '2026-02-15 13:53:05');

DROP TABLE IF EXISTS `caja_sesiones`;
CREATE TABLE `caja_sesiones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `nombre_cajero` varchar(100) DEFAULT NULL,
  `fecha_apertura` datetime DEFAULT current_timestamp(),
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_inicial` decimal(10,2) DEFAULT 0.00,
  `monto_final_sistema` decimal(10,2) DEFAULT 0.00,
  `monto_final_real` decimal(10,2) DEFAULT 0.00,
  `diferencia` decimal(10,2) DEFAULT 0.00,
  `estado` varchar(20) DEFAULT 'ABIERTA',
  `fecha_contable` date DEFAULT curdate(),
  `id_sucursal` int(11) DEFAULT 1,
  `nota` text DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `caja_sesiones` VALUES ('1', NULL, 'Eddy', '2026-01-29 22:48:21', '2026-01-29 23:00:49', '0.00', '7290.00', '7290.00', '0.00', 'CERRADA', '2026-01-23', '4', 'realmente 2360 en tranf');
INSERT INTO `caja_sesiones` VALUES ('2', NULL, 'Eddy', '2026-01-29 23:01:12', '2026-01-29 23:12:12', '0.00', '8745.00', '8745.00', '0.00', 'CERRADA', '2026-01-24', '4', 'real fue 60 en tranfe');
INSERT INTO `caja_sesiones` VALUES ('3', NULL, 'Admin', '2026-01-29 23:13:03', '2026-01-29 23:26:58', '0.00', '14235.00', '13515.00', '-720.00', 'CERRADA', '2026-01-25', '4', 'faltan 720 de 3 marranetas');
INSERT INTO `caja_sesiones` VALUES ('4', NULL, 'Admin', '2026-01-29 23:27:13', '2026-01-29 23:31:59', '0.00', '5310.00', '5310.00', '0.00', 'CERRADA', '2026-01-26', '4', 'ok');
INSERT INTO `caja_sesiones` VALUES ('5', NULL, 'Eddy', '2026-01-29 23:38:30', '2026-01-29 23:44:07', '0.00', '6115.00', '6115.00', '0.00', 'CERRADA', '2026-01-27', '4', 'por traf 1280');
INSERT INTO `caja_sesiones` VALUES ('6', NULL, 'Eddy', '2026-01-29 23:48:36', '2026-01-29 23:54:16', '0.00', '6655.00', '6655.00', '0.00', 'CERRADA', '2026-01-28', '4', '990 por tranf');
INSERT INTO `caja_sesiones` VALUES ('7', NULL, 'Eddy', '2026-01-30 08:40:43', '2026-01-30 09:21:19', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-01-29', '4', 'test');
INSERT INTO `caja_sesiones` VALUES ('8', NULL, 'Eddy', '2026-01-30 09:22:13', '2026-01-30 09:30:40', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-01-11', '4', 'test');
INSERT INTO `caja_sesiones` VALUES ('9', NULL, 'Eddy', '2026-01-30 10:23:27', '2026-01-30 10:59:19', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-01-12', '4', 'prueba roly');
INSERT INTO `caja_sesiones` VALUES ('10', NULL, 'Admin', '2026-01-30 13:24:53', '2026-01-31 08:23:01', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-01-02', '4', 'Test');
INSERT INTO `caja_sesiones` VALUES ('11', NULL, 'Eddy', '2026-01-31 08:23:10', '2026-01-31 09:06:03', '0.00', '12940.00', '12940.00', '0.00', 'CERRADA', '2026-01-29', '4', 'Ok');
INSERT INTO `caja_sesiones` VALUES ('12', NULL, 'Admin', '2026-02-01 20:29:30', '2026-02-01 21:42:46', '0.00', '17705.00', '17705.00', '0.00', 'CERRADA', '2026-01-30', '4', '');
INSERT INTO `caja_sesiones` VALUES ('13', NULL, 'Eddy', '2026-02-02 18:59:55', '2026-02-02 19:35:39', '0.00', '15770.00', '15770.00', '0.00', 'CERRADA', '2026-01-31', '4', 'reportado 13130 faltaron 2640');
INSERT INTO `caja_sesiones` VALUES ('14', NULL, 'Eddy', '2026-02-04 08:26:03', '2026-02-04 08:41:54', '0.00', '11180.00', '11180.00', '0.00', 'CERRADA', '2026-02-01', '4', 'ok');
INSERT INTO `caja_sesiones` VALUES ('15', NULL, 'Eddy', '2026-02-04 08:42:11', '2026-02-04 09:40:48', '0.00', '5440.00', '5440.00', '0.00', 'CERRADA', '2026-02-02', '4', '0');
INSERT INTO `caja_sesiones` VALUES ('16', NULL, 'Eddy', '2026-02-04 10:28:14', '2026-02-04 11:21:50', '0.00', '3980.00', '3990.00', '10.00', 'CERRADA', '2026-02-03', '4', 'puse higado a 720 y es a 730 por eso la diferencia de 10');
INSERT INTO `caja_sesiones` VALUES ('17', NULL, 'Eddy', '2026-02-06 10:21:00', '2026-02-07 10:01:08', '0.00', '18330.00', '18330.00', '0.00', 'CERRADA', '2026-02-04', '4', 'aqui se habian puesto en papel marranetas de mas y se rebajo 2880 en efectivo');
INSERT INTO `caja_sesiones` VALUES ('18', NULL, 'Eddy', '2026-02-07 10:18:21', '2026-02-07 13:48:24', '0.00', '9080.00', '9080.00', '0.00', 'CERRADA', '2026-02-05', '4', '-40 con el reaL');
INSERT INTO `caja_sesiones` VALUES ('19', NULL, 'Eddy', '2026-02-08 09:01:47', '2026-02-08 14:46:37', '0.00', '15580.00', '15590.00', '10.00', 'CERRADA', '2026-02-06', '4', 'no se de que 10 pesos sobran en cash');
INSERT INTO `caja_sesiones` VALUES ('20', NULL, 'Eddy', '2026-02-08 14:47:56', '2026-02-10 12:08:09', '0.00', '21120.00', '21060.00', '-60.00', 'CERRADA', '2026-02-07', '4', 'Le faltan 100 cup al marinero de shekels mal calculadas');
INSERT INTO `caja_sesiones` VALUES ('21', NULL, 'Eddy', '2026-02-10 12:09:07', '2026-02-12 13:29:36', '0.00', '11450.00', '11680.00', '230.00', 'CERRADA', '2026-02-08', '4', 'sobra 1 fria');
INSERT INTO `caja_sesiones` VALUES ('22', '4', 'Admin', '2026-02-11 09:33:48', '2026-02-11 09:34:37', '0.00', '300.00', '300.00', '0.00', 'CERRADA', '2026-02-11', '4', 'ok');
INSERT INTO `caja_sesiones` VALUES ('23', '1', 'Eddy', '2026-02-11 14:25:40', '2026-02-12 11:39:19', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-02-11', '4', '');
INSERT INTO `caja_sesiones` VALUES ('24', NULL, 'Eddy', '2026-02-12 13:29:46', '2026-02-12 14:00:18', '0.00', '6845.00', '6845.00', '0.00', 'CERRADA', '2026-02-09', '4', '');
INSERT INTO `caja_sesiones` VALUES ('25', NULL, 'Eddy', '2026-02-12 14:05:29', '2026-02-12 14:20:59', '0.00', '8380.00', '8380.00', '0.00', 'CERRADA', '2026-02-10', '4', '');
INSERT INTO `caja_sesiones` VALUES ('26', NULL, 'Eddy', '2026-02-12 20:04:02', '2026-02-15 12:56:26', '0.00', '0.00', '8965.00', '8965.00', 'CERRADA', '2026-02-11', '4', 'yo tengo 20 d emas por encima del marinero que tiene 12145');
INSERT INTO `caja_sesiones` VALUES ('27', '4', 'admin', '2026-02-12 20:31:25', '2026-02-12 21:00:19', '0.00', '0.00', '0.00', '0.00', 'CERRADA', '2026-02-28', '4', '');
INSERT INTO `caja_sesiones` VALUES ('28', NULL, 'Eddy', '2026-02-15 13:02:59', '2026-02-15 13:41:35', '0.00', '0.00', '7005.00', '7005.00', 'CERRADA', '2026-02-12', '4', 'le di 3200 a oscar para comprar');
INSERT INTO `caja_sesiones` VALUES ('29', NULL, 'Eddy', '2026-02-15 13:50:29', NULL, '0.00', '0.00', '0.00', '0.00', 'ABIERTA', '2026-02-13', '4', 'no');

DROP TABLE IF EXISTS `carritos_abandonados`;
CREATE TABLE `carritos_abandonados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) DEFAULT NULL,
  `items_json` text DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `ultima_actividad` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `categorias`;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `emoji` varchar(10) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categorias` VALUES ('1', 'Hamburguesas', '🍔', '#FFF9C4');
INSERT INTO `categorias` VALUES ('2', 'Pizzas', '🍕', '#F8BBD0');
INSERT INTO `categorias` VALUES ('3', 'Ensaladas', '🥗', '#C8E6C9');
INSERT INTO `categorias` VALUES ('4', 'Sushi', '🍣', '#B3E5FC');
INSERT INTO `categorias` VALUES ('5', 'Tacos', '🌮', '#FFCCBC');
INSERT INTO `categorias` VALUES ('6', 'Sopas', '🍜', '#D1C4E9');
INSERT INTO `categorias` VALUES ('8', 'Pollo', '🍗', '#F0F4C3');
INSERT INTO `categorias` VALUES ('9', 'Sandwiches', '🥪', '#FFE0B2');
INSERT INTO `categorias` VALUES ('10', 'Desayunos', '🍳', '#E1BEE7');
INSERT INTO `categorias` VALUES ('11', 'Postres', '🍰', '#DCEDC8');
INSERT INTO `categorias` VALUES ('12', 'Helados', '🍦', '#FFECB3');
INSERT INTO `categorias` VALUES ('13', 'Donas', '🍩', '#D0F0C0');
INSERT INTO `categorias` VALUES ('14', 'Frutas', '🍎', '#E0F7FA');
INSERT INTO `categorias` VALUES ('15', 'BEBIDAS', '🥤', '#f5f5dc');
INSERT INTO `categorias` VALUES ('16', 'Café', '☕', '#FFF0F5');
INSERT INTO `categorias` VALUES ('17', 'Cervezas', '🍺', '#FAFAD2');
INSERT INTO `categorias` VALUES ('18', 'Cocteles', '🍹', '#E6E6FA');
INSERT INTO `categorias` VALUES ('19', 'Snacks', '🍿', '#FFF5EE');
INSERT INTO `categorias` VALUES ('20', 'Panadería', '🥨', '#F0FFFF');
INSERT INTO `categorias` VALUES ('21', 'DULCES', '🍭', '#FFECB3');
INSERT INTO `categorias` VALUES ('22', 'CONFITURAS', '🍬', '#F8BBD0');
INSERT INTO `categorias` VALUES ('23', 'BODEGON', '🍷', '#D1C4E9');
INSERT INTO `categorias` VALUES ('24', 'BEBIDAS_A', '🍸', '#E1BEE7');
INSERT INTO `categorias` VALUES ('25', 'CARNICOS', '🥩', '#FFCCBC');
INSERT INTO `categorias` VALUES ('26', 'Pruebas', '🧪', '#F5F5DC');
INSERT INTO `categorias` VALUES ('27', 'INSUMOS', '📦', '#CFD8DC');
INSERT INTO `categorias` VALUES ('28', 'CONGELADOS', '🧊', '#E0F7FA');

DROP TABLE IF EXISTS `chat_messages`;
CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_uuid` varchar(50) NOT NULL,
  `sender` enum('client','admin') NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_client` (`client_uuid`),
  KEY `idx_read` (`is_read`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `chat_messages` VALUES ('1', 'cli_8j69zmenk', 'client', 'hola, les queda mas aceite', '1', '2026-02-04 14:35:33');
INSERT INTO `chat_messages` VALUES ('2', 'cli_8j69zmenk', 'client', 'hola', '1', '2026-02-04 14:39:52');
INSERT INTO `chat_messages` VALUES ('3', 'cli_8j69zmenk', 'admin', 'siii', '0', '2026-02-04 14:45:27');
INSERT INTO `chat_messages` VALUES ('4', 'cli_8j69zmenk', 'client', 'cuanto le queda', '1', '2026-02-04 14:55:30');
INSERT INTO `chat_messages` VALUES ('5', 'cli_8j69zmenk', 'admin', 'me quedan 22', '0', '2026-02-04 14:55:45');
INSERT INTO `chat_messages` VALUES ('6', 'cli_8j69zmenk', 'client', 'les quedan cake d ebombon', '1', '2026-02-04 15:32:27');
INSERT INTO `chat_messages` VALUES ('7', 'cli_8j69zmenk', 'admin', 'si de bpmbon tengo 2', '0', '2026-02-04 15:36:08');
INSERT INTO `chat_messages` VALUES ('8', 'cli_8j69zmenk', 'client', 'ok, gracias', '1', '2026-02-04 15:36:33');
INSERT INTO `chat_messages` VALUES ('9', 'cli_f6qf5h3p5', 'client', 'hola tiene cakes de bombon', '1', '2026-02-05 11:45:51');
INSERT INTO `chat_messages` VALUES ('10', 'cli_f6qf5h3p5', 'admin', 'si tengo cuantos quiere', '0', '2026-02-05 11:46:10');
INSERT INTO `chat_messages` VALUES ('11', 'cli_f6qf5h3p5', 'client', 'quiero 1', '1', '2026-02-05 11:46:17');
INSERT INTO `chat_messages` VALUES ('12', 'cli_f6qf5h3p5', 'admin', 'listo ya s elo envie', '0', '2026-02-05 11:46:25');
INSERT INTO `chat_messages` VALUES ('13', 'cli_8j69zmenk', 'client', 'tienen aceite hoy?', '1', '2026-02-11 13:42:42');
INSERT INTO `chat_messages` VALUES ('14', 'cli_w9xb36o39', 'client', 'Hola', '1', '2026-02-11 13:43:11');
INSERT INTO `chat_messages` VALUES ('15', 'cli_w9xb36o39', 'client', 'Tienen cake', '1', '2026-02-11 13:43:15');
INSERT INTO `chat_messages` VALUES ('16', 'cli_8j69zmenk', 'admin', 'Si', '0', '2026-02-11 17:48:10');
INSERT INTO `chat_messages` VALUES ('17', 'cli_w9xb36o39', 'admin', 'Si', '0', '2026-02-11 17:48:17');
INSERT INTO `chat_messages` VALUES ('18', 'cli_2cq785o6z', 'client', 'les quedan croquetas?', '1', '2026-02-13 20:55:43');
INSERT INTO `chat_messages` VALUES ('19', 'cli_2cq785o6z', 'admin', 'Si tenemos', '0', '2026-02-14 10:28:07');

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `uuid` char(36) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `categoria` enum('Regular','VIP','Corporativo','Moroso','Empleado') DEFAULT 'Regular',
  `origen` varchar(50) DEFAULT 'Local',
  `notas` text DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `nit_ci` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `es_mensajero` tinyint(1) DEFAULT 0,
  `vehiculo` varchar(50) DEFAULT NULL,
  `matricula` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clientes` VALUES ('1', 'sureima chales', '7868082963', '522 East 12th Street', '1', NULL, '2026-02-10 10:27:22', 'VIP', 'Facebook', '', '2026-01-31', '71010102929', 'sycnet.2013@gmail.com', '0', NULL, NULL);
INSERT INTO `clientes` VALUES ('2', 'Oscar escobar', '56078943', 'czda del cerro #1024', '1', NULL, '2026-02-10 10:42:53', 'Empleado', 'Local', '', '2026-01-26', '68020212312', '', '1', 'Triciclo', 'P84739');

DROP TABLE IF EXISTS `clientes_tienda`;
CREATE TABLE `clientes_tienda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `direccion` text DEFAULT NULL,
  `municipio` varchar(50) DEFAULT NULL,
  `barrio` varchar(50) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `ultima_sesion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telefono` (`telefono`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `clientes_tienda` VALUES ('1', 'Sureima Chales Proenza', '17868082963', NULL, '$2y$10$td8g98J9PzIyVnzj.K3SBOWthtVj.AbvyNfbY/SqziyTGUT7TZOXi', 'parque 258 / bella vista y canal', NULL, NULL, '2026-02-13 17:56:38', NULL);
INSERT INTO `clientes_tienda` VALUES ('2', 'ingry torres', '53348756', NULL, '$2y$10$HaDq3f6ajy9iZjCM1jJOIO6ZooNpNfrrXtBHmiP0nrGYj3sarci4K', 'magnolia 258 - parque y bella vista', NULL, NULL, '2026-02-13 21:36:41', NULL);

DROP TABLE IF EXISTS `comandas`;
CREATE TABLE `comandas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta` int(11) DEFAULT NULL,
  `items_json` longtext DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'pendiente',
  `tipo_servicio` varchar(30) DEFAULT NULL,
  `cliente_nombre` varchar(200) DEFAULT NULL,
  `id_mesa` int(10) unsigned DEFAULT NULL,
  `curso` int(11) DEFAULT 1,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comandas` VALUES ('1', '26', '[{\"qty\":10,\"name\":\"Marquesita\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-01-31 09:02:12', '2026-02-15 09:17:13', '2026-02-15 09:17:13');
INSERT INTO `comandas` VALUES ('2', '29', '[{\"qty\":1,\"name\":\"Cake 2900\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-01 20:54:53', '2026-02-15 09:17:14', '2026-02-15 09:17:14');
INSERT INTO `comandas` VALUES ('3', '31', '[{\"qty\":3,\"name\":\"Marquesita\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-01 21:33:07', '2026-02-15 09:17:15', '2026-02-15 09:17:15');
INSERT INTO `comandas` VALUES ('4', '32', '[{\"qty\":3,\"name\":\"Cupcakes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-01 21:35:17', '2026-02-15 09:17:53', '2026-02-15 09:17:53');
INSERT INTO `comandas` VALUES ('5', '33', '[{\"qty\":1,\"name\":\"Bolsa de 8 panes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-01 21:38:39', '2026-02-15 09:17:26', '2026-02-15 09:17:26');
INSERT INTO `comandas` VALUES ('6', '35', '[{\"qty\":3,\"name\":\"Bolsa de 8 panes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-02 19:12:03', '2026-02-15 09:17:27', '2026-02-15 09:17:27');
INSERT INTO `comandas` VALUES ('7', '36', '[{\"qty\":4,\"name\":\"Panque de chocolate\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-02 19:12:19', '2026-02-15 09:17:28', '2026-02-15 09:17:28');
INSERT INTO `comandas` VALUES ('8', '37', '[{\"qty\":2,\"name\":\"Marquesita\",\"note\":\"\"},{\"qty\":11,\"name\":\"Cerveza Presidente\",\"note\":\"\"},{\"qty\":2,\"name\":\"Cupcakes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-02 19:25:32', '2026-02-15 09:17:29', '2026-02-15 09:17:29');
INSERT INTO `comandas` VALUES ('9', '39', '[{\"qty\":4,\"name\":\"Cerveza Presidente\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-04 08:26:07', '2026-02-15 09:17:30', '2026-02-15 09:17:30');
INSERT INTO `comandas` VALUES ('10', '40', '[{\"qty\":1,\"name\":\"Marquesita\",\"note\":\"\"},{\"qty\":2,\"name\":\"Cupcakes\",\"note\":\"\"},{\"qty\":2,\"name\":\"Gacenigas mini\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-04 08:40:54', '2026-02-15 09:17:31', '2026-02-15 09:17:31');
INSERT INTO `comandas` VALUES ('11', '41', '[{\"qty\":1,\"name\":\"Pqt de 4 panques\",\"note\":\"\"},{\"qty\":1,\"name\":\"pqt torticas 6u\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-04 09:40:34', '2026-02-15 09:17:32', '2026-02-15 09:17:32');
INSERT INTO `comandas` VALUES ('12', '73', '[{\"qty\":8,\"name\":\"Cerveza Presidente\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-06 16:02:51', '2026-02-15 09:17:33', '2026-02-15 09:17:34');
INSERT INTO `comandas` VALUES ('13', '89', '[{\"qty\":1,\"name\":\"Pqt de 4 panques\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:49:29', '2026-02-15 09:17:34', '2026-02-15 09:17:35');
INSERT INTO `comandas` VALUES ('14', '91', '[{\"qty\":1,\"name\":\"lomo en bandeja 1lb\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:50:14', '2026-02-15 09:17:36', '2026-02-15 09:17:36');
INSERT INTO `comandas` VALUES ('15', '92', '[{\"qty\":2,\"name\":\"Caldo de pollo sobrecito\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:50:38', '2026-02-15 09:17:37', '2026-02-15 09:17:37');
INSERT INTO `comandas` VALUES ('16', '93', '[{\"qty\":2,\"name\":\"pastillita pollo con tomate\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:50:49', '2026-02-15 09:17:38', '2026-02-15 09:17:38');
INSERT INTO `comandas` VALUES ('17', '94', '[{\"qty\":3,\"name\":\"Galletas Saltitacos\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:58:21', '2026-02-15 09:17:39', '2026-02-15 09:17:39');
INSERT INTO `comandas` VALUES ('18', '95', '[{\"qty\":3,\"name\":\"ojitos gummy gum\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:58:59', '2026-02-15 09:17:40', '2026-02-15 09:17:41');
INSERT INTO `comandas` VALUES ('19', '97', '[{\"qty\":1,\"name\":\"Jabon de carbon\",\"note\":\"\"},{\"qty\":1,\"name\":\"jabon de bano\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 09:59:26', '2026-02-15 09:17:41', '2026-02-15 09:17:42');
INSERT INTO `comandas` VALUES ('20', '101', '[{\"qty\":1,\"name\":\"Cerveza Presidente\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 10:20:45', '2026-02-15 09:17:42', '2026-02-15 09:17:43');
INSERT INTO `comandas` VALUES ('21', '106', '[{\"qty\":1,\"name\":\"Caldo de pollo sobrecito\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 10:29:32', '2026-02-15 09:17:44', '2026-02-15 09:17:44');
INSERT INTO `comandas` VALUES ('22', '107', '[{\"qty\":1,\"name\":\"Galletas Saltitacos\",\"note\":\"\"},{\"qty\":1,\"name\":\"jabon de bano\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 11:11:52', '2026-02-15 09:17:44', '2026-02-15 09:17:45');
INSERT INTO `comandas` VALUES ('23', '108', '[{\"qty\":8,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-07 11:12:27', '2026-02-15 09:17:46', '2026-02-15 09:17:46');
INSERT INTO `comandas` VALUES ('24', '109', '[{\"qty\":3,\"name\":\"ojitos gummy gum\",\"note\":\"\"},{\"qty\":1,\"name\":\"lomo en bandeja 1lb\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-08 09:03:42', '2026-02-15 09:17:47', '2026-02-15 09:17:47');
INSERT INTO `comandas` VALUES ('25', '118', '[{\"qty\":3,\"name\":\"Galletas Saltitacos\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-08 10:13:53', '2026-02-15 09:17:48', '2026-02-15 09:17:48');
INSERT INTO `comandas` VALUES ('26', '119', '[{\"qty\":1,\"name\":\"Donas Donuts\",\"note\":\"\"},{\"qty\":4,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-08 10:15:45', '2026-02-15 09:17:49', '2026-02-15 09:17:49');
INSERT INTO `comandas` VALUES ('27', '123', '[{\"qty\":1,\"name\":\"pqt torticas 6u\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-08 20:01:26', '2026-02-15 09:17:51', '2026-02-15 09:17:51');
INSERT INTO `comandas` VALUES ('28', '131', '[{\"qty\":1,\"name\":\"pqt torticas 6u\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-10 11:47:51', '2026-02-15 09:17:51', '2026-02-15 09:17:52');
INSERT INTO `comandas` VALUES ('29', '134', '[{\"qty\":1,\"name\":\"pqt torticas 6u\",\"note\":\"\"},{\"qty\":1,\"name\":\"jabon de bano\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-10 12:14:14', '2026-02-15 09:17:05', '2026-02-15 09:17:05');
INSERT INTO `comandas` VALUES ('30', '135', '[{\"qty\":1,\"name\":\"Hamburguesas pollo\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-10 12:15:38', '2026-02-15 09:17:06', '2026-02-15 09:17:06');
INSERT INTO `comandas` VALUES ('31', '137', '[{\"qty\":1,\"name\":\"Hamburguesas pollo\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-10 12:25:05', '2026-02-15 09:17:08', '2026-02-15 09:17:08');
INSERT INTO `comandas` VALUES ('32', '138', '[{\"qty\":2,\"name\":\"COCA COLA GRANDE\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-11 09:34:10', '2026-02-15 09:17:09', '2026-02-15 09:17:09');
INSERT INTO `comandas` VALUES ('33', '139', '[{\"qty\":1,\"name\":\"COCA COLA GRANDE\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-11 14:26:29', '2026-02-15 09:17:00', '2026-02-15 09:17:00');
INSERT INTO `comandas` VALUES ('34', '140', '[{\"qty\":1,\"name\":\"COCA COLA GRANDE\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-11 17:57:10', '2026-02-15 09:17:01', '2026-02-15 09:17:02');
INSERT INTO `comandas` VALUES ('35', '154', '[{\"qty\":1,\"name\":\"Cafe en sobre\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 13:26:07', '2026-02-15 09:17:03', '2026-02-15 09:17:03');
INSERT INTO `comandas` VALUES ('36', '156', '[{\"qty\":2,\"name\":\"pqt torticas 6u\",\"note\":\"\"},{\"qty\":3,\"name\":\"jabon de bano\",\"note\":\"\"},{\"qty\":3,\"name\":\"Donas Donuts\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 13:55:05', '2026-02-15 09:17:04', '2026-02-15 09:17:04');
INSERT INTO `comandas` VALUES ('37', '160', '[{\"qty\":2,\"name\":\"pastillita pollo con tomate\",\"note\":\"\"},{\"qty\":1,\"name\":\"Cerveza star lager\",\"note\":\"\"},{\"qty\":5,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 14:12:49', '2026-02-15 09:16:52', '2026-02-15 09:16:58');
INSERT INTO `comandas` VALUES ('38', '161', '[{\"qty\":5,\"name\":\"Cerveza star lager\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 14:13:55', '2026-02-15 09:16:53', '2026-02-15 09:16:56');
INSERT INTO `comandas` VALUES ('39', '162', '[{\"qty\":1,\"name\":\"lomo en bandeja 1lb\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 14:15:23', '2026-02-15 09:16:54', '2026-02-15 09:16:54');
INSERT INTO `comandas` VALUES ('40', '163', '[{\"qty\":1,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 14:17:02', '2026-02-15 09:16:57', '2026-02-15 09:16:57');
INSERT INTO `comandas` VALUES ('41', '180', '[{\"qty\":9,\"name\":\"Cerveza star lager\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 20:06:16', '2026-02-15 09:16:51', '2026-02-15 09:17:56');
INSERT INTO `comandas` VALUES ('42', '181', '[{\"qty\":1,\"name\":\"Cerveza star lager\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-12 20:10:52', '2026-02-15 09:16:51', '2026-02-15 09:17:57');
INSERT INTO `comandas` VALUES ('43', '183', '[{\"qty\":1,\"name\":\"Cafe en sobre\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-13 00:28:11', '2026-02-15 09:16:50', '2026-02-15 09:17:59');
INSERT INTO `comandas` VALUES ('44', '185', '[{\"qty\":1,\"name\":\"Cafe en sobre\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-13 02:00:36', '2026-02-15 09:16:50', '2026-02-15 09:17:59');
INSERT INTO `comandas` VALUES ('45', '187', '[{\"qty\":1,\"name\":\"Cafe en sobre\",\"note\":\"\"},{\"qty\":3,\"name\":\"ojitos gummy gum\",\"note\":\"\"},{\"qty\":1,\"name\":\"jabon de bano\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '1', '2026-02-11 09:26:53', '2026-02-15 10:15:08', '2026-02-15 11:19:55');
INSERT INTO `comandas` VALUES ('46', '188', '[{\"qty\":1,\"name\":\"Hamburguesas pollo\",\"note\":\"\"}]', 'terminado', '5', 'pepe', '5', '0', '2026-02-11 09:29:48', '2026-02-15 10:15:10', '2026-02-15 10:15:11');
INSERT INTO `comandas` VALUES ('47', '191', '[{\"qty\":9,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'entregado', NULL, NULL, NULL, '0', '2026-02-11 09:35:34', '2026-02-15 11:19:51', '2026-02-15 11:19:51');
INSERT INTO `comandas` VALUES ('48', '195', '[{\"qty\":8,\"name\":\"Cerveza star lager\",\"note\":\"\"},{\"qty\":2,\"name\":\"Caldo de pollo sobrecito\",\"note\":\"\"},{\"qty\":2,\"name\":\"ojitos gummy gum\",\"note\":\"\"},{\"qty\":1,\"name\":\"jabon de bano\",\"note\":\"\"}]', 'pendiente', NULL, NULL, NULL, '1', '2026-02-12 13:12:42', NULL, NULL);
INSERT INTO `comandas` VALUES ('49', '196', '[{\"qty\":1,\"name\":\"minicake 2000\",\"note\":\"\"},{\"qty\":1,\"name\":\"Donas Grandes\",\"note\":\"\"}]', 'pendiente', NULL, NULL, NULL, '1', '2026-02-12 13:39:43', NULL, NULL);

DROP TABLE IF EXISTS `compras_cabecera`;
CREATE TABLE `compras_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT current_timestamp(),
  `proveedor` varchar(100) DEFAULT NULL,
  `total` decimal(12,2) DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'finalizado',
  `numero_factura` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `compras_cabecera` VALUES ('1', '2026-01-29 22:53:23', 'adrian', '8160.00', 'Admin', ' [Suc:4 Alm:4]', 'finalizado', NULL);
INSERT INTO `compras_cabecera` VALUES ('2', '2026-01-29 22:58:19', '', '292.71', 'Admin', ' [Suc:4 Alm:4]', 'finalizado', NULL);
INSERT INTO `compras_cabecera` VALUES ('3', '2026-01-29 23:30:04', 'roly ce', '1594.00', 'Admin', 'dia 26/ene [Suc:4 Alm:4]', 'finalizado', NULL);
INSERT INTO `compras_cabecera` VALUES ('4', '2026-01-29 23:34:58', 'adrian', '22517.00', 'Admin', 'dia 27 [Suc:4 Alm:4]', 'CANCELADA', 'f43322');
INSERT INTO `compras_cabecera` VALUES ('5', '2026-01-29 23:48:01', 'roly ce', '6140.00', 'Admin', 'dia 28 [Suc:4 Alm:4]', 'finalizado', NULL);
INSERT INTO `compras_cabecera` VALUES ('6', '2026-01-02 11:36:03', 'pepe', '240.00', 'Admin', 'no [Suc:4 Alm:4]', 'CANCELADA', 'f64435');
INSERT INTO `compras_cabecera` VALUES ('7', '2026-01-31 10:08:03', '', '240.00', 'Admin', ' [Suc:4 Alm:4]', 'CANCELADA', '');
INSERT INTO `compras_cabecera` VALUES ('8', '2026-02-01 08:39:18', '', '230000.00', 'Admin', ' [Suc:4 Alm:4]', 'CANCELADA', '');
INSERT INTO `compras_cabecera` VALUES ('9', '2026-02-02 20:38:55', '', '3568.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('10', '2026-01-30 21:37:20', 'por error', '6050.00', 'Admin', 'rectificando faltantes [Suc:4 Alm:4]', 'PROCESADA', 'f000');
INSERT INTO `compras_cabecera` VALUES ('11', '2026-02-02 18:41:43', '', '7494.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('12', '2026-02-02 18:44:49', 'roly', '480.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('13', '2026-02-03 19:09:47', '', '13906.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('14', '2026-01-31 19:20:45', '', '640.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('15', '2026-02-04 09:55:48', '', '405.00', 'Admin', 'por error [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('16', '2026-02-04 10:24:06', '', '50.00', 'Admin', 'error [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('17', '2026-02-03 10:51:07', 'roly', '10521.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('18', '2026-02-03 10:59:41', 'roly', '4410.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('19', '2026-02-03 11:04:23', 'roly', '1200.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('20', '2026-02-04 09:48:07', 'adrian', '6384.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('21', '2026-02-05 11:06:14', 'roly', '2010.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('22', '2026-02-06 09:07:39', 'roly', '16248.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('23', '2026-02-06 14:33:49', '', '45.00', 'Admin', 'por error [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('24', '2026-02-07 19:25:31', 'roly', '1950.13', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('25', '2026-02-08 12:21:55', '', '10320.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('26', '2026-02-08 12:22:41', '', '820.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('27', '2026-02-08 13:02:40', '', '480.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('28', '2026-02-08 13:06:53', '', '900.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('29', '2026-02-08 13:13:46', '', '440.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('30', '2026-02-10 14:09:11', '', '8750.00', 'Admin', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('31', '2026-02-11 09:40:12', 'roly', '2080.00', '4', ' [Suc:4 Alm:4]', 'PROCESADA', 'f122');
INSERT INTO `compras_cabecera` VALUES ('32', '2026-02-12 13:25:02', 'roly', '8726.00', '4', ' [Suc:4 Alm:4]', 'PROCESADA', '');
INSERT INTO `compras_cabecera` VALUES ('33', '2026-02-13 13:27:54', 'roly', '27512.00', '4', ' [Suc:4 Alm:4]', 'PENDIENTE', '');
INSERT INTO `compras_cabecera` VALUES ('34', '2026-02-12 13:38:34', '', '2300.00', '4', ' [Suc:4 Alm:4]', 'PROCESADA', '');

DROP TABLE IF EXISTS `compras_detalle`;
CREATE TABLE `compras_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_compra` int(11) DEFAULT NULL,
  `id_producto` varchar(50) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `costo_unitario` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(12,2) DEFAULT NULL,
  `costo_anterior` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `compras_detalle` VALUES ('1', '1', '660011', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('2', '1', '660005', '24.00', '130.00', '3120.00', NULL);
INSERT INTO `compras_detalle` VALUES ('3', '2', '881108', '1.00', '292.71', '292.71', NULL);
INSERT INTO `compras_detalle` VALUES ('4', '3', '660017', '2.00', '72.00', '144.00', NULL);
INSERT INTO `compras_detalle` VALUES ('5', '3', '660012', '29.00', '50.00', '1450.00', NULL);
INSERT INTO `compras_detalle` VALUES ('6', '4', '660026', '2.00', '430.00', '860.00', NULL);
INSERT INTO `compras_detalle` VALUES ('7', '4', '660012', '22.00', '50.00', '1100.00', NULL);
INSERT INTO `compras_detalle` VALUES ('8', '4', '660023', '24.00', '213.00', '5112.00', NULL);
INSERT INTO `compras_detalle` VALUES ('9', '4', '660037', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('10', '4', '660032', '24.00', '190.00', '4560.00', NULL);
INSERT INTO `compras_detalle` VALUES ('11', '4', '660036', '27.00', '135.00', '3645.00', NULL);
INSERT INTO `compras_detalle` VALUES ('12', '4', '660033', '32.00', '20.00', '640.00', NULL);
INSERT INTO `compras_detalle` VALUES ('13', '4', '660035', '32.00', '15.00', '480.00', NULL);
INSERT INTO `compras_detalle` VALUES ('14', '4', '660034', '180.00', '6.00', '1080.00', NULL);
INSERT INTO `compras_detalle` VALUES ('15', '5', '660012', '26.00', '50.00', '1300.00', NULL);
INSERT INTO `compras_detalle` VALUES ('16', '5', '660099', '16.00', '65.00', '1040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('17', '5', '660015', '9.00', '300.00', '2700.00', NULL);
INSERT INTO `compras_detalle` VALUES ('18', '5', '660014', '5.00', '220.00', '1100.00', NULL);
INSERT INTO `compras_detalle` VALUES ('19', '6', '756058841446', '2.00', '120.00', '240.00', NULL);
INSERT INTO `compras_detalle` VALUES ('20', '7', '756058841446', '2.00', '120.00', '240.00', NULL);
INSERT INTO `compras_detalle` VALUES ('21', '8', '756058841480', '2300.00', '100.00', '230000.00', NULL);
INSERT INTO `compras_detalle` VALUES ('22', '9', '660010', '4.00', '130.00', '520.00', NULL);
INSERT INTO `compras_detalle` VALUES ('23', '9', '660009', '6.00', '120.00', '720.00', NULL);
INSERT INTO `compras_detalle` VALUES ('24', '9', '660017', '9.00', '72.00', '648.00', NULL);
INSERT INTO `compras_detalle` VALUES ('25', '9', '756058841478', '7.00', '40.00', '280.00', NULL);
INSERT INTO `compras_detalle` VALUES ('26', '9', '660098', '1.00', '0.00', '0.00', NULL);
INSERT INTO `compras_detalle` VALUES ('27', '9', '660043', '2.00', '700.00', '1400.00', NULL);
INSERT INTO `compras_detalle` VALUES ('28', '10', '660037', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('29', '10', '660097', '4.00', '160.00', '640.00', NULL);
INSERT INTO `compras_detalle` VALUES ('30', '10', '660004', '1.00', '370.00', '370.00', NULL);
INSERT INTO `compras_detalle` VALUES ('31', '11', '660043', '1.00', '700.00', '700.00', NULL);
INSERT INTO `compras_detalle` VALUES ('32', '11', '660012', '20.00', '50.00', '1000.00', NULL);
INSERT INTO `compras_detalle` VALUES ('33', '11', '660017', '6.00', '72.00', '432.00', NULL);
INSERT INTO `compras_detalle` VALUES ('34', '11', '660023', '24.00', '213.00', '5112.00', NULL);
INSERT INTO `compras_detalle` VALUES ('35', '11', '660002', '10.00', '25.00', '250.00', NULL);
INSERT INTO `compras_detalle` VALUES ('36', '12', '660096', '2.00', '120.00', '240.00', NULL);
INSERT INTO `compras_detalle` VALUES ('37', '12', '660031', '3.00', '80.00', '240.00', NULL);
INSERT INTO `compras_detalle` VALUES ('38', '13', '660094', '2.00', '200.00', '400.00', NULL);
INSERT INTO `compras_detalle` VALUES ('39', '13', '756058841478', '4.00', '40.00', '160.00', NULL);
INSERT INTO `compras_detalle` VALUES ('40', '13', '660031', '2.00', '80.00', '160.00', NULL);
INSERT INTO `compras_detalle` VALUES ('41', '13', '660012', '12.00', '50.00', '600.00', NULL);
INSERT INTO `compras_detalle` VALUES ('42', '13', '660095', '4.00', '70.00', '280.00', NULL);
INSERT INTO `compras_detalle` VALUES ('43', '13', '660093', '2.00', '180.00', '360.00', NULL);
INSERT INTO `compras_detalle` VALUES ('44', '13', '660026', '3.00', '430.00', '1290.00', NULL);
INSERT INTO `compras_detalle` VALUES ('45', '13', '660017', '8.00', '72.00', '576.00', NULL);
INSERT INTO `compras_detalle` VALUES ('46', '13', '660037', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('47', '13', '990091', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('48', '14', '660033', '32.00', '20.00', '640.00', NULL);
INSERT INTO `compras_detalle` VALUES ('49', '15', '660036', '3.00', '135.00', '405.00', NULL);
INSERT INTO `compras_detalle` VALUES ('50', '16', '660012', '1.00', '50.00', '50.00', NULL);
INSERT INTO `compras_detalle` VALUES ('51', '17', '660012', '28.00', '50.00', '1400.00', NULL);
INSERT INTO `compras_detalle` VALUES ('52', '17', '660090', '4.00', '1150.00', '4600.00', NULL);
INSERT INTO `compras_detalle` VALUES ('53', '17', '660016', '3.00', '620.00', '1860.00', NULL);
INSERT INTO `compras_detalle` VALUES ('54', '17', '660089', '24.00', '20.00', '480.00', NULL);
INSERT INTO `compras_detalle` VALUES ('55', '17', '660088', '10.00', '18.00', '180.00', NULL);
INSERT INTO `compras_detalle` VALUES ('56', '17', '660087', '7.00', '143.00', '1001.00', NULL);
INSERT INTO `compras_detalle` VALUES ('57', '17', '660087', '25.00', '40.00', '1000.00', NULL);
INSERT INTO `compras_detalle` VALUES ('58', '18', '660100', '25.00', '40.00', '1000.00', NULL);
INSERT INTO `compras_detalle` VALUES ('59', '18', '660007', '70.00', '20.00', '1400.00', NULL);
INSERT INTO `compras_detalle` VALUES ('60', '18', '660101', '8.00', '25.00', '200.00', NULL);
INSERT INTO `compras_detalle` VALUES ('61', '18', '660102', '3.00', '170.00', '510.00', NULL);
INSERT INTO `compras_detalle` VALUES ('62', '18', '660103', '10.00', '130.00', '1300.00', NULL);
INSERT INTO `compras_detalle` VALUES ('63', '19', '660104', '10.00', '120.00', '1200.00', NULL);
INSERT INTO `compras_detalle` VALUES ('64', '20', '660027', '24.00', '160.00', '3840.00', NULL);
INSERT INTO `compras_detalle` VALUES ('65', '20', '660006', '12.00', '212.00', '2544.00', NULL);
INSERT INTO `compras_detalle` VALUES ('66', '21', '440001', '8.00', '90.00', '720.00', NULL);
INSERT INTO `compras_detalle` VALUES ('67', '21', '660026', '3.00', '430.00', '1290.00', NULL);
INSERT INTO `compras_detalle` VALUES ('68', '22', '660013', '16.00', '35.00', '560.00', NULL);
INSERT INTO `compras_detalle` VALUES ('69', '22', '660020', '5.00', '570.00', '2850.00', NULL);
INSERT INTO `compras_detalle` VALUES ('70', '22', '660018', '2.00', '580.00', '1160.00', NULL);
INSERT INTO `compras_detalle` VALUES ('71', '22', '660096', '4.00', '120.00', '480.00', NULL);
INSERT INTO `compras_detalle` VALUES ('72', '22', '660003', '8.00', '360.00', '2880.00', NULL);
INSERT INTO `compras_detalle` VALUES ('73', '22', '660037', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('74', '22', '660012', '17.00', '50.00', '850.00', NULL);
INSERT INTO `compras_detalle` VALUES ('75', '22', '660017', '11.00', '88.00', '968.00', NULL);
INSERT INTO `compras_detalle` VALUES ('76', '22', '660014', '5.00', '220.00', '1100.00', NULL);
INSERT INTO `compras_detalle` VALUES ('77', '22', '440001', '4.00', '90.00', '360.00', NULL);
INSERT INTO `compras_detalle` VALUES ('78', '23', '660035', '3.00', '15.00', '45.00', NULL);
INSERT INTO `compras_detalle` VALUES ('79', '24', '660017', '4.00', '88.00', '352.00', NULL);
INSERT INTO `compras_detalle` VALUES ('80', '24', '660030', '4.00', '180.00', '720.00', NULL);
INSERT INTO `compras_detalle` VALUES ('81', '24', '881108', '3.00', '292.71', '878.13', NULL);
INSERT INTO `compras_detalle` VALUES ('82', '25', '660023', '24.00', '213.00', '5112.00', NULL);
INSERT INTO `compras_detalle` VALUES ('83', '25', '660021', '24.00', '217.00', '5208.00', NULL);
INSERT INTO `compras_detalle` VALUES ('84', '26', '660010', '4.00', '130.00', '520.00', NULL);
INSERT INTO `compras_detalle` VALUES ('85', '26', '660015', '1.00', '300.00', '300.00', NULL);
INSERT INTO `compras_detalle` VALUES ('86', '27', '660009', '4.00', '120.00', '480.00', NULL);
INSERT INTO `compras_detalle` VALUES ('87', '28', '660015', '3.00', '300.00', '900.00', NULL);
INSERT INTO `compras_detalle` VALUES ('88', '29', '660017', '5.00', '88.00', '440.00', NULL);
INSERT INTO `compras_detalle` VALUES ('89', '30', '440002', '24.00', '200.00', '4800.00', NULL);
INSERT INTO `compras_detalle` VALUES ('90', '30', '440001', '15.00', '90.00', '1350.00', NULL);
INSERT INTO `compras_detalle` VALUES ('91', '30', '660017', '10.00', '88.00', '880.00', NULL);
INSERT INTO `compras_detalle` VALUES ('92', '30', '660026', '2.00', '430.00', '860.00', NULL);
INSERT INTO `compras_detalle` VALUES ('93', '30', '660025', '2.00', '430.00', '860.00', NULL);
INSERT INTO `compras_detalle` VALUES ('94', '31', '660012', '20.00', '60.00', '1200.00', NULL);
INSERT INTO `compras_detalle` VALUES ('95', '31', '660017', '10.00', '88.00', '880.00', NULL);
INSERT INTO `compras_detalle` VALUES ('96', '32', '660015', '11.00', '300.00', '3300.00', NULL);
INSERT INTO `compras_detalle` VALUES ('97', '32', '660043', '1.00', '700.00', '700.00', NULL);
INSERT INTO `compras_detalle` VALUES ('98', '32', '440003', '1.00', '1100.00', '1100.00', NULL);
INSERT INTO `compras_detalle` VALUES ('99', '32', '440001', '6.00', '90.00', '540.00', NULL);
INSERT INTO `compras_detalle` VALUES ('100', '32', '660017', '8.00', '88.00', '704.00', NULL);
INSERT INTO `compras_detalle` VALUES ('101', '32', '660031', '1.00', '82.00', '82.00', NULL);
INSERT INTO `compras_detalle` VALUES ('102', '32', '660014', '6.00', '220.00', '1320.00', NULL);
INSERT INTO `compras_detalle` VALUES ('103', '32', '660026', '1.00', '430.00', '430.00', NULL);
INSERT INTO `compras_detalle` VALUES ('104', '32', '660025', '1.00', '430.00', '430.00', NULL);
INSERT INTO `compras_detalle` VALUES ('105', '32', '660012', '2.00', '60.00', '120.00', NULL);
INSERT INTO `compras_detalle` VALUES ('106', '33', '660043', '5.00', '700.00', '3500.00', NULL);
INSERT INTO `compras_detalle` VALUES ('107', '33', '660011', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('108', '33', '660012', '22.00', '60.00', '1320.00', NULL);
INSERT INTO `compras_detalle` VALUES ('109', '33', '440004', '6.00', '1250.00', '7500.00', NULL);
INSERT INTO `compras_detalle` VALUES ('110', '33', '660037', '24.00', '210.00', '5040.00', NULL);
INSERT INTO `compras_detalle` VALUES ('111', '33', '660023', '24.00', '213.00', '5112.00', NULL);
INSERT INTO `compras_detalle` VALUES ('112', '34', '440005', '2.00', '500.00', '1000.00', NULL);
INSERT INTO `compras_detalle` VALUES ('113', '34', '660010', '10.00', '130.00', '1300.00', NULL);

DROP TABLE IF EXISTS `config_facturacion`;
CREATE TABLE `config_facturacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ultimo_consecutivo` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `contabilidad_config`;
CREATE TABLE `contabilidad_config` (
  `clave` varchar(50) NOT NULL,
  `valor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `contabilidad_config` VALUES ('fecha_cierre', '2025-12-31');

DROP TABLE IF EXISTS `contabilidad_cuentas`;
CREATE TABLE `contabilidad_cuentas` (
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `nivel` int(11) DEFAULT 1,
  `padre_codigo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `contabilidad_cuentas` VALUES ('101', 'Efectivo en Caja', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('101.001', 'Caja Magnolia', 'ACTIVO', '2', '101');
INSERT INTO `contabilidad_cuentas` VALUES ('101.002', 'Caja Marinero', 'ACTIVO', '2', '101');
INSERT INTO `contabilidad_cuentas` VALUES ('102', 'Efectivo en Banco', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('102.001', 'Mayorista CUP Metro', 'ACTIVO', '2', '102');
INSERT INTO `contabilidad_cuentas` VALUES ('102.002', 'Corriente CUP Metro', 'ACTIVO', '2', '102');
INSERT INTO `contabilidad_cuentas` VALUES ('102.003', 'CUC Metro', 'ACTIVO', '2', '102');
INSERT INTO `contabilidad_cuentas` VALUES ('108', 'Cuentas por Cobrar (Clientes)', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('120', 'Inventario de Mercancías', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('121', 'Materias Primas y Materiales', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('140', 'Activos Fijos Tangibles (Equipos)', 'ACTIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('201', 'Cuentas por Pagar (Proveedores)', 'PASIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('210', 'Salarios y Sueldos por Pagar', 'PASIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('240', 'Obligaciones con el Fisco (Impuestos)', 'PASIVO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('240.1', 'Impuesto s/Ventas (10%)', 'PASIVO', '2', '240');
INSERT INTO `contabilidad_cuentas` VALUES ('240.2', 'Contribución Local (1%)', 'PASIVO', '2', '240');
INSERT INTO `contabilidad_cuentas` VALUES ('240.3', 'Seguridad Social (14%)', 'PASIVO', '2', '240');
INSERT INTO `contabilidad_cuentas` VALUES ('240.4', 'Impuesto s/Utilidades', 'PASIVO', '2', '240');
INSERT INTO `contabilidad_cuentas` VALUES ('240.5', 'Seguridad Social por Pagar', 'PASIVO', '2', '240');
INSERT INTO `contabilidad_cuentas` VALUES ('401', 'Ingresos por Ventas (Bienes)', 'INGRESO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('402', 'Ingresos por Servicios', 'INGRESO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('409', 'Otros Ingresos', 'INGRESO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('501', 'Costo de Ventas (Mercancía)', 'COSTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('502', 'Costo de Producción', 'COSTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('600', 'Patrimonio Neto', 'PATRIMONIO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('601', 'Capital Contable', 'PATRIMONIO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('630', 'Utilidades Retenidas', 'PATRIMONIO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('640', 'Reserva para Contingencias', 'PATRIMONIO', '2', '600');
INSERT INTO `contabilidad_cuentas` VALUES ('701', 'Gastos de Personal (Salarios)', 'GASTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('702', 'Gastos de SERVICIOS', 'GASTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('703', 'Mantenimiento y Reparaciones', 'GASTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('704', 'Gastos de ONAT', 'GASTO', '1', NULL);
INSERT INTO `contabilidad_cuentas` VALUES ('704.1', 'Gasto Impuesto Ventas', 'GASTO', '2', '704');
INSERT INTO `contabilidad_cuentas` VALUES ('704.2', 'Gasto Fuerza Trabajo', 'GASTO', '2', '704');
INSERT INTO `contabilidad_cuentas` VALUES ('704.3', 'Gasto Contribución Local', 'GASTO', '2', '704');
INSERT INTO `contabilidad_cuentas` VALUES ('704.4', 'Gasto Seguridad Social', 'GASTO', '2', '704');
INSERT INTO `contabilidad_cuentas` VALUES ('704.5', 'Gasto Impuesto Utilidades', 'GASTO', '2', '704');
INSERT INTO `contabilidad_cuentas` VALUES ('709', 'Gastos Personales (Retiro Socio)', 'GASTO', '1', NULL);

DROP TABLE IF EXISTS `contabilidad_diario`;
CREATE TABLE `contabilidad_diario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asiento_id` varchar(30) NOT NULL DEFAULT '0',
  `fecha` date DEFAULT NULL,
  `asiento_tipo` varchar(50) DEFAULT NULL,
  `referencia_id` int(11) DEFAULT NULL,
  `cuenta` varchar(100) DEFAULT NULL,
  `debe` decimal(12,2) DEFAULT 0.00,
  `haber` decimal(12,2) DEFAULT 0.00,
  `creado_por` varchar(50) DEFAULT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fecha` (`fecha`),
  KEY `cuenta` (`cuenta`),
  KEY `asiento_id` (`asiento_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3790 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `contabilidad_diario` VALUES ('399', 'OLD-399', '2026-02-26', 'GASTO', '9', '702 - Gastos de Energía y Agua', '3000.00', '0.00', NULL, 'pago de luz');
INSERT INTO `contabilidad_diario` VALUES ('400', 'OLD-400', '2026-02-26', 'GASTO', '9', '101 - Efectivo', '0.00', '3000.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('401', 'OLD-401', '2026-02-28', 'GASTO', '10', '702 - Gastos de Energía y Agua', '5600.00', '0.00', NULL, 'ETECSA MOVILES');
INSERT INTO `contabilidad_diario` VALUES ('402', 'OLD-402', '2026-02-28', 'GASTO', '10', '101 - Efectivo', '0.00', '5600.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('403', 'OLD-403', '2026-02-10', 'GASTO', '11', '702 - Gastos de Energía y Agua', '7800.00', '0.00', NULL, 'Impuestos ONAT');
INSERT INTO `contabilidad_diario` VALUES ('404', 'OLD-404', '2026-02-10', 'GASTO', '11', '101 - Efectivo', '0.00', '7800.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('405', 'OLD-405', '2026-02-15', 'GASTO', '12', '702 - Gastos de Energía y Agua', '8000.00', '0.00', NULL, 'Impuesto 10%');
INSERT INTO `contabilidad_diario` VALUES ('406', 'OLD-406', '2026-02-15', 'GASTO', '12', '101 - Efectivo', '0.00', '8000.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('1407', 'OLD-1407', '2026-01-01', 'AJUSTE', '0', '120 - Inventario Mercancías', '107385.00', '0.00', NULL, 'Ajuste Inventario Inicial/Físico');
INSERT INTO `contabilidad_diario` VALUES ('1408', 'OLD-1408', '2026-01-01', 'AJUSTE', '0', '601 - Capital Social', '0.00', '107385.00', NULL, 'Regularización de Stock');
INSERT INTO `contabilidad_diario` VALUES ('2793', 'OLD-2793', '2026-01-31', 'AJUSTE', '0', '120 - Inventario Mercancías', '179801.35', '0.00', NULL, 'Ajuste Inv. (global)');
INSERT INTO `contabilidad_diario` VALUES ('2794', 'OLD-2794', '2026-01-31', 'AJUSTE', '0', '601 - Capital Social', '0.00', '179801.35', NULL, 'Regularización Stock');
INSERT INTO `contabilidad_diario` VALUES ('3115', 'OLD-3115', '2026-01-28', 'AJUSTE', '0', '601 - Capital Social', '179801.35', '0.00', NULL, 'Ajuste Merma (local)');
INSERT INTO `contabilidad_diario` VALUES ('3116', 'OLD-3116', '2026-01-28', 'AJUSTE', '0', '120 - Inventario Mercancías', '0.00', '179801.35', NULL, 'Corrección Inv.');
INSERT INTO `contabilidad_diario` VALUES ('3277', 'OLD-3277', '2026-01-28', 'AJUSTE', '0', '120 - Inventario Mercancías', '179801.35', '0.00', NULL, 'Ajuste Inv. (global)');
INSERT INTO `contabilidad_diario` VALUES ('3278', 'OLD-3278', '2026-01-28', 'AJUSTE', '0', '601 - Capital Social', '0.00', '179801.35', NULL, 'Regularización Stock');
INSERT INTO `contabilidad_diario` VALUES ('3613', 'OLD-3613', '2026-01-23', 'VENTA', '1', '102 - Banco', '2280.00', '0.00', NULL, 'Venta #1');
INSERT INTO `contabilidad_diario` VALUES ('3614', 'OLD-3614', '2026-01-23', 'VENTA', '1', '401 - Ingresos', '0.00', '2280.00', NULL, 'Venta #1');
INSERT INTO `contabilidad_diario` VALUES ('3615', 'OLD-3615', '2026-01-23', 'COSTO', '1', '501 - Costo', '1409.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3616', 'OLD-3616', '2026-01-23', 'COSTO', '1', '120 - Inventario', '0.00', '1409.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3617', 'OLD-3617', '2026-01-23', 'VENTA', '2', '101.004 - Cuenta General', '5010.00', '0.00', NULL, 'Venta #2');
INSERT INTO `contabilidad_diario` VALUES ('3618', 'OLD-3618', '2026-01-23', 'VENTA', '2', '401 - Ingresos', '0.00', '5010.00', NULL, 'Venta #2');
INSERT INTO `contabilidad_diario` VALUES ('3619', 'OLD-3619', '2026-01-23', 'COSTO', '2', '501 - Costo', '4304.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3620', 'OLD-3620', '2026-01-23', 'COSTO', '2', '120 - Inventario', '0.00', '4304.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3621', 'OLD-3621', '2026-01-24', 'VENTA', '3', '101.004 - Cuenta General', '3160.00', '0.00', NULL, 'Venta #3');
INSERT INTO `contabilidad_diario` VALUES ('3622', 'OLD-3622', '2026-01-24', 'VENTA', '3', '401 - Ingresos', '0.00', '3160.00', NULL, 'Venta #3');
INSERT INTO `contabilidad_diario` VALUES ('3623', 'OLD-3623', '2026-01-24', 'COSTO', '3', '501 - Costo', '2440.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3624', 'OLD-3624', '2026-01-24', 'COSTO', '3', '120 - Inventario', '0.00', '2440.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3625', 'OLD-3625', '2026-01-24', 'VENTA', '4', '102 - Banco', '70.00', '0.00', NULL, 'Venta #4');
INSERT INTO `contabilidad_diario` VALUES ('3626', 'OLD-3626', '2026-01-24', 'VENTA', '4', '401 - Ingresos', '0.00', '70.00', NULL, 'Venta #4');
INSERT INTO `contabilidad_diario` VALUES ('3627', 'OLD-3627', '2026-01-24', 'COSTO', '4', '501 - Costo', '35.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3628', 'OLD-3628', '2026-01-24', 'COSTO', '4', '120 - Inventario', '0.00', '35.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3629', 'OLD-3629', '2026-01-24', 'VENTA', '5', '101.004 - Cuenta General', '4475.00', '0.00', NULL, 'Venta #5');
INSERT INTO `contabilidad_diario` VALUES ('3630', 'OLD-3630', '2026-01-24', 'VENTA', '5', '401 - Ingresos', '0.00', '4475.00', NULL, 'Venta #5');
INSERT INTO `contabilidad_diario` VALUES ('3631', 'OLD-3631', '2026-01-24', 'COSTO', '5', '501 - Costo', '3713.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3632', 'OLD-3632', '2026-01-24', 'COSTO', '5', '120 - Inventario', '0.00', '3713.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3633', 'OLD-3633', '2026-01-29', 'VENTA', '6', '101.004 - Cuenta General', '-600.00', '0.00', NULL, 'Venta #6');
INSERT INTO `contabilidad_diario` VALUES ('3634', 'OLD-3634', '2026-01-29', 'VENTA', '6', '401 - Ingresos', '0.00', '-600.00', NULL, 'Venta #6');
INSERT INTO `contabilidad_diario` VALUES ('3635', 'OLD-3635', '2026-01-29', 'COSTO', '6', '501 - Costo', '-300.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3636', 'OLD-3636', '2026-01-29', 'COSTO', '6', '120 - Inventario', '0.00', '-300.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3637', 'OLD-3637', '2026-01-24', 'VENTA', '7', '101.004 - Cuenta General', '840.00', '0.00', NULL, 'Venta #7');
INSERT INTO `contabilidad_diario` VALUES ('3638', 'OLD-3638', '2026-01-24', 'VENTA', '7', '401 - Ingresos', '0.00', '840.00', NULL, 'Venta #7');
INSERT INTO `contabilidad_diario` VALUES ('3639', 'OLD-3639', '2026-01-24', 'COSTO', '7', '501 - Costo', '540.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3640', 'OLD-3640', '2026-01-24', 'COSTO', '7', '120 - Inventario', '0.00', '540.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3641', 'OLD-3641', '2026-01-24', 'VENTA', '8', '101.004 - Cuenta General', '800.00', '0.00', NULL, 'Venta #8');
INSERT INTO `contabilidad_diario` VALUES ('3642', 'OLD-3642', '2026-01-24', 'VENTA', '8', '401 - Ingresos', '0.00', '800.00', NULL, 'Venta #8');
INSERT INTO `contabilidad_diario` VALUES ('3643', 'OLD-3643', '2026-01-24', 'COSTO', '8', '501 - Costo', '400.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3644', 'OLD-3644', '2026-01-24', 'COSTO', '8', '120 - Inventario', '0.00', '400.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3645', 'OLD-3645', '2026-01-25', 'VENTA', '9', '102 - Banco', '4090.00', '0.00', NULL, 'Venta #9');
INSERT INTO `contabilidad_diario` VALUES ('3646', 'OLD-3646', '2026-01-25', 'VENTA', '9', '401 - Ingresos', '0.00', '4090.00', NULL, 'Venta #9');
INSERT INTO `contabilidad_diario` VALUES ('3647', 'OLD-3647', '2026-01-25', 'COSTO', '9', '501 - Costo', '3364.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3648', 'OLD-3648', '2026-01-25', 'COSTO', '9', '120 - Inventario', '0.00', '3364.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3649', 'OLD-3649', '2026-01-25', 'VENTA', '10', '101.004 - Cuenta General', '10225.00', '0.00', NULL, 'Venta #10');
INSERT INTO `contabilidad_diario` VALUES ('3650', 'OLD-3650', '2026-01-25', 'VENTA', '10', '401 - Ingresos', '0.00', '10225.00', NULL, 'Venta #10');
INSERT INTO `contabilidad_diario` VALUES ('3651', 'OLD-3651', '2026-01-25', 'COSTO', '10', '501 - Costo', '7997.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3652', 'OLD-3652', '2026-01-25', 'COSTO', '10', '120 - Inventario', '0.00', '7997.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3653', 'OLD-3653', '2026-01-29', 'VENTA', '11', '101.004 - Cuenta General', '-80.00', '0.00', NULL, 'Venta #11');
INSERT INTO `contabilidad_diario` VALUES ('3654', 'OLD-3654', '2026-01-29', 'VENTA', '11', '401 - Ingresos', '0.00', '-80.00', NULL, 'Venta #11');
INSERT INTO `contabilidad_diario` VALUES ('3655', 'OLD-3655', '2026-01-29', 'COSTO', '11', '501 - Costo', '-35.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3656', 'OLD-3656', '2026-01-29', 'COSTO', '11', '120 - Inventario', '0.00', '-35.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3657', 'OLD-3657', '2026-01-26', 'VENTA', '12', '101.004 - Cuenta General', '4210.00', '0.00', NULL, 'Venta #12');
INSERT INTO `contabilidad_diario` VALUES ('3658', 'OLD-3658', '2026-01-26', 'VENTA', '12', '401 - Ingresos', '0.00', '4210.00', NULL, 'Venta #12');
INSERT INTO `contabilidad_diario` VALUES ('3659', 'OLD-3659', '2026-01-26', 'COSTO', '12', '501 - Costo', '2960.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3660', 'OLD-3660', '2026-01-26', 'COSTO', '12', '120 - Inventario', '0.00', '2960.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3661', 'OLD-3661', '2026-01-26', 'VENTA', '13', '101.004 - Cuenta General', '1100.00', '0.00', NULL, 'Venta #13');
INSERT INTO `contabilidad_diario` VALUES ('3662', 'OLD-3662', '2026-01-26', 'VENTA', '13', '401 - Ingresos', '0.00', '1100.00', NULL, 'Venta #13');
INSERT INTO `contabilidad_diario` VALUES ('3663', 'OLD-3663', '2026-01-26', 'COSTO', '13', '501 - Costo', '550.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3664', 'OLD-3664', '2026-01-26', 'COSTO', '13', '120 - Inventario', '0.00', '550.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3665', 'OLD-3665', '2026-01-27', 'VENTA', '14', '102 - Banco', '1260.00', '0.00', NULL, 'Venta #14');
INSERT INTO `contabilidad_diario` VALUES ('3666', 'OLD-3666', '2026-01-27', 'VENTA', '14', '401 - Ingresos', '0.00', '1260.00', NULL, 'Venta #14');
INSERT INTO `contabilidad_diario` VALUES ('3667', 'OLD-3667', '2026-01-27', 'COSTO', '14', '501 - Costo', '1062.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3668', 'OLD-3668', '2026-01-27', 'COSTO', '14', '120 - Inventario', '0.00', '1062.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3669', 'OLD-3669', '2026-01-27', 'VENTA', '15', '101.004 - Cuenta General', '4855.00', '0.00', NULL, 'Venta #15');
INSERT INTO `contabilidad_diario` VALUES ('3670', 'OLD-3670', '2026-01-27', 'VENTA', '15', '401 - Ingresos', '0.00', '4855.00', NULL, 'Venta #15');
INSERT INTO `contabilidad_diario` VALUES ('3671', 'OLD-3671', '2026-01-27', 'COSTO', '15', '501 - Costo', '3257.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3672', 'OLD-3672', '2026-01-27', 'COSTO', '15', '120 - Inventario', '0.00', '3257.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3673', 'OLD-3673', '2026-01-28', 'VENTA', '16', '102 - Banco', '1000.00', '0.00', NULL, 'Venta #16');
INSERT INTO `contabilidad_diario` VALUES ('3674', 'OLD-3674', '2026-01-28', 'VENTA', '16', '401 - Ingresos', '0.00', '1000.00', NULL, 'Venta #16');
INSERT INTO `contabilidad_diario` VALUES ('3675', 'OLD-3675', '2026-01-28', 'COSTO', '16', '501 - Costo', '500.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3676', 'OLD-3676', '2026-01-28', 'COSTO', '16', '120 - Inventario', '0.00', '500.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3677', 'OLD-3677', '2026-01-28', 'VENTA', '17', '101.004 - Cuenta General', '2020.00', '0.00', NULL, 'Venta #17');
INSERT INTO `contabilidad_diario` VALUES ('3678', 'OLD-3678', '2026-01-28', 'VENTA', '17', '401 - Ingresos', '0.00', '2020.00', NULL, 'Venta #17');
INSERT INTO `contabilidad_diario` VALUES ('3679', 'OLD-3679', '2026-01-28', 'COSTO', '17', '501 - Costo', '1561.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3680', 'OLD-3680', '2026-01-28', 'COSTO', '17', '120 - Inventario', '0.00', '1561.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3681', 'OLD-3681', '2026-01-28', 'VENTA', '18', '101.004 - Cuenta General', '3235.00', '0.00', NULL, 'Venta #18');
INSERT INTO `contabilidad_diario` VALUES ('3682', 'OLD-3682', '2026-01-28', 'VENTA', '18', '401 - Ingresos', '0.00', '3235.00', NULL, 'Venta #18');
INSERT INTO `contabilidad_diario` VALUES ('3683', 'OLD-3683', '2026-01-28', 'COSTO', '18', '501 - Costo', '2776.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3684', 'OLD-3684', '2026-01-28', 'COSTO', '18', '120 - Inventario', '0.00', '2776.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3685', 'OLD-3685', '2026-01-28', 'VENTA', '19', '101.004 - Cuenta General', '400.00', '0.00', NULL, 'Venta #19');
INSERT INTO `contabilidad_diario` VALUES ('3686', 'OLD-3686', '2026-01-28', 'VENTA', '19', '401 - Ingresos', '0.00', '400.00', NULL, 'Venta #19');
INSERT INTO `contabilidad_diario` VALUES ('3687', 'OLD-3687', '2026-01-28', 'COSTO', '19', '501 - Costo', '294.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3688', 'OLD-3688', '2026-01-28', 'COSTO', '19', '120 - Inventario', '0.00', '294.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3689', 'OLD-3689', '2026-01-12', 'VENTA', '20', '101.004 - Cuenta General', '360.00', '0.00', NULL, 'Venta #20');
INSERT INTO `contabilidad_diario` VALUES ('3690', 'OLD-3690', '2026-01-12', 'VENTA', '20', '401 - Ingresos', '0.00', '360.00', NULL, 'Venta #20');
INSERT INTO `contabilidad_diario` VALUES ('3691', 'OLD-3691', '2026-01-12', 'COSTO', '20', '501 - Costo', '220.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3692', 'OLD-3692', '2026-01-12', 'COSTO', '20', '120 - Inventario', '0.00', '220.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3693', 'OLD-3693', '2026-01-12', 'VENTA', '21', '102 - Banco', '650.00', '0.00', NULL, 'Venta #21');
INSERT INTO `contabilidad_diario` VALUES ('3694', 'OLD-3694', '2026-01-12', 'VENTA', '21', '401 - Ingresos', '0.00', '650.00', NULL, 'Venta #21');
INSERT INTO `contabilidad_diario` VALUES ('3695', 'OLD-3695', '2026-01-12', 'COSTO', '21', '501 - Costo', '560.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3696', 'OLD-3696', '2026-01-12', 'COSTO', '21', '120 - Inventario', '0.00', '560.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3697', 'OLD-3697', '2026-01-30', 'VENTA', '22', '101.004 - Cuenta General', '-360.00', '0.00', NULL, 'Venta #22');
INSERT INTO `contabilidad_diario` VALUES ('3698', 'OLD-3698', '2026-01-30', 'VENTA', '22', '401 - Ingresos', '0.00', '-360.00', NULL, 'Venta #22');
INSERT INTO `contabilidad_diario` VALUES ('3699', 'OLD-3699', '2026-01-30', 'COSTO', '22', '501 - Costo', '-220.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3700', 'OLD-3700', '2026-01-30', 'COSTO', '22', '120 - Inventario', '0.00', '-220.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3701', 'OLD-3701', '2026-01-30', 'VENTA', '23', '101.004 - Cuenta General', '-650.00', '0.00', NULL, 'Venta #23');
INSERT INTO `contabilidad_diario` VALUES ('3702', 'OLD-3702', '2026-01-30', 'VENTA', '23', '401 - Ingresos', '0.00', '-650.00', NULL, 'Venta #23');
INSERT INTO `contabilidad_diario` VALUES ('3703', 'OLD-3703', '2026-01-30', 'COSTO', '23', '501 - Costo', '-560.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3704', 'OLD-3704', '2026-01-30', 'COSTO', '23', '120 - Inventario', '0.00', '-560.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3705', 'OLD-3705', '2026-01-29', 'VENTA', '24', '102 - Banco', '2030.00', '0.00', NULL, 'Venta #24');
INSERT INTO `contabilidad_diario` VALUES ('3706', 'OLD-3706', '2026-01-29', 'VENTA', '24', '401 - Ingresos', '0.00', '2030.00', NULL, 'Venta #24');
INSERT INTO `contabilidad_diario` VALUES ('3707', 'OLD-3707', '2026-01-29', 'COSTO', '24', '501 - Costo', '1535.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3708', 'OLD-3708', '2026-01-29', 'COSTO', '24', '120 - Inventario', '0.00', '1535.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3709', 'OLD-3709', '2026-01-29', 'VENTA', '25', '101.004 - Cuenta General', '3850.00', '0.00', NULL, 'Venta #25');
INSERT INTO `contabilidad_diario` VALUES ('3710', 'OLD-3710', '2026-01-29', 'VENTA', '25', '401 - Ingresos', '0.00', '3850.00', NULL, 'Venta #25');
INSERT INTO `contabilidad_diario` VALUES ('3711', 'OLD-3711', '2026-01-29', 'COSTO', '25', '501 - Costo', '3076.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3712', 'OLD-3712', '2026-01-29', 'COSTO', '25', '120 - Inventario', '0.00', '3076.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3713', 'OLD-3713', '2026-01-29', 'VENTA', '26', '101.004 - Cuenta General', '2980.00', '0.00', NULL, 'Venta #26');
INSERT INTO `contabilidad_diario` VALUES ('3714', 'OLD-3714', '2026-01-29', 'VENTA', '26', '401 - Ingresos', '0.00', '2980.00', NULL, 'Venta #26');
INSERT INTO `contabilidad_diario` VALUES ('3715', 'OLD-3715', '2026-01-29', 'COSTO', '26', '501 - Costo', '1686.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3716', 'OLD-3716', '2026-01-29', 'COSTO', '26', '120 - Inventario', '0.00', '1686.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3717', 'OLD-3717', '2026-01-29', 'VENTA', '27', '101.004 - Cuenta General', '4080.00', '0.00', NULL, 'Venta #27');
INSERT INTO `contabilidad_diario` VALUES ('3718', 'OLD-3718', '2026-01-29', 'VENTA', '27', '401 - Ingresos', '0.00', '4080.00', NULL, 'Venta #27');
INSERT INTO `contabilidad_diario` VALUES ('3719', 'OLD-3719', '2026-01-29', 'COSTO', '27', '501 - Costo', '3597.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3720', 'OLD-3720', '2026-01-29', 'COSTO', '27', '120 - Inventario', '0.00', '3597.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3721', 'OLD-3721', '2026-01-30', 'VENTA', '28', '102 - Banco', '1830.00', '0.00', NULL, 'Venta #28');
INSERT INTO `contabilidad_diario` VALUES ('3722', 'OLD-3722', '2026-01-30', 'VENTA', '28', '401 - Ingresos', '0.00', '1830.00', NULL, 'Venta #28');
INSERT INTO `contabilidad_diario` VALUES ('3723', 'OLD-3723', '2026-01-30', 'COSTO', '28', '501 - Costo', '1385.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3724', 'OLD-3724', '2026-01-30', 'COSTO', '28', '120 - Inventario', '0.00', '1385.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3725', 'OLD-3725', '2026-01-30', 'VENTA', '29', '102 - Banco', '4400.00', '0.00', NULL, 'Venta #29');
INSERT INTO `contabilidad_diario` VALUES ('3726', 'OLD-3726', '2026-01-30', 'VENTA', '29', '401 - Ingresos', '0.00', '4400.00', NULL, 'Venta #29');
INSERT INTO `contabilidad_diario` VALUES ('3727', 'OLD-3727', '2026-01-30', 'COSTO', '29', '501 - Costo', '2700.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3728', 'OLD-3728', '2026-01-30', 'COSTO', '29', '120 - Inventario', '0.00', '2700.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3729', 'OLD-3729', '2026-01-30', 'VENTA', '30', '102 - Banco', '240.00', '0.00', NULL, 'Venta #30');
INSERT INTO `contabilidad_diario` VALUES ('3730', 'OLD-3730', '2026-01-30', 'VENTA', '30', '401 - Ingresos', '0.00', '240.00', NULL, 'Venta #30');
INSERT INTO `contabilidad_diario` VALUES ('3731', 'OLD-3731', '2026-01-30', 'COSTO', '30', '501 - Costo', '166.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3732', 'OLD-3732', '2026-01-30', 'COSTO', '30', '120 - Inventario', '0.00', '166.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3733', 'OLD-3733', '2026-01-30', 'VENTA', '31', '101.004 - Cuenta General', '3550.00', '0.00', NULL, 'Venta #31');
INSERT INTO `contabilidad_diario` VALUES ('3734', 'OLD-3734', '2026-01-30', 'VENTA', '31', '401 - Ingresos', '0.00', '3550.00', NULL, 'Venta #31');
INSERT INTO `contabilidad_diario` VALUES ('3735', 'OLD-3735', '2026-01-30', 'COSTO', '31', '501 - Costo', '2487.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3736', 'OLD-3736', '2026-01-30', 'COSTO', '31', '120 - Inventario', '0.00', '2487.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3737', 'OLD-3737', '2026-01-30', 'VENTA', '32', '101.004 - Cuenta General', '3230.00', '0.00', NULL, 'Venta #32');
INSERT INTO `contabilidad_diario` VALUES ('3738', 'OLD-3738', '2026-01-30', 'VENTA', '32', '401 - Ingresos', '0.00', '3230.00', NULL, 'Venta #32');
INSERT INTO `contabilidad_diario` VALUES ('3739', 'OLD-3739', '2026-01-30', 'COSTO', '32', '501 - Costo', '2179.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3740', 'OLD-3740', '2026-01-30', 'COSTO', '32', '120 - Inventario', '0.00', '2179.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3741', 'OLD-3741', '2026-01-30', 'VENTA', '33', '101.004 - Cuenta General', '4440.00', '0.00', NULL, 'Venta #33');
INSERT INTO `contabilidad_diario` VALUES ('3742', 'OLD-3742', '2026-01-30', 'VENTA', '33', '401 - Ingresos', '0.00', '4440.00', NULL, 'Venta #33');
INSERT INTO `contabilidad_diario` VALUES ('3743', 'OLD-3743', '2026-01-30', 'COSTO', '33', '501 - Costo', '3890.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3744', 'OLD-3744', '2026-01-30', 'COSTO', '33', '120 - Inventario', '0.00', '3890.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3745', 'OLD-3745', '2026-01-30', 'VENTA', '34', '101.004 - Cuenta General', '15.00', '0.00', NULL, 'Venta #34');
INSERT INTO `contabilidad_diario` VALUES ('3746', 'OLD-3746', '2026-01-30', 'VENTA', '34', '401 - Ingresos', '0.00', '15.00', NULL, 'Venta #34');
INSERT INTO `contabilidad_diario` VALUES ('3747', 'OLD-3747', '2026-01-30', 'COSTO', '34', '501 - Costo', '8.00', '0.00', NULL, 'Costo Venta');
INSERT INTO `contabilidad_diario` VALUES ('3748', 'OLD-3748', '2026-01-30', 'COSTO', '34', '120 - Inventario', '0.00', '8.00', NULL, 'Baja Stock');
INSERT INTO `contabilidad_diario` VALUES ('3749', 'OLD-3749', '2026-01-26', 'GASTO', '1', '702 - Gastos de SERVICIOS', '3000.00', '0.00', NULL, 'pago de luz');
INSERT INTO `contabilidad_diario` VALUES ('3750', 'OLD-3750', '2026-01-26', 'GASTO', '1', '101 - Efectivo', '0.00', '3000.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('3751', 'OLD-3751', '2026-01-29', 'GASTO', '2', '702 - Gastos de SERVICIOS', '5600.00', '0.00', NULL, 'ETECSA MOVILES');
INSERT INTO `contabilidad_diario` VALUES ('3752', 'OLD-3752', '2026-01-29', 'GASTO', '2', '101 - Efectivo', '0.00', '5600.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('3753', 'OLD-3753', '2026-01-10', 'GASTO', '3', '702 - Gastos de SERVICIOS', '7800.00', '0.00', NULL, 'Impuestos ONAT');
INSERT INTO `contabilidad_diario` VALUES ('3754', 'OLD-3754', '2026-01-10', 'GASTO', '3', '101 - Efectivo', '0.00', '7800.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('3755', 'OLD-3755', '2026-01-15', 'GASTO', '4', '702 - Gastos de SERVICIOS', '8000.00', '0.00', NULL, 'Impuesto 10%');
INSERT INTO `contabilidad_diario` VALUES ('3756', 'OLD-3756', '2026-01-15', 'GASTO', '4', '101 - Efectivo', '0.00', '8000.00', NULL, 'Pago: SERVICIOS');
INSERT INTO `contabilidad_diario` VALUES ('3757', 'OLD-3757', '2026-01-29', 'GASTO', '13', '701 - Gastos de Personal', '1226.00', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3758', 'OLD-3758', '2026-01-29', 'GASTO', '13', '101 - Efectivo', '0.00', '1226.00', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3759', 'OLD-3759', '2026-01-28', 'GASTO', '14', '701 - Gastos de Personal', '665.50', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3760', 'OLD-3760', '2026-01-28', 'GASTO', '14', '101 - Efectivo', '0.00', '665.50', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3761', 'OLD-3761', '2026-01-27', 'GASTO', '15', '701 - Gastos de Personal', '611.50', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3762', 'OLD-3762', '2026-01-27', 'GASTO', '15', '101 - Efectivo', '0.00', '611.50', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3763', 'OLD-3763', '2026-01-26', 'GASTO', '16', '701 - Gastos de Personal', '531.00', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3764', 'OLD-3764', '2026-01-26', 'GASTO', '16', '101 - Efectivo', '0.00', '531.00', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3765', 'OLD-3765', '2026-01-25', 'GASTO', '18', '701 - Gastos de Personal', '1431.50', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3766', 'OLD-3766', '2026-01-25', 'GASTO', '18', '101 - Efectivo', '0.00', '1431.50', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3767', 'OLD-3767', '2026-01-24', 'GASTO', '19', '701 - Gastos de Personal', '934.50', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3768', 'OLD-3768', '2026-01-24', 'GASTO', '19', '101 - Efectivo', '0.00', '934.50', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3769', 'OLD-3769', '2026-01-23', 'GASTO', '20', '701 - Gastos de Personal', '729.00', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3770', 'OLD-3770', '2026-01-23', 'GASTO', '20', '101 - Efectivo', '0.00', '729.00', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3771', 'OLD-3771', '2026-01-30', 'GASTO', '21', '701 - Gastos de Personal', '1770.50', '0.00', NULL, 'Salario eddy 10%');
INSERT INTO `contabilidad_diario` VALUES ('3772', 'OLD-3772', '2026-01-30', 'GASTO', '21', '101 - Efectivo', '0.00', '1770.50', NULL, 'Pago: NOMINA');
INSERT INTO `contabilidad_diario` VALUES ('3773', 'OLD-3773', '2026-01-29', 'COMPRA', '1', '120 - Inventario Mercancías', '8160.00', '0.00', NULL, 'Compra #1 - adrian');
INSERT INTO `contabilidad_diario` VALUES ('3774', 'OLD-3774', '2026-01-29', 'COMPRA', '1', '101 - Efectivo', '0.00', '8160.00', NULL, 'Pago Compra #1');
INSERT INTO `contabilidad_diario` VALUES ('3775', 'OLD-3775', '2026-01-29', 'COMPRA', '2', '120 - Inventario Mercancías', '292.71', '0.00', NULL, 'Compra #2 - ');
INSERT INTO `contabilidad_diario` VALUES ('3776', 'OLD-3776', '2026-01-29', 'COMPRA', '2', '101 - Efectivo', '0.00', '292.71', NULL, 'Pago Compra #2');
INSERT INTO `contabilidad_diario` VALUES ('3777', 'OLD-3777', '2026-01-29', 'COMPRA', '3', '120 - Inventario Mercancías', '1594.00', '0.00', NULL, 'Compra #3 - roly ce');
INSERT INTO `contabilidad_diario` VALUES ('3778', 'OLD-3778', '2026-01-29', 'COMPRA', '3', '101 - Efectivo', '0.00', '1594.00', NULL, 'Pago Compra #3');
INSERT INTO `contabilidad_diario` VALUES ('3779', 'OLD-3779', '2026-01-29', 'COMPRA', '5', '120 - Inventario Mercancías', '6140.00', '0.00', NULL, 'Compra #5 - roly ce');
INSERT INTO `contabilidad_diario` VALUES ('3780', 'OLD-3780', '2026-01-29', 'COMPRA', '5', '101 - Efectivo', '0.00', '6140.00', NULL, 'Pago Compra #5');
INSERT INTO `contabilidad_diario` VALUES ('3781', 'OLD-3781', '2026-01-30', 'COMPRA', '10', '120 - Inventario Mercancías', '6050.00', '0.00', NULL, 'Compra #10 - por error');
INSERT INTO `contabilidad_diario` VALUES ('3782', 'OLD-3782', '2026-01-30', 'COMPRA', '10', '101 - Efectivo', '0.00', '6050.00', NULL, 'Pago Compra #10');
INSERT INTO `contabilidad_diario` VALUES ('3783', 'OLD-3783', '2026-01-29', 'MERMA', '1', '709 - Gastos por Merma', '3240.00', '0.00', NULL, 'Pérdida Merma #1');
INSERT INTO `contabilidad_diario` VALUES ('3784', 'OLD-3784', '2026-01-29', 'MERMA', '1', '120 - Inventario Mercancías', '0.00', '3240.00', NULL, 'Baja por Merma');
INSERT INTO `contabilidad_diario` VALUES ('3785', 'OLD-3785', '2026-01-30', 'MERMA', '2', '709 - Gastos por Merma', '292.71', '0.00', NULL, 'Pérdida Merma #2');
INSERT INTO `contabilidad_diario` VALUES ('3786', 'OLD-3786', '2026-01-30', 'MERMA', '2', '120 - Inventario Mercancías', '0.00', '292.71', NULL, 'Baja por Merma');
INSERT INTO `contabilidad_diario` VALUES ('3787', '20260209-221957-CC19', '2026-02-08', NULL, NULL, '101.01', '7590.00', '0.00', NULL, 'Ingreso Efectivo - Cierre de Caja #19');
INSERT INTO `contabilidad_diario` VALUES ('3788', '20260209-221957-CC19', '2026-02-08', NULL, NULL, '104.01', '8740.00', '0.00', NULL, 'Ingreso Transferencia - Cierre de Caja #19');
INSERT INTO `contabilidad_diario` VALUES ('3789', '20260209-221957-CC19', '2026-02-08', NULL, NULL, '401.01', '0.00', '16330.00', NULL, 'Ventas del Día - Eddy (Cierre de Caja #19)');

DROP TABLE IF EXISTS `contabilidad_gastos`;
CREATE TABLE `contabilidad_gastos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `monto` decimal(12,2) DEFAULT NULL,
  `origen_pago` enum('CAJA','BANCO') DEFAULT 'CAJA',
  `usuario` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `contabilidad_saldos`;
CREATE TABLE `contabilidad_saldos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `caja_fuerte` decimal(12,2) DEFAULT 0.00,
  `banco` decimal(12,2) DEFAULT 0.00,
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `declaraciones_onat`;
CREATE TABLE `declaraciones_onat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `anio` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `tipo_entidad` varchar(20) DEFAULT NULL,
  `ingresos_brutos` decimal(12,2) DEFAULT NULL,
  `costo_ventas` decimal(12,2) DEFAULT NULL,
  `gastos_nomina` decimal(12,2) DEFAULT NULL,
  `gastos_otros` decimal(12,2) DEFAULT NULL,
  `imp_ventas` decimal(12,2) DEFAULT NULL,
  `imp_fuerza` decimal(12,2) DEFAULT NULL,
  `contrib_local` decimal(12,2) DEFAULT NULL,
  `seg_social` decimal(12,2) DEFAULT NULL,
  `seg_social_especial` decimal(12,2) DEFAULT NULL,
  `imp_utilidades` decimal(12,2) DEFAULT NULL,
  `total_pagar` decimal(12,2) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_decl` (`id_empresa`,`anio`,`mes`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `declaraciones_onat` VALUES ('1', '1', '2026', '1', 'MIPYME', '48350.00', '36827.00', '27000.00', '200.00', '4835.00', '1350.00', '483.50', '1350.00', '3240.00', '0.00', '11258.50', '2026-01-30 00:53:02');

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `empresas` VALUES ('1', 'palweb', '1');

DROP TABLE IF EXISTS `facturas`;
CREATE TABLE `facturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_factura` varchar(20) NOT NULL,
  `fecha_emision` datetime NOT NULL,
  `id_ticket_origen` int(11) DEFAULT NULL,
  `cliente_nombre` varchar(150) DEFAULT NULL,
  `cliente_direccion` varchar(255) DEFAULT NULL,
  `cliente_telefono` varchar(50) DEFAULT NULL,
  `mensajero_nombre` varchar(100) DEFAULT NULL,
  `vehiculo` varchar(100) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `creado_por` varchar(100) DEFAULT NULL,
  `estado` enum('ACTIVA','ANULADA') DEFAULT 'ACTIVA',
  `estado_pago` enum('PENDIENTE','PAGADA') DEFAULT 'PENDIENTE',
  `metodo_pago` varchar(50) DEFAULT NULL,
  `fecha_pago` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `facturas` VALUES ('1', '20260209001', '2026-02-08 00:00:00', '20', 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '360.00', '360.00', 'Administrador', 'ACTIVA', 'PAGADA', 'Efectivo', '2026-02-09 21:41:50');
INSERT INTO `facturas` VALUES ('2', '20260209001', '2026-02-08 00:00:00', NULL, 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '0.00', '0.00', 'Administrador', 'ANULADA', 'PENDIENTE', '', NULL);
INSERT INTO `facturas` VALUES ('3', '20260209001', '2026-02-08 00:00:00', '123', 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '4560.00', '4560.00', 'Administrador', 'ACTIVA', 'PENDIENTE', NULL, NULL);
INSERT INTO `facturas` VALUES ('4', '20260209001', '2026-02-08 00:00:00', NULL, 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '0.00', '0.00', 'Administrador', 'ANULADA', 'PENDIENTE', '', NULL);
INSERT INTO `facturas` VALUES ('5', '20260209001', '2026-02-08 00:00:00', NULL, 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '0.00', '0.00', 'Administrador', 'ANULADA', 'PENDIENTE', '', NULL);
INSERT INTO `facturas` VALUES ('6', '20260209001', '2026-02-08 00:00:00', '120', 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '-750.00', '-750.00', 'Administrador', 'ACTIVA', 'PENDIENTE', NULL, NULL);
INSERT INTO `facturas` VALUES ('7', '20260209007', '2026-02-08 00:00:00', NULL, 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '0.00', '0.00', 'Administrador', 'ACTIVA', 'PENDIENTE', NULL, NULL);
INSERT INTO `facturas` VALUES ('8', '20260209008', '2026-02-08 00:00:00', '100', 'la rosa de guadalupe', 'calle $534 entre pez y rayo', '5834985904', 'pepe robert', 'Triciclo Eléctrico', '1000.00', '1000.00', 'Administrador', 'ACTIVA', 'PENDIENTE', NULL, NULL);

DROP TABLE IF EXISTS `facturas_detalle`;
CREATE TABLE `facturas_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_factura` int(11) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `unidad_medida` varchar(20) DEFAULT 'UND',
  `cantidad` decimal(10,2) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `importe` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_factura` (`id_factura`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `facturas_detalle` VALUES ('1', '1', 'Albondigas pqt', 'UND', '1.00', '360.00', '360.00');
INSERT INTO `facturas_detalle` VALUES ('2', '3', 'Cabezote', 'UND', '10.00', '80.00', '800.00');
INSERT INTO `facturas_detalle` VALUES ('3', '3', 'Albondigas pqt', 'UND', '1.00', '360.00', '360.00');
INSERT INTO `facturas_detalle` VALUES ('4', '3', 'Leche condensada', 'UND', '1.00', '520.00', '520.00');
INSERT INTO `facturas_detalle` VALUES ('5', '3', 'Fanguito', 'UND', '3.00', '580.00', '1740.00');
INSERT INTO `facturas_detalle` VALUES ('6', '3', 'Cerveza Esple', 'UND', '4.00', '230.00', '920.00');
INSERT INTO `facturas_detalle` VALUES ('7', '3', 'pqt torticas 6u', 'UND', '1.00', '220.00', '220.00');
INSERT INTO `facturas_detalle` VALUES ('8', '6', 'Croquetas pollo pqt', 'UND', '-5.00', '150.00', '-750.00');
INSERT INTO `facturas_detalle` VALUES ('9', '8', 'Energizante', 'UND', '1.00', '280.00', '280.00');
INSERT INTO `facturas_detalle` VALUES ('10', '8', 'Refresco cola lata 300ml', 'UND', '2.00', '240.00', '480.00');
INSERT INTO `facturas_detalle` VALUES ('11', '8', 'Cerveza La Fria', 'UND', '1.00', '240.00', '240.00');

DROP TABLE IF EXISTS `flujo_caja_mensual`;
CREATE TABLE `flujo_caja_mensual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `concepto_key` varchar(50) NOT NULL,
  `valor` text DEFAULT NULL,
  `id_sucursal` int(11) DEFAULT 1,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_celda` (`fecha`,`concepto_key`,`id_sucursal`)
) ENGINE=InnoDB AUTO_INCREMENT=1901 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `flujo_caja_mensual` VALUES ('1', '2026-02-01', 'ventas_diarias', '0.00', '1', '2026-02-11 17:30:57');
INSERT INTO `flujo_caja_mensual` VALUES ('2', '2026-02-01', 'inv_1', '0.00', '1', '2026-02-12 10:15:40');
INSERT INTO `flujo_caja_mensual` VALUES ('3', '2026-02-01', 'inv_2', '123198.85', '1', '2026-02-12 10:15:40');
INSERT INTO `flujo_caja_mensual` VALUES ('4', '2026-02-01', 'inv_4', '46625.39', '1', '2026-02-12 10:15:40');
INSERT INTO `flujo_caja_mensual` VALUES ('5', '2026-02-01', 'inv_3', '0.00', '1', '2026-02-11 17:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('6', '2026-02-01', 'inv_6', '0.00', '1', '2026-02-11 17:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('7', '2026-02-01', 'inv_5', '0.00', '1', '2026-02-11 17:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('8', '2026-02-02', 'inv_2', '123198.85', '1', '2026-02-12 10:15:44');
INSERT INTO `flujo_caja_mensual` VALUES ('9', '2026-02-02', 'ventas_diarias', '0.00', '1', '2026-02-11 17:31:14');
INSERT INTO `flujo_caja_mensual` VALUES ('10', '2026-02-02', 'inv_4', '75424.82', '1', '2026-02-12 10:15:44');
INSERT INTO `flujo_caja_mensual` VALUES ('11', '2026-02-02', 'inv_1', '0.00', '1', '2026-02-12 10:15:44');
INSERT INTO `flujo_caja_mensual` VALUES ('12', '2026-02-02', 'inv_3', '0.00', '1', '2026-02-11 17:25:47');
INSERT INTO `flujo_caja_mensual` VALUES ('13', '2026-02-02', 'inv_5', '0.00', '1', '2026-02-11 17:25:47');
INSERT INTO `flujo_caja_mensual` VALUES ('14', '2026-02-02', 'inv_6', '0.00', '1', '2026-02-11 17:25:47');
INSERT INTO `flujo_caja_mensual` VALUES ('15', '2026-02-03', 'ventas_diarias', '0.00', '1', '2026-02-12 08:15:19');
INSERT INTO `flujo_caja_mensual` VALUES ('16', '2026-02-03', 'inv_4', '90794.82', '1', '2026-02-12 10:15:48');
INSERT INTO `flujo_caja_mensual` VALUES ('17', '2026-02-03', 'inv_3', '0.00', '1', '2026-02-11 17:26:03');
INSERT INTO `flujo_caja_mensual` VALUES ('18', '2026-02-03', 'inv_2', '123198.85', '1', '2026-02-12 10:15:48');
INSERT INTO `flujo_caja_mensual` VALUES ('19', '2026-02-03', 'inv_1', '0.00', '1', '2026-02-12 10:15:48');
INSERT INTO `flujo_caja_mensual` VALUES ('20', '2026-02-03', 'inv_5', '0.00', '1', '2026-02-11 17:26:03');
INSERT INTO `flujo_caja_mensual` VALUES ('21', '2026-02-03', 'inv_6', '0.00', '1', '2026-02-11 17:26:03');
INSERT INTO `flujo_caja_mensual` VALUES ('22', '2026-02-04', 'inv_1', '0.00', '1', '2026-02-12 10:15:51');
INSERT INTO `flujo_caja_mensual` VALUES ('23', '2026-02-04', 'inv_4', '62007.00', '1', '2026-02-12 10:15:51');
INSERT INTO `flujo_caja_mensual` VALUES ('24', '2026-02-04', 'ventas_diarias', '18890.00', '1', '2026-02-12 07:40:50');
INSERT INTO `flujo_caja_mensual` VALUES ('25', '2026-02-04', 'inv_5', '0.00', '1', '2026-02-11 17:26:27');
INSERT INTO `flujo_caja_mensual` VALUES ('26', '2026-02-04', 'inv_3', '0.00', '1', '2026-02-11 17:26:27');
INSERT INTO `flujo_caja_mensual` VALUES ('27', '2026-02-04', 'inv_2', '123198.85', '1', '2026-02-12 10:15:51');
INSERT INTO `flujo_caja_mensual` VALUES ('28', '2026-02-04', 'inv_6', '0.00', '1', '2026-02-11 17:26:27');
INSERT INTO `flujo_caja_mensual` VALUES ('29', '2026-02-05', 'inv_3', '0.00', '1', '2026-02-11 17:26:31');
INSERT INTO `flujo_caja_mensual` VALUES ('30', '2026-02-05', 'inv_4', '64017.00', '1', '2026-02-12 10:15:55');
INSERT INTO `flujo_caja_mensual` VALUES ('31', '2026-02-05', 'ventas_diarias', '9080.00', '1', '2026-02-12 07:40:38');
INSERT INTO `flujo_caja_mensual` VALUES ('32', '2026-02-05', 'inv_2', '123198.85', '1', '2026-02-12 10:15:55');
INSERT INTO `flujo_caja_mensual` VALUES ('33', '2026-02-05', 'inv_1', '0.00', '1', '2026-02-12 10:15:55');
INSERT INTO `flujo_caja_mensual` VALUES ('34', '2026-02-05', 'inv_5', '0.00', '1', '2026-02-11 17:26:31');
INSERT INTO `flujo_caja_mensual` VALUES ('35', '2026-02-05', 'inv_6', '0.00', '1', '2026-02-11 17:26:31');
INSERT INTO `flujo_caja_mensual` VALUES ('36', '2026-02-06', 'inv_2', '123198.85', '1', '2026-02-12 10:15:58');
INSERT INTO `flujo_caja_mensual` VALUES ('37', '2026-02-06', 'inv_1', '0.00', '1', '2026-02-12 10:15:58');
INSERT INTO `flujo_caja_mensual` VALUES ('38', '2026-02-06', 'ventas_diarias', '15580.00', '1', '2026-02-12 19:41:20');
INSERT INTO `flujo_caja_mensual` VALUES ('39', '2026-02-06', 'inv_3', '0.00', '1', '2026-02-11 17:26:35');
INSERT INTO `flujo_caja_mensual` VALUES ('40', '2026-02-06', 'inv_5', '0.00', '1', '2026-02-11 17:26:35');
INSERT INTO `flujo_caja_mensual` VALUES ('41', '2026-02-06', 'inv_4', '67621.00', '1', '2026-02-12 10:15:58');
INSERT INTO `flujo_caja_mensual` VALUES ('42', '2026-02-06', 'inv_6', '0.00', '1', '2026-02-11 17:26:35');
INSERT INTO `flujo_caja_mensual` VALUES ('43', '2026-02-07', 'inv_3', '0.00', '1', '2026-02-11 17:26:39');
INSERT INTO `flujo_caja_mensual` VALUES ('44', '2026-02-07', 'inv_4', '38007.66', '1', '2026-02-13 12:28:43');
INSERT INTO `flujo_caja_mensual` VALUES ('45', '2026-02-07', 'inv_5', '0.00', '1', '2026-02-11 17:26:39');
INSERT INTO `flujo_caja_mensual` VALUES ('46', '2026-02-07', 'ventas_diarias', '21120.00', '1', '2026-02-11 19:36:35');
INSERT INTO `flujo_caja_mensual` VALUES ('47', '2026-02-07', 'inv_1', '0.00', '1', '2026-02-12 10:16:01');
INSERT INTO `flujo_caja_mensual` VALUES ('48', '2026-02-07', 'inv_2', '123198.85', '1', '2026-02-12 10:16:01');
INSERT INTO `flujo_caja_mensual` VALUES ('49', '2026-02-07', 'inv_6', '0.00', '1', '2026-02-11 17:26:39');
INSERT INTO `flujo_caja_mensual` VALUES ('64', '2026-02-08', 'inv_2', '123198.85', '1', '2026-02-12 10:16:03');
INSERT INTO `flujo_caja_mensual` VALUES ('65', '2026-02-08', 'inv_4', '36103.24', '1', '2026-02-13 12:28:47');
INSERT INTO `flujo_caja_mensual` VALUES ('66', '2026-02-08', 'inv_5', '0.00', '1', '2026-02-11 17:31:18');
INSERT INTO `flujo_caja_mensual` VALUES ('67', '2026-02-08', 'ventas_diarias', '13870.00', '1', '2026-02-12 19:41:14');
INSERT INTO `flujo_caja_mensual` VALUES ('68', '2026-02-08', 'inv_1', '0.00', '1', '2026-02-12 10:16:03');
INSERT INTO `flujo_caja_mensual` VALUES ('69', '2026-02-08', 'inv_3', '0.00', '1', '2026-02-11 17:31:18');
INSERT INTO `flujo_caja_mensual` VALUES ('70', '2026-02-08', 'inv_6', '0.00', '1', '2026-02-11 17:31:18');
INSERT INTO `flujo_caja_mensual` VALUES ('71', '2026-02-09', 'inv_3', '0.00', '1', '2026-02-11 17:31:22');
INSERT INTO `flujo_caja_mensual` VALUES ('72', '2026-02-09', 'ventas_diarias', '6845.00', '1', '2026-02-12 19:41:01');
INSERT INTO `flujo_caja_mensual` VALUES ('73', '2026-02-09', 'inv_2', '123198.85', '1', '2026-02-12 10:16:07');
INSERT INTO `flujo_caja_mensual` VALUES ('74', '2026-02-09', 'inv_5', '0.00', '1', '2026-02-11 17:31:22');
INSERT INTO `flujo_caja_mensual` VALUES ('75', '2026-02-09', 'inv_4', '31109.24', '1', '2026-02-13 12:28:50');
INSERT INTO `flujo_caja_mensual` VALUES ('76', '2026-02-09', 'inv_1', '0.00', '1', '2026-02-12 10:16:07');
INSERT INTO `flujo_caja_mensual` VALUES ('77', '2026-02-09', 'inv_6', '0.00', '1', '2026-02-11 17:31:22');
INSERT INTO `flujo_caja_mensual` VALUES ('78', '2026-02-10', 'ventas_diarias', '8380.00', '1', '2026-02-12 19:41:04');
INSERT INTO `flujo_caja_mensual` VALUES ('79', '2026-02-10', 'inv_3', '0.00', '1', '2026-02-11 17:31:27');
INSERT INTO `flujo_caja_mensual` VALUES ('80', '2026-02-10', 'inv_1', '0.00', '1', '2026-02-12 10:16:09');
INSERT INTO `flujo_caja_mensual` VALUES ('81', '2026-02-10', 'inv_5', '0.00', '1', '2026-02-11 17:31:27');
INSERT INTO `flujo_caja_mensual` VALUES ('82', '2026-02-10', 'inv_4', '33384.10', '1', '2026-02-13 12:28:53');
INSERT INTO `flujo_caja_mensual` VALUES ('83', '2026-02-10', 'inv_2', '123198.85', '1', '2026-02-12 10:16:09');
INSERT INTO `flujo_caja_mensual` VALUES ('84', '2026-02-10', 'inv_6', '0.00', '1', '2026-02-11 17:31:27');
INSERT INTO `flujo_caja_mensual` VALUES ('85', '2026-02-11', 'inv_4', '32954.10', '1', '2026-02-13 12:41:36');
INSERT INTO `flujo_caja_mensual` VALUES ('86', '2026-02-11', 'ventas_diarias', '3350.00', '1', '2026-02-13 12:41:36');
INSERT INTO `flujo_caja_mensual` VALUES ('87', '2026-02-11', 'inv_5', '0.00', '1', '2026-02-11 17:31:55');
INSERT INTO `flujo_caja_mensual` VALUES ('88', '2026-02-11', 'inv_1', '-2570.00', '1', '2026-02-13 12:41:36');
INSERT INTO `flujo_caja_mensual` VALUES ('89', '2026-02-11', 'inv_2', '123198.85', '1', '2026-02-12 10:16:36');
INSERT INTO `flujo_caja_mensual` VALUES ('90', '2026-02-11', 'inv_3', '0.00', '1', '2026-02-11 17:31:55');
INSERT INTO `flujo_caja_mensual` VALUES ('91', '2026-02-11', 'inv_6', '0.00', '1', '2026-02-11 17:31:55');
INSERT INTO `flujo_caja_mensual` VALUES ('92', '2026-02-12', 'ventas_diarias', '0.00', '1', '2026-02-11 17:31:59');
INSERT INTO `flujo_caja_mensual` VALUES ('93', '2026-02-12', 'inv_3', '0.00', '1', '2026-02-11 17:31:59');
INSERT INTO `flujo_caja_mensual` VALUES ('94', '2026-02-12', 'inv_5', '0.00', '1', '2026-02-11 17:31:59');
INSERT INTO `flujo_caja_mensual` VALUES ('95', '2026-02-12', 'inv_4', '33246.81', '1', '2026-02-13 12:41:32');
INSERT INTO `flujo_caja_mensual` VALUES ('96', '2026-02-12', 'inv_2', '123198.85', '1', '2026-02-12 11:00:44');
INSERT INTO `flujo_caja_mensual` VALUES ('97', '2026-02-12', 'inv_1', '-2570.00', '1', '2026-02-13 12:41:32');
INSERT INTO `flujo_caja_mensual` VALUES ('98', '2026-02-12', 'inv_6', '0.00', '1', '2026-02-11 17:31:59');
INSERT INTO `flujo_caja_mensual` VALUES ('561', '2026-02-13', 'inv_2', '123198.85', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('562', '2026-02-13', 'inv_5', '0.00', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('563', '2026-02-13', 'ventas_diarias', '0.00', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('564', '2026-02-13', 'inv_1', '0.00', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('565', '2026-02-13', 'inv_4', '34446.81', '1', '2026-02-13 12:41:28');
INSERT INTO `flujo_caja_mensual` VALUES ('566', '2026-02-13', 'inv_3', '0.00', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('567', '2026-02-13', 'inv_6', '0.00', '1', '2026-02-12 10:16:16');
INSERT INTO `flujo_caja_mensual` VALUES ('568', '2026-02-14', 'ventas_diarias', '0.00', '1', '2026-02-12 10:16:18');
INSERT INTO `flujo_caja_mensual` VALUES ('569', '2026-02-14', 'inv_3', '0.00', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('570', '2026-02-14', 'inv_2', '123198.85', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('571', '2026-02-14', 'inv_4', '36168.24', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('572', '2026-02-14', 'inv_5', '0.00', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('573', '2026-02-14', 'inv_1', '0.00', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('574', '2026-02-14', 'inv_6', '0.00', '1', '2026-02-12 10:16:19');
INSERT INTO `flujo_caja_mensual` VALUES ('638', '2026-02-12', 'caja', '13395.00', '1', '2026-02-12 10:59:45');
INSERT INTO `flujo_caja_mensual` VALUES ('683', '2026-02-12', 'otros_ing', '6200.00', '1', '2026-02-12 19:41:55');
INSERT INTO `flujo_caja_mensual` VALUES ('684', '2026-02-12', 'compras', '9000.00', '1', '2026-02-12 19:42:33');
INSERT INTO `flujo_caja_mensual` VALUES ('687', '2026-02-12', 'caja_ext', '6200.00', '1', '2026-02-12 19:45:58');
INSERT INTO `flujo_caja_mensual` VALUES ('716', '2026-02-13', 'otros_ing', '4860.00', '1', '2026-02-13 12:29:23');
INSERT INTO `flujo_caja_mensual` VALUES ('759', '2026-02-01', 'inv_suc', '56802.40', '4', '2026-02-13 12:47:23');
INSERT INTO `flujo_caja_mensual` VALUES ('760', '2026-02-01', 'ventas_diarias', '11180.00', '4', '2026-02-13 12:47:23');
INSERT INTO `flujo_caja_mensual` VALUES ('761', '2026-02-02', 'ventas_diarias', '5440.00', '4', '2026-02-13 12:47:23');
INSERT INTO `flujo_caja_mensual` VALUES ('762', '2026-02-02', 'inv_suc', '63591.40', '4', '2026-02-13 12:47:23');
INSERT INTO `flujo_caja_mensual` VALUES ('763', '2026-02-03', 'ventas_diarias', '3980.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('764', '2026-02-03', 'inv_suc', '77200.51', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('765', '2026-02-04', 'ventas_diarias', '18330.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('766', '2026-02-04', 'inv_suc', '54698.12', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('767', '2026-02-05', 'ventas_diarias', '9080.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('768', '2026-02-05', 'inv_suc', '51456.59', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('769', '2026-02-06', 'inv_suc', '53776.95', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('770', '2026-02-06', 'ventas_diarias', '15580.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('771', '2026-02-07', 'ventas_diarias', '21120.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('772', '2026-02-07', 'inv_suc', '38007.66', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('773', '2026-02-08', 'ventas_diarias', '13870.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('774', '2026-02-08', 'inv_suc', '36103.24', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('775', '2026-02-09', 'ventas_diarias', '6845.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('776', '2026-02-09', 'inv_suc', '31109.24', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('777', '2026-02-10', 'ventas_diarias', '8380.00', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('778', '2026-02-10', 'inv_suc', '33384.10', '4', '2026-02-13 12:47:24');
INSERT INTO `flujo_caja_mensual` VALUES ('779', '2026-02-11', 'ventas_diarias', '3350.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('780', '2026-02-11', 'inv_suc', '32954.10', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('781', '2026-02-12', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('782', '2026-02-12', 'inv_suc', '33246.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('783', '2026-02-13', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('784', '2026-02-13', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('785', '2026-02-14', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('786', '2026-02-14', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('787', '2026-02-15', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('788', '2026-02-15', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('789', '2026-02-16', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('790', '2026-02-16', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('791', '2026-02-17', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('792', '2026-02-17', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('793', '2026-02-18', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('794', '2026-02-18', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('795', '2026-02-19', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('796', '2026-02-19', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:25');
INSERT INTO `flujo_caja_mensual` VALUES ('797', '2026-02-20', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('798', '2026-02-20', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('799', '2026-02-21', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('800', '2026-02-21', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('801', '2026-02-22', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('802', '2026-02-22', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('803', '2026-02-23', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('804', '2026-02-23', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('805', '2026-02-24', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('806', '2026-02-24', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('807', '2026-02-25', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('808', '2026-02-25', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('809', '2026-02-26', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('810', '2026-02-26', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('811', '2026-02-27', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('812', '2026-02-27', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('813', '2026-02-28', 'ventas_diarias', '0.00', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('814', '2026-02-28', 'inv_suc', '34446.81', '4', '2026-02-13 12:47:26');
INSERT INTO `flujo_caja_mensual` VALUES ('815', '2026-02-12', 'otros_ing', '11300.00', '4', '2026-02-13 12:48:35');
INSERT INTO `flujo_caja_mensual` VALUES ('816', '2026-02-13', 'otros_ing', '4860.00', '4', '2026-02-13 12:49:00');
INSERT INTO `flujo_caja_mensual` VALUES ('817', '2026-02-01', 'inv_5', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('818', '2026-02-01', 'ventas_info', '11180.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('819', '2026-02-01', 'inv_3', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('820', '2026-02-01', 'inv_1', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('821', '2026-02-01', 'inv_4', '56802.40', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('822', '2026-02-01', 'inv_2', '123198.85', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('823', '2026-02-01', 'inv_6', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('824', '2026-02-02', 'ventas_info', '5440.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('825', '2026-02-02', 'inv_1', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('826', '2026-02-02', 'inv_2', '123198.85', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('827', '2026-02-02', 'inv_4', '63591.40', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('828', '2026-02-02', 'inv_3', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('829', '2026-02-02', 'inv_5', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('830', '2026-02-02', 'inv_6', '0.00', '4', '2026-02-13 12:53:32');
INSERT INTO `flujo_caja_mensual` VALUES ('831', '2026-02-03', 'inv_1', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('832', '2026-02-03', 'ventas_info', '3980.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('833', '2026-02-03', 'inv_2', '123198.85', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('834', '2026-02-03', 'inv_5', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('835', '2026-02-03', 'inv_3', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('836', '2026-02-03', 'inv_4', '77200.51', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('837', '2026-02-03', 'inv_6', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('838', '2026-02-04', 'ventas_info', '18330.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('839', '2026-02-04', 'inv_1', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('840', '2026-02-04', 'inv_3', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('841', '2026-02-04', 'inv_2', '123198.85', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('842', '2026-02-04', 'inv_5', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('843', '2026-02-04', 'inv_4', '54698.12', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('844', '2026-02-04', 'inv_6', '0.00', '4', '2026-02-13 12:53:33');
INSERT INTO `flujo_caja_mensual` VALUES ('845', '2026-02-05', 'ventas_info', '9080.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('846', '2026-02-05', 'inv_1', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('847', '2026-02-05', 'inv_5', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('848', '2026-02-05', 'inv_2', '123198.85', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('849', '2026-02-05', 'inv_3', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('850', '2026-02-05', 'inv_4', '51456.59', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('851', '2026-02-05', 'inv_6', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('852', '2026-02-06', 'ventas_info', '15580.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('853', '2026-02-06', 'inv_1', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('854', '2026-02-06', 'inv_4', '53776.95', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('855', '2026-02-06', 'inv_2', '123198.85', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('856', '2026-02-06', 'inv_5', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('857', '2026-02-06', 'inv_3', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('858', '2026-02-06', 'inv_6', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('859', '2026-02-07', 'inv_1', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('860', '2026-02-07', 'ventas_info', '21120.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('861', '2026-02-07', 'inv_2', '123198.85', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('862', '2026-02-07', 'inv_3', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('863', '2026-02-07', 'inv_5', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('864', '2026-02-07', 'inv_4', '38007.66', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('865', '2026-02-07', 'inv_6', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('866', '2026-02-08', 'ventas_info', '13870.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('867', '2026-02-08', 'inv_3', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('868', '2026-02-08', 'inv_5', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('869', '2026-02-08', 'inv_1', '0.00', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('870', '2026-02-08', 'inv_2', '123198.85', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('871', '2026-02-08', 'inv_4', '36103.24', '4', '2026-02-13 12:53:34');
INSERT INTO `flujo_caja_mensual` VALUES ('872', '2026-02-08', 'inv_6', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('873', '2026-02-09', 'ventas_info', '6845.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('874', '2026-02-09', 'inv_1', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('875', '2026-02-09', 'inv_5', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('876', '2026-02-09', 'inv_2', '123198.85', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('877', '2026-02-09', 'inv_4', '31109.24', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('878', '2026-02-09', 'inv_3', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('879', '2026-02-09', 'inv_6', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('880', '2026-02-10', 'inv_1', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('881', '2026-02-10', 'inv_2', '123198.85', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('882', '2026-02-10', 'ventas_info', '8380.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('883', '2026-02-10', 'inv_3', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('884', '2026-02-10', 'inv_5', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('885', '2026-02-10', 'inv_4', '33384.10', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('886', '2026-02-10', 'inv_6', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('887', '2026-02-11', 'inv_5', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('888', '2026-02-11', 'inv_2', '123198.85', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('889', '2026-02-11', 'ventas_info', '3350.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('890', '2026-02-11', 'inv_1', '-2570.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('891', '2026-02-11', 'inv_3', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('892', '2026-02-11', 'inv_4', '32954.10', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('893', '2026-02-11', 'inv_6', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('894', '2026-02-12', 'inv_4', '33246.81', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('895', '2026-02-12', 'ventas_info', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('896', '2026-02-12', 'inv_1', '-2570.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('897', '2026-02-12', 'inv_3', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('898', '2026-02-12', 'inv_5', '0.00', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('899', '2026-02-12', 'inv_2', '123198.85', '4', '2026-02-13 12:53:35');
INSERT INTO `flujo_caja_mensual` VALUES ('900', '2026-02-12', 'inv_6', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('901', '2026-02-13', 'ventas_info', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('902', '2026-02-13', 'inv_2', '123198.85', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('903', '2026-02-13', 'inv_3', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('904', '2026-02-13', 'inv_1', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('905', '2026-02-13', 'inv_4', '34446.81', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('906', '2026-02-13', 'inv_5', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('907', '2026-02-13', 'inv_6', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('908', '2026-02-14', 'inv_4', '34446.81', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('909', '2026-02-14', 'inv_2', '123198.85', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('910', '2026-02-14', 'inv_1', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('911', '2026-02-14', 'ventas_info', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('912', '2026-02-14', 'inv_3', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('913', '2026-02-14', 'inv_5', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('914', '2026-02-14', 'inv_6', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('915', '2026-02-15', 'inv_1', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('916', '2026-02-15', 'ventas_info', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('917', '2026-02-15', 'inv_2', '123198.85', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('918', '2026-02-15', 'inv_5', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('919', '2026-02-15', 'inv_4', '34446.81', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('920', '2026-02-15', 'inv_3', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('921', '2026-02-15', 'inv_6', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('922', '2026-02-16', 'inv_1', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('923', '2026-02-16', 'ventas_info', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('924', '2026-02-16', 'inv_5', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('925', '2026-02-16', 'inv_2', '123198.85', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('926', '2026-02-16', 'inv_4', '34446.81', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('927', '2026-02-16', 'inv_3', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('928', '2026-02-16', 'inv_6', '0.00', '4', '2026-02-13 12:53:36');
INSERT INTO `flujo_caja_mensual` VALUES ('929', '2026-02-17', 'inv_1', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('930', '2026-02-17', 'ventas_info', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('931', '2026-02-17', 'inv_5', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('932', '2026-02-17', 'inv_4', '34446.81', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('933', '2026-02-17', 'inv_2', '123198.85', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('934', '2026-02-17', 'inv_3', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('935', '2026-02-17', 'inv_6', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('936', '2026-02-18', 'inv_5', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('937', '2026-02-18', 'inv_3', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('938', '2026-02-18', 'ventas_info', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('939', '2026-02-18', 'inv_4', '34446.81', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('940', '2026-02-18', 'inv_1', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('941', '2026-02-18', 'inv_2', '123198.85', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('942', '2026-02-18', 'inv_6', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('943', '2026-02-19', 'ventas_info', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('944', '2026-02-19', 'inv_2', '123198.85', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('945', '2026-02-19', 'inv_1', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('946', '2026-02-19', 'inv_4', '34446.81', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('947', '2026-02-19', 'inv_5', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('948', '2026-02-19', 'inv_3', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('949', '2026-02-19', 'inv_6', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('950', '2026-02-20', 'inv_4', '34446.81', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('951', '2026-02-20', 'inv_5', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('952', '2026-02-20', 'ventas_info', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('953', '2026-02-20', 'inv_3', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('954', '2026-02-20', 'inv_1', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('955', '2026-02-20', 'inv_2', '123198.85', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('956', '2026-02-20', 'inv_6', '0.00', '4', '2026-02-13 12:53:37');
INSERT INTO `flujo_caja_mensual` VALUES ('957', '2026-02-21', 'ventas_info', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('958', '2026-02-21', 'inv_4', '34446.81', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('959', '2026-02-21', 'inv_1', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('960', '2026-02-21', 'inv_3', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('961', '2026-02-21', 'inv_5', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('962', '2026-02-21', 'inv_2', '123198.85', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('963', '2026-02-21', 'inv_6', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('964', '2026-02-22', 'ventas_info', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('965', '2026-02-22', 'inv_4', '34446.81', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('966', '2026-02-22', 'inv_1', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('967', '2026-02-22', 'inv_2', '123198.85', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('968', '2026-02-22', 'inv_5', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('969', '2026-02-22', 'inv_3', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('970', '2026-02-22', 'inv_6', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('971', '2026-02-23', 'inv_5', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('972', '2026-02-23', 'ventas_info', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('973', '2026-02-23', 'inv_3', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('974', '2026-02-23', 'inv_1', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('975', '2026-02-23', 'inv_2', '123198.85', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('976', '2026-02-23', 'inv_4', '34446.81', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('977', '2026-02-23', 'inv_6', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('978', '2026-02-24', 'ventas_info', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('979', '2026-02-24', 'inv_4', '34446.81', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('980', '2026-02-24', 'inv_1', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('981', '2026-02-24', 'inv_5', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('982', '2026-02-24', 'inv_3', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('983', '2026-02-24', 'inv_2', '123198.85', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('984', '2026-02-24', 'inv_6', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('985', '2026-02-25', 'ventas_info', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('986', '2026-02-25', 'inv_1', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('987', '2026-02-25', 'inv_4', '34446.81', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('988', '2026-02-25', 'inv_5', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('989', '2026-02-25', 'inv_3', '0.00', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('990', '2026-02-25', 'inv_2', '123198.85', '4', '2026-02-13 12:53:38');
INSERT INTO `flujo_caja_mensual` VALUES ('991', '2026-02-25', 'inv_6', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('992', '2026-02-26', 'ventas_info', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('993', '2026-02-26', 'inv_4', '34446.81', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('994', '2026-02-26', 'inv_1', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('995', '2026-02-26', 'inv_5', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('996', '2026-02-26', 'inv_3', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('997', '2026-02-26', 'inv_2', '123198.85', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('998', '2026-02-26', 'inv_6', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('999', '2026-02-27', 'ventas_info', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1000', '2026-02-27', 'inv_1', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1001', '2026-02-27', 'inv_3', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1002', '2026-02-27', 'inv_5', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1003', '2026-02-27', 'inv_4', '34446.81', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1004', '2026-02-27', 'inv_2', '123198.85', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1005', '2026-02-27', 'inv_6', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1006', '2026-02-28', 'ventas_info', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1007', '2026-02-28', 'inv_2', '123198.85', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1008', '2026-02-28', 'inv_1', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1009', '2026-02-28', 'inv_4', '34446.81', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1010', '2026-02-28', 'inv_5', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1011', '2026-02-28', 'inv_3', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1012', '2026-02-28', 'inv_6', '0.00', '4', '2026-02-13 12:53:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1013', '2026-02-12', 'costos', '9000.00', '4', '2026-02-13 12:54:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1210', '2026-02-01', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1211', '2026-02-01', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1212', '2026-02-01', 'ventas_suc_4', '11180.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1213', '2026-02-01', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1214', '2026-02-01', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1216', '2026-02-01', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1222', '2026-02-02', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1223', '2026-02-02', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1224', '2026-02-02', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1225', '2026-02-02', 'ventas_suc_4', '5440.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1226', '2026-02-02', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1227', '2026-02-02', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1234', '2026-02-03', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1235', '2026-02-03', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1236', '2026-02-03', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1237', '2026-02-03', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1238', '2026-02-03', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1239', '2026-02-03', 'ventas_suc_4', '3980.00', '4', '2026-02-14 09:25:39');
INSERT INTO `flujo_caja_mensual` VALUES ('1246', '2026-02-04', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1247', '2026-02-04', 'ventas_suc_4', '18330.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1248', '2026-02-04', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1249', '2026-02-04', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1250', '2026-02-04', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1251', '2026-02-04', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1258', '2026-02-05', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1259', '2026-02-05', 'ventas_suc_4', '9080.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1260', '2026-02-05', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1261', '2026-02-05', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1262', '2026-02-05', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1263', '2026-02-05', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1270', '2026-02-06', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1271', '2026-02-06', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1272', '2026-02-06', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1273', '2026-02-06', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1274', '2026-02-06', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1275', '2026-02-06', 'ventas_suc_4', '15580.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1282', '2026-02-07', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1283', '2026-02-07', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1284', '2026-02-07', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1285', '2026-02-07', 'ventas_suc_4', '21120.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1286', '2026-02-07', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1287', '2026-02-07', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1294', '2026-02-08', 'ventas_suc_4', '13870.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1295', '2026-02-08', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1296', '2026-02-08', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1297', '2026-02-08', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1298', '2026-02-08', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1299', '2026-02-08', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:40');
INSERT INTO `flujo_caja_mensual` VALUES ('1306', '2026-02-09', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1307', '2026-02-09', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1308', '2026-02-09', 'ventas_suc_4', '6845.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1309', '2026-02-09', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1310', '2026-02-09', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1311', '2026-02-09', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1318', '2026-02-10', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1319', '2026-02-10', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1320', '2026-02-10', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1321', '2026-02-10', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1322', '2026-02-10', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1323', '2026-02-10', 'ventas_suc_4', '8380.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1330', '2026-02-11', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1331', '2026-02-11', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1332', '2026-02-11', 'ventas_suc_4', '3350.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1333', '2026-02-11', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1334', '2026-02-11', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1335', '2026-02-11', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1342', '2026-02-12', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1343', '2026-02-12', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1344', '2026-02-12', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1345', '2026-02-12', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1346', '2026-02-12', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1347', '2026-02-12', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:41');
INSERT INTO `flujo_caja_mensual` VALUES ('1354', '2026-02-13', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1355', '2026-02-13', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1356', '2026-02-13', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1357', '2026-02-13', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1358', '2026-02-13', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1359', '2026-02-13', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1366', '2026-02-14', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1367', '2026-02-14', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1368', '2026-02-14', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1369', '2026-02-14', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1370', '2026-02-14', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1371', '2026-02-14', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1378', '2026-02-15', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1379', '2026-02-15', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1380', '2026-02-15', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1381', '2026-02-15', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1382', '2026-02-15', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1383', '2026-02-15', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1390', '2026-02-16', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1391', '2026-02-16', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1392', '2026-02-16', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1393', '2026-02-16', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1394', '2026-02-16', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1395', '2026-02-16', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:42');
INSERT INTO `flujo_caja_mensual` VALUES ('1402', '2026-02-17', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1403', '2026-02-17', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1404', '2026-02-17', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1405', '2026-02-17', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1406', '2026-02-17', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1407', '2026-02-17', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1414', '2026-02-18', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1415', '2026-02-18', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1416', '2026-02-18', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1417', '2026-02-18', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1418', '2026-02-18', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1419', '2026-02-18', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1426', '2026-02-19', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1427', '2026-02-19', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1428', '2026-02-19', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1429', '2026-02-19', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1430', '2026-02-19', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1431', '2026-02-19', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1438', '2026-02-20', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1439', '2026-02-20', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1440', '2026-02-20', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1441', '2026-02-20', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1442', '2026-02-20', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1443', '2026-02-20', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:43');
INSERT INTO `flujo_caja_mensual` VALUES ('1450', '2026-02-21', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1451', '2026-02-21', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1452', '2026-02-21', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1453', '2026-02-21', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1454', '2026-02-21', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1455', '2026-02-21', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1462', '2026-02-22', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1463', '2026-02-22', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1464', '2026-02-22', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1465', '2026-02-22', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1466', '2026-02-22', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1467', '2026-02-22', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1474', '2026-02-23', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1475', '2026-02-23', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1476', '2026-02-23', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1477', '2026-02-23', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1478', '2026-02-23', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1479', '2026-02-23', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1486', '2026-02-24', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1487', '2026-02-24', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1488', '2026-02-24', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1489', '2026-02-24', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1490', '2026-02-24', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1491', '2026-02-24', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:44');
INSERT INTO `flujo_caja_mensual` VALUES ('1498', '2026-02-25', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1499', '2026-02-25', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1500', '2026-02-25', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1501', '2026-02-25', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1502', '2026-02-25', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1503', '2026-02-25', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1510', '2026-02-26', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1511', '2026-02-26', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1512', '2026-02-26', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1513', '2026-02-26', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1514', '2026-02-26', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1515', '2026-02-26', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1522', '2026-02-27', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1523', '2026-02-27', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1524', '2026-02-27', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1525', '2026-02-27', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1526', '2026-02-27', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1527', '2026-02-27', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1534', '2026-02-28', 'ventas_suc_2', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1535', '2026-02-28', 'ventas_suc_1', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1536', '2026-02-28', 'ventas_suc_5', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1537', '2026-02-28', 'ventas_suc_3', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1538', '2026-02-28', 'ventas_suc_6', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1539', '2026-02-28', 'ventas_suc_4', '0.00', '4', '2026-02-14 09:25:45');
INSERT INTO `flujo_caja_mensual` VALUES ('1882', '2026-02-14', 'recaudacion_marinero', '3805.00', '4', '2026-02-14 10:01:48');
INSERT INTO `flujo_caja_mensual` VALUES ('1883', '2026-02-14', 'caja', '2925', '4', '2026-02-14 16:00:47');
INSERT INTO `flujo_caja_mensual` VALUES ('1888', '2026-02-14', 'otros_ing', '[{\"monto\":120,\"nota\":\"marinero\\n\"},{\"monto\":680,\"nota\":\"azucar\"}]', '4', '2026-02-14 10:07:18');
INSERT INTO `flujo_caja_mensual` VALUES ('1889', '2026-02-13', 'costos', '[{\"monto\":5900,\"nota\":\"10 azucar\"},{\"monto\":23220,\"nota\":\"cerveza,whiskey, energizante adrian\"},{\"monto\":1150,\"nota\":\"aceite\"}]', '4', '2026-02-14 10:08:37');
INSERT INTO `flujo_caja_mensual` VALUES ('1892', '2026-02-14', 'recaudacion_magnolia', '15235', '4', '2026-02-14 15:45:16');
INSERT INTO `flujo_caja_mensual` VALUES ('1893', '2026-02-14', 'costos', '[{\"monto\":2700,\"nota\":\"huevos\"}]', '4', '2026-02-14 15:56:30');

DROP TABLE IF EXISTS `gastos_fijos`;
CREATE TABLE `gastos_fijos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `concepto` varchar(150) NOT NULL,
  `monto_estimado` decimal(10,2) DEFAULT 0.00,
  `dia_pago_sugerido` int(11) DEFAULT 1,
  `categoria` varchar(50) DEFAULT 'General',
  `activo` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `gastos_historial`;
CREATE TABLE `gastos_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `concepto` varchar(150) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `id_usuario` varchar(50) DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `tipo` enum('VARIABLE','FIJO') DEFAULT 'VARIABLE',
  `id_sucursal` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_gastos_sucursal` (`id_sucursal`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gastos_historial` VALUES ('1', '2026-01-26', 'pago de luz', '3000.00', 'SERVICIOS', 'Admin', NULL, 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('2', '2026-01-29', 'ETECSA MOVILES', '5600.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('3', '2026-01-10', 'Impuestos ONAT', '7800.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('4', '2026-01-15', 'Impuesto 10%', '8000.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('9', '2026-02-26', 'pago de luz', '3000.00', 'SERVICIOS', 'Admin', NULL, 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('10', '2026-02-28', 'ETECSA MOVILES', '5600.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('11', '2026-02-10', 'Impuestos ONAT', '7800.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('12', '2026-02-15', 'Impuesto 10%', '8000.00', 'SERVICIOS', 'Admin', '', 'FIJO', '4');
INSERT INTO `gastos_historial` VALUES ('13', '2026-01-29', 'Salario eddy 10%', '1226.00', 'NOMINA', 'Admin', '10% de $12260 = $1,226.00', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('14', '2026-01-28', 'Salario eddy 10%', '665.50', 'NOMINA', 'Admin', '10% de $6655 = $665.50', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('15', '2026-01-27', 'Salario eddy 10%', '611.50', 'NOMINA', 'Admin', '10% de $6115 = $611.50', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('16', '2026-01-26', 'Salario eddy 10%', '531.00', 'NOMINA', 'Admin', '10% de $5310 = $531.00', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('18', '2026-01-25', 'Salario eddy 10%', '1431.50', 'NOMINA', 'Admin', '10% de $14315 = $1,431.50', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('19', '2026-01-24', 'Salario eddy 10%', '934.50', 'NOMINA', 'Admin', '10% de $9345 = $934.50', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('20', '2026-01-23', 'Salario eddy 10%', '729.00', 'NOMINA', 'Admin', '10% de $7290 = $729.00', 'VARIABLE', '4');
INSERT INTO `gastos_historial` VALUES ('21', '2026-01-30', 'Salario eddy 10%', '1770.50', 'NOMINA', 'Admin', '10% de $17705 = $1,770.50', 'VARIABLE', '4');

DROP TABLE IF EXISTS `gastos_plantillas_operativos`;
CREATE TABLE `gastos_plantillas_operativos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `categoria` varchar(50) NOT NULL DEFAULT 'OPERATIVO',
  `monto_default` decimal(12,2) DEFAULT 0.00,
  `descripcion` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `orden` int(11) DEFAULT 0,
  `es_salario` tinyint(1) DEFAULT 0,
  `tipo_calculo_salario` enum('FIJO','PORCENTAJE_VENTAS','FIJO_MAS_PORCENTAJE','FIJO_MAS_PORCENTAJE_SOBRE_META','PORCENTAJE_ESCALONADO','POR_HORA','PERSONALIZADO') DEFAULT 'FIJO',
  `salario_fijo` decimal(12,2) DEFAULT 0.00,
  `porcentaje_ventas` decimal(5,2) DEFAULT 0.00,
  `meta_ventas` decimal(12,2) DEFAULT 0.00,
  `porcentaje_sobre_meta` decimal(5,2) DEFAULT 0.00,
  `valor_hora` decimal(10,2) DEFAULT 0.00,
  `config_escalonado` longtext DEFAULT NULL CHECK (json_valid(`config_escalonado`)),
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_plantillas_activo` (`activo`),
  KEY `idx_plantillas_categoria` (`categoria`),
  KEY `idx_plantillas_es_salario` (`es_salario`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gastos_plantillas_operativos` VALUES ('1', 'Limpieza diaria', 'LIMPIEZA', '0.00', 'Productos y servicios de limpieza del local', '1', '1', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('2', 'Desechables', 'LIMPIEZA', '0.00', 'Bolsas, papel, servilletas, etc.', '1', '2', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('3', 'Fumigación', 'LIMPIEZA', '0.00', 'Control de plagas', '1', '3', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('8', 'Propinas entregadas', 'NOMINA', '0.00', 'Propinas pagadas al personal', '1', '14', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('10', 'Personal eventual', 'NOMINA', '0.00', 'Trabajadores temporales', '1', '16', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('11', 'Pago a proveedores', 'DEUDAS', '0.00', 'Abono a cuentas por pagar', '1', '20', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('12', 'Intereses préstamos', 'DEUDAS', '0.00', 'Intereses de financiamiento', '1', '21', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('13', 'Cuota de crédito', 'DEUDAS', '0.00', 'Pago de créditos bancarios', '1', '22', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('14', 'Combustible/Gas', 'OPERATIVO', '0.00', 'Gas LP o combustible para cocina', '1', '30', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('15', 'Hielo', 'OPERATIVO', '0.00', 'Compra de hielo para el día', '1', '31', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('16', 'Agua embotellada', 'OPERATIVO', '0.00', 'Garrafones o botellas de agua', '1', '32', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('17', 'Insumos menores', 'OPERATIVO', '0.00', 'Compras pequeñas del día', '1', '33', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('18', 'Transporte/Delivery', 'OPERATIVO', '0.00', 'Gastos de entrega a domicilio', '1', '34', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('19', 'Electricidad prepago', 'SERVICIOS', '0.00', 'Recarga de electricidad prepago', '1', '40', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('20', 'Internet/WiFi', 'SERVICIOS', '0.00', 'Pago diario de internet', '1', '41', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('21', 'Teléfono', 'SERVICIOS', '0.00', 'Recargas telefónicas', '1', '42', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('22', 'Seguridad privada', 'SEGURIDAD', '0.00', 'Pago a vigilancia', '1', '50', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('23', 'Custodia nocturna', 'SEGURIDAD', '0.00', 'Servicio nocturno de seguridad', '1', '51', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('24', 'Reparaciones urgentes', 'MANTENIMIENTO', '0.00', 'Arreglos menores urgentes', '1', '60', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('25', 'Gastos médicos', 'OTROS', '0.00', 'Atención médica de emergencia', '1', '61', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('26', 'Multas/Permisos', 'OTROS', '0.00', 'Pagos a autoridades', '1', '62', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('27', 'Otros gastos', 'OTROS', '0.00', 'Gastos varios no clasificados', '1', '99', '0', 'FIJO', '0.00', '0.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:11:31', '2026-02-01 21:11:31');
INSERT INTO `gastos_plantillas_operativos` VALUES ('28', 'Salario eddy 10%', 'NOMINA', '0.00', 'eddy', '1', '0', '1', 'PORCENTAJE_VENTAS', '0.00', '10.00', '0.00', '0.00', '0.00', NULL, '2026-02-01 21:13:35', '2026-02-01 21:13:35');

DROP TABLE IF EXISTS `horarios_tienda`;
CREATE TABLE `horarios_tienda` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dia_semana` tinyint(4) NOT NULL,
  `hora_apertura` time NOT NULL DEFAULT '09:00:00',
  `hora_cierre` time NOT NULL DEFAULT '22:00:00',
  `activo` tinyint(1) DEFAULT 1,
  `id_sucursal` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dia_suc` (`dia_semana`,`id_sucursal`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `horarios_tienda` VALUES ('1', '1', '09:00:00', '22:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('2', '2', '09:00:00', '22:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('3', '3', '09:00:00', '22:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('4', '4', '09:00:00', '22:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('5', '5', '09:00:00', '23:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('6', '6', '09:00:00', '23:00:00', '1', NULL);
INSERT INTO `horarios_tienda` VALUES ('7', '7', '09:00:00', '22:00:00', '1', NULL);

DROP TABLE IF EXISTS `kardex`;
CREATE TABLE `kardex` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_producto` varchar(50) NOT NULL,
  `id_almacen` int(11) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `tipo_movimiento` varchar(50) DEFAULT 'GENERAL',
  `cantidad` decimal(15,4) NOT NULL,
  `saldo_anterior` decimal(15,4) NOT NULL,
  `saldo_actual` decimal(15,4) NOT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `costo_unitario` decimal(15,2) DEFAULT 0.00,
  `usuario` varchar(100) DEFAULT 'Sistema',
  `uuid` char(36) DEFAULT NULL,
  `id_sucursal` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uuid` (`uuid`),
  KEY `idx_prod_fecha` (`id_producto`,`fecha`),
  KEY `idx_almacen` (`id_almacen`)
) ENGINE=InnoDB AUTO_INCREMENT=687 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kardex` VALUES ('1', '756058841477', '2', '2026-01-01 00:00:00', 'AJUSTE', '5.0000', '0.0000', '5.0000', 'IMPORT_CSV_185004', '20.00', 'ADMIN_IMPORT', '54f3de0e-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('2', '881105', '2', '2026-01-01 00:00:00', 'AJUSTE', '29.0000', '0.0000', '29.0000', 'IMPORT_CSV_185004', '50.00', 'ADMIN_IMPORT', '54f3e2d6-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('3', '991101', '2', '2026-01-01 00:00:00', 'AJUSTE', '6290.0000', '0.0000', '6290.0000', 'IMPORT_CSV_185004', '0.58', 'ADMIN_IMPORT', '54f3e3a8-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('4', '991102', '2', '2026-01-01 00:00:00', 'AJUSTE', '320.0000', '0.0000', '320.0000', 'IMPORT_CSV_185004', '0.61', 'ADMIN_IMPORT', '54f3e442-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('5', '991103', '2', '2026-01-01 00:00:00', 'AJUSTE', '5735.0000', '0.0000', '5735.0000', 'IMPORT_CSV_185004', '0.40', 'ADMIN_IMPORT', '54f3e4d1-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('6', '991105', '2', '2026-01-01 00:00:00', 'AJUSTE', '2530.0000', '0.0000', '2530.0000', 'IMPORT_CSV_185004', '1.20', 'ADMIN_IMPORT', '54f3e561-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('7', '991106', '2', '2026-01-01 00:00:00', 'AJUSTE', '700.0000', '0.0000', '700.0000', 'IMPORT_CSV_185004', '1.80', 'ADMIN_IMPORT', '54f3e5ee-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('8', '991107', '2', '2026-01-01 00:00:00', 'AJUSTE', '695.0000', '0.0000', '695.0000', 'IMPORT_CSV_185004', '2.40', 'ADMIN_IMPORT', '54f3e679-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('9', '991108', '2', '2026-01-01 00:00:00', 'AJUSTE', '500.0000', '0.0000', '500.0000', 'IMPORT_CSV_185004', '0.85', 'ADMIN_IMPORT', '54f3e8e6-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('10', '991109', '2', '2026-01-01 00:00:00', 'AJUSTE', '200.0000', '0.0000', '200.0000', 'IMPORT_CSV_185004', '2.50', 'ADMIN_IMPORT', '54f3e977-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('11', '991110', '2', '2026-01-01 00:00:00', 'AJUSTE', '415.0000', '0.0000', '415.0000', 'IMPORT_CSV_185004', '3.60', 'ADMIN_IMPORT', '54f3e9fe-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('12', '991111', '2', '2026-01-01 00:00:00', 'AJUSTE', '1365.0000', '0.0000', '1365.0000', 'IMPORT_CSV_185004', '1.80', 'ADMIN_IMPORT', '54f3ea5d-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('13', '991112', '2', '2026-01-01 00:00:00', 'AJUSTE', '315.0000', '0.0000', '315.0000', 'IMPORT_CSV_185004', '5.00', 'ADMIN_IMPORT', '54f3eab4-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('14', '991113', '2', '2026-01-01 00:00:00', 'AJUSTE', '930.0000', '0.0000', '930.0000', 'IMPORT_CSV_185004', '4.15', 'ADMIN_IMPORT', '54f3eb0c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('15', '991114', '2', '2026-01-01 00:00:00', 'AJUSTE', '3.0000', '0.0000', '3.0000', 'IMPORT_CSV_185004', '45.00', 'ADMIN_IMPORT', '54f3eb64-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('16', '991115', '2', '2026-01-01 00:00:00', 'AJUSTE', '29.0000', '0.0000', '29.0000', 'IMPORT_CSV_185004', '25.00', 'ADMIN_IMPORT', '54f3ebbc-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('17', '991116', '2', '2026-01-01 00:00:00', 'AJUSTE', '14.0000', '0.0000', '14.0000', 'IMPORT_CSV_185004', '50.00', 'ADMIN_IMPORT', '54f3ec13-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('18', '991117', '2', '2026-01-01 00:00:00', 'AJUSTE', '13.0000', '0.0000', '13.0000', 'IMPORT_CSV_185004', '50.00', 'ADMIN_IMPORT', '54f3ec69-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('19', '991118', '2', '2026-01-01 00:00:00', 'AJUSTE', '110.0000', '0.0000', '110.0000', 'IMPORT_CSV_185004', '1.00', 'ADMIN_IMPORT', '54f3ecc0-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('20', '991119', '2', '2026-01-01 00:00:00', 'AJUSTE', '1740.0000', '0.0000', '1740.0000', 'IMPORT_CSV_185004', '0.12', 'ADMIN_IMPORT', '54f3ed18-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('21', '991120', '2', '2026-01-01 00:00:00', 'AJUSTE', '180.0000', '0.0000', '180.0000', 'IMPORT_CSV_185004', '2.00', 'ADMIN_IMPORT', '54f3ed6d-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('22', '991121', '2', '2026-01-01 00:00:00', 'AJUSTE', '1145.0000', '0.0000', '1145.0000', 'IMPORT_CSV_185004', '0.43', 'ADMIN_IMPORT', '54f3edc5-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('23', '991122', '2', '2026-01-01 00:00:00', 'AJUSTE', '1855.0000', '0.0000', '1855.0000', 'IMPORT_CSV_185004', '3.50', 'ADMIN_IMPORT', '54f3ee1e-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('24', '991123', '2', '2026-01-01 00:00:00', 'AJUSTE', '910.0000', '0.0000', '910.0000', 'IMPORT_CSV_185004', '5.00', 'ADMIN_IMPORT', '54f3ee71-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('25', '991124', '2', '2026-01-01 00:00:00', 'AJUSTE', '500.0000', '0.0000', '500.0000', 'IMPORT_CSV_185004', '0.40', 'ADMIN_IMPORT', '54f3eec9-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('26', '991125', '2', '2026-01-01 00:00:00', 'AJUSTE', '240.0000', '0.0000', '240.0000', 'IMPORT_CSV_185004', '0.27', 'ADMIN_IMPORT', '54f3ef1c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('27', '991126', '2', '2026-01-01 00:00:00', 'AJUSTE', '300.0000', '0.0000', '300.0000', 'IMPORT_CSV_185004', '2.50', 'ADMIN_IMPORT', '54f3ef73-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('28', '991127', '2', '2026-01-01 00:00:00', 'AJUSTE', '1775.0000', '0.0000', '1775.0000', 'IMPORT_CSV_185004', '2.50', 'ADMIN_IMPORT', '54f3efc8-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('29', '991128', '2', '2026-01-01 00:00:00', 'AJUSTE', '830.0000', '0.0000', '830.0000', 'IMPORT_CSV_185005', '1.50', 'ADMIN_IMPORT', '54f3f01b-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('30', '991129', '2', '2026-01-01 00:00:00', 'AJUSTE', '240.0000', '0.0000', '240.0000', 'IMPORT_CSV_185005', '1.50', 'ADMIN_IMPORT', '54f3f072-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('31', '991130', '2', '2026-01-01 00:00:00', 'AJUSTE', '115.0000', '0.0000', '115.0000', 'IMPORT_CSV_185005', '1.50', 'ADMIN_IMPORT', '54f3f0cb-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('32', '991131', '2', '2026-01-01 00:00:00', 'AJUSTE', '140.0000', '0.0000', '140.0000', 'IMPORT_CSV_185005', '1.50', 'ADMIN_IMPORT', '54f3f11e-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('33', '991132', '2', '2026-01-01 00:00:00', 'AJUSTE', '630.0000', '0.0000', '630.0000', 'IMPORT_CSV_185005', '1.50', 'ADMIN_IMPORT', '54f3f174-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('34', '991133', '2', '2026-01-01 00:00:00', 'AJUSTE', '625.0000', '0.0000', '625.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f1cb-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('35', '991134', '2', '2026-01-01 00:00:00', 'AJUSTE', '230.0000', '0.0000', '230.0000', 'IMPORT_CSV_185005', '4.60', 'ADMIN_IMPORT', '54f3f221-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('36', '991135', '2', '2026-01-01 00:00:00', 'AJUSTE', '65.0000', '0.0000', '65.0000', 'IMPORT_CSV_185005', '1.00', 'ADMIN_IMPORT', '54f3f275-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('37', '991136', '2', '2026-01-01 00:00:00', 'AJUSTE', '435.0000', '0.0000', '435.0000', 'IMPORT_CSV_185005', '2.90', 'ADMIN_IMPORT', '54f3f2d0-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('38', '991137', '2', '2026-01-01 00:00:00', 'AJUSTE', '390.0000', '0.0000', '390.0000', 'IMPORT_CSV_185005', '2.90', 'ADMIN_IMPORT', '54f3f325-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('39', '991139', '2', '2026-01-01 00:00:00', 'AJUSTE', '2775.0000', '0.0000', '2775.0000', 'IMPORT_CSV_185005', '2.60', 'ADMIN_IMPORT', '54f3f37c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('40', '991141', '2', '2026-01-01 00:00:00', 'AJUSTE', '180.0000', '0.0000', '180.0000', 'IMPORT_CSV_185005', '0.43', 'ADMIN_IMPORT', '54f3f3cf-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('41', '991144', '2', '2026-01-01 00:00:00', 'AJUSTE', '135.0000', '0.0000', '135.0000', 'IMPORT_CSV_185005', '1.25', 'ADMIN_IMPORT', '54f3f426-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('42', '991146', '2', '2026-01-01 00:00:00', 'AJUSTE', '75.0000', '0.0000', '75.0000', 'IMPORT_CSV_185005', '0.27', 'ADMIN_IMPORT', '54f3f47c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('43', '991147', '2', '2026-01-01 00:00:00', 'AJUSTE', '630.0000', '0.0000', '630.0000', 'IMPORT_CSV_185005', '0.50', 'ADMIN_IMPORT', '54f3f4d4-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('44', '991148', '2', '2026-01-01 00:00:00', 'AJUSTE', '1.5000', '0.0000', '1.5000', 'IMPORT_CSV_185005', '253.00', 'ADMIN_IMPORT', '54f3f52a-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('45', '991149', '2', '2026-01-01 00:00:00', 'AJUSTE', '0.2500', '0.0000', '0.2500', 'IMPORT_CSV_185005', '129.00', 'ADMIN_IMPORT', '54f3f57f-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('46', '991151', '2', '2026-01-01 00:00:00', 'AJUSTE', '1020.0000', '0.0000', '1020.0000', 'IMPORT_CSV_185005', '0.23', 'ADMIN_IMPORT', '54f3f5d5-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('47', '991152', '2', '2026-01-01 00:00:00', 'AJUSTE', '5500.0000', '0.0000', '5500.0000', 'IMPORT_CSV_185005', '0.63', 'ADMIN_IMPORT', '54f3f62c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('48', '991153', '2', '2026-01-01 00:00:00', 'AJUSTE', '915.0000', '0.0000', '915.0000', 'IMPORT_CSV_185005', '25.00', 'ADMIN_IMPORT', '54f3f681-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('49', '991154', '2', '2026-01-01 00:00:00', 'AJUSTE', '50.0000', '0.0000', '50.0000', 'IMPORT_CSV_185005', '0.20', 'ADMIN_IMPORT', '54f3f6d6-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('50', '991157', '2', '2026-01-01 00:00:00', 'AJUSTE', '285.0000', '0.0000', '285.0000', 'IMPORT_CSV_185005', '35.00', 'ADMIN_IMPORT', '54f3f72b-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('51', '991158', '2', '2026-01-01 00:00:00', 'AJUSTE', '725.0000', '0.0000', '725.0000', 'IMPORT_CSV_185005', '0.41', 'ADMIN_IMPORT', '54f3f780-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('52', '991159', '2', '2026-01-01 00:00:00', 'AJUSTE', '345.0000', '0.0000', '345.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f7d6-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('53', '991160', '2', '2026-01-01 00:00:00', 'AJUSTE', '60.0000', '0.0000', '60.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f82b-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('54', '991161', '2', '2026-01-01 00:00:00', 'AJUSTE', '60.0000', '0.0000', '60.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f881-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('55', '991162', '2', '2026-01-01 00:00:00', 'AJUSTE', '100.0000', '0.0000', '100.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f8d5-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('56', '991163', '2', '2026-01-01 00:00:00', 'AJUSTE', '50.0000', '0.0000', '50.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f92b-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('57', '991164', '2', '2026-01-01 00:00:00', 'AJUSTE', '40.0000', '0.0000', '40.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f97f-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('58', '991165', '2', '2026-01-01 00:00:00', 'AJUSTE', '50.0000', '0.0000', '50.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3f9d5-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('59', '991166', '2', '2026-01-01 00:00:00', 'AJUSTE', '810.0000', '0.0000', '810.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fa2d-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('60', '991167', '2', '2026-01-01 00:00:00', 'AJUSTE', '390.0000', '0.0000', '390.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fa81-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('61', '991168', '2', '2026-01-01 00:00:00', 'AJUSTE', '80.0000', '0.0000', '80.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fad7-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('62', '991169', '2', '2026-01-01 00:00:00', 'AJUSTE', '855.0000', '0.0000', '855.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fb2f-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('63', '991170', '2', '2026-01-01 00:00:00', 'AJUSTE', '185.0000', '0.0000', '185.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fb87-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('64', '991171', '2', '2026-01-01 00:00:00', 'AJUSTE', '995.0000', '0.0000', '995.0000', 'IMPORT_CSV_185005', '7.00', 'ADMIN_IMPORT', '54f3fbdd-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('65', '991172', '2', '2026-01-01 00:00:00', 'AJUSTE', '140.0000', '0.0000', '140.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fd53-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('66', '991173', '2', '2026-01-01 00:00:00', 'AJUSTE', '365.0000', '0.0000', '365.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fdad-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('67', '991174', '2', '2026-01-01 00:00:00', 'AJUSTE', '305.0000', '0.0000', '305.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fe05-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('68', '991175', '2', '2026-01-01 00:00:00', 'AJUSTE', '95.0000', '0.0000', '95.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3fe5a-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('69', '991176', '2', '2026-01-01 00:00:00', 'AJUSTE', '345.0000', '0.0000', '345.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3feae-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('70', '991177', '2', '2026-01-01 00:00:00', 'AJUSTE', '110.0000', '0.0000', '110.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3ff06-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('71', '991178', '2', '2026-01-01 00:00:00', 'AJUSTE', '40.0000', '0.0000', '40.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3ff5e-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('72', '991179', '2', '2026-01-01 00:00:00', 'AJUSTE', '75.0000', '0.0000', '75.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f3ffbf-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('73', '991180', '2', '2026-01-01 00:00:00', 'AJUSTE', '55.0000', '0.0000', '55.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f4002c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('74', '991181', '2', '2026-01-01 00:00:00', 'AJUSTE', '105.0000', '0.0000', '105.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f40086-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('75', '991182', '2', '2026-01-01 00:00:00', 'AJUSTE', '90.0000', '0.0000', '90.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f400e4-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('76', '991183', '2', '2026-01-01 00:00:00', 'AJUSTE', '70.0000', '0.0000', '70.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f4013e-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('77', '991184', '2', '2026-01-01 00:00:00', 'AJUSTE', '3625.0000', '0.0000', '3625.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f4019c-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('78', '991185', '2', '2026-01-01 00:00:00', 'AJUSTE', '26.0000', '0.0000', '26.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f401fa-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('79', '991186', '2', '2026-01-01 00:00:00', 'AJUSTE', '775.0000', '0.0000', '775.0000', 'IMPORT_CSV_185005', '2.20', 'ADMIN_IMPORT', '54f40255-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('80', '991187', '2', '2026-01-01 00:00:00', 'AJUSTE', '6.0000', '0.0000', '6.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f4045a-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('81', '991188', '2', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f404b4-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('82', '991189', '2', '2026-01-01 00:00:00', 'AJUSTE', '160.0000', '0.0000', '160.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f4050b-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('83', '991190', '2', '2026-01-01 00:00:00', 'AJUSTE', '325.0000', '0.0000', '325.0000', 'IMPORT_CSV_185005', '2.00', 'ADMIN_IMPORT', '54f40562-01f4-11f1-b0a7-0affd1a0dee5', '2');
INSERT INTO `kardex` VALUES ('84', '660034', '4', '2026-01-01 00:00:00', 'AJUSTE', '180.0000', '0.0000', '180.0000', 'IMPORT_CSV_185540', '5.00', 'ADMIN_IMPORT', '54f405be-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('85', '660029', '4', '2026-01-01 00:00:00', 'AJUSTE', '315.0000', '0.0000', '315.0000', 'IMPORT_CSV_185540', '8.00', 'ADMIN_IMPORT', '54f407b8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('86', '660035', '4', '2026-01-01 00:00:00', 'AJUSTE', '32.0000', '0.0000', '32.0000', 'IMPORT_CSV_185540', '15.00', 'ADMIN_IMPORT', '54f41ca3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('87', '660007', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '20.00', 'ADMIN_IMPORT', '54f420cb-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('88', '660033', '4', '2026-01-01 00:00:00', 'AJUSTE', '32.0000', '0.0000', '32.0000', 'IMPORT_CSV_185540', '20.00', 'ADMIN_IMPORT', '54f422f8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('89', '660002', '4', '2026-01-01 00:00:00', 'AJUSTE', '22.0000', '0.0000', '22.0000', 'IMPORT_CSV_185540', '25.00', 'ADMIN_IMPORT', '54f429ac-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('90', '660019', '4', '2026-01-01 00:00:00', 'AJUSTE', '100.0000', '0.0000', '100.0000', 'IMPORT_CSV_185540', '33.00', 'ADMIN_IMPORT', '54f48a62-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('91', '660001', '4', '2026-01-01 00:00:00', 'AJUSTE', '21.0000', '0.0000', '21.0000', 'IMPORT_CSV_185540', '35.00', 'ADMIN_IMPORT', '54f48b98-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('92', '660028', '4', '2026-01-01 00:00:00', 'AJUSTE', '6.0000', '0.0000', '6.0000', 'IMPORT_CSV_185540', '90.00', 'ADMIN_IMPORT', '54f48e56-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('93', '660009', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '120.00', 'ADMIN_IMPORT', '54f48ef6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('94', '660005', '4', '2026-01-01 00:00:00', 'AJUSTE', '1.0000', '0.0000', '1.0000', 'IMPORT_CSV_185540', '130.00', 'ADMIN_IMPORT', '54f49160-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('95', '660036', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '135.00', 'ADMIN_IMPORT', '54f491f4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('96', '660008', '4', '2026-01-01 00:00:00', 'AJUSTE', '4.0000', '0.0000', '4.0000', 'IMPORT_CSV_185540', '150.00', 'ADMIN_IMPORT', '54f4945b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('97', '660027', '4', '2026-01-01 00:00:00', 'AJUSTE', '34.0000', '0.0000', '34.0000', 'IMPORT_CSV_185540', '166.00', 'ADMIN_IMPORT', '54f496c7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('98', '660032', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '190.00', 'ADMIN_IMPORT', '54f4993c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('99', '660024', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '205.00', 'ADMIN_IMPORT', '54f49baf-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('100', '660011', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '210.00', 'ADMIN_IMPORT', '54f4a2d7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('101', '660021', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '210.00', 'ADMIN_IMPORT', '54f4a33e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('102', '660022', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '210.00', 'ADMIN_IMPORT', '54f4a398-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('103', '660037', '4', '2026-01-01 00:00:00', 'AJUSTE', '24.0000', '0.0000', '24.0000', 'IMPORT_CSV_185540', '210.00', 'ADMIN_IMPORT', '54f4a3f3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('104', '660023', '4', '2026-01-01 00:00:00', 'AJUSTE', '48.0000', '0.0000', '48.0000', 'IMPORT_CSV_185540', '213.00', 'ADMIN_IMPORT', '54f4a520-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('105', '660006', '4', '2026-01-01 00:00:00', 'AJUSTE', '1.0000', '0.0000', '1.0000', 'IMPORT_CSV_185540', '230.00', 'ADMIN_IMPORT', '54f4a58d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('106', '660003', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '340.00', 'ADMIN_IMPORT', '54f4a5e6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('107', '660004', '4', '2026-01-01 00:00:00', 'AJUSTE', '8.0000', '0.0000', '8.0000', 'IMPORT_CSV_185540', '370.00', 'ADMIN_IMPORT', '54f4a63e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('108', '660025', '4', '2026-01-01 00:00:00', 'AJUSTE', '12.0000', '0.0000', '12.0000', 'IMPORT_CSV_185540', '430.00', 'ADMIN_IMPORT', '54f4a697-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('109', '660026', '4', '2026-01-01 00:00:00', 'AJUSTE', '3.0000', '0.0000', '3.0000', 'IMPORT_CSV_185540', '430.00', 'ADMIN_IMPORT', '54f4a6f0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('110', '660020', '4', '2026-01-01 00:00:00', 'AJUSTE', '10.0000', '0.0000', '10.0000', 'IMPORT_CSV_185540', '560.00', 'ADMIN_IMPORT', '54f4a746-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('111', '660018', '4', '2026-01-01 00:00:00', 'AJUSTE', '8.0000', '0.0000', '8.0000', 'IMPORT_CSV_185540', '580.00', 'ADMIN_IMPORT', '54f4a79e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('112', '660016', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '620.00', 'ADMIN_IMPORT', '54f4a7f7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('113', '660012', '4', '2026-01-01 00:00:00', 'AJUSTE', '33.0000', '0.0000', '33.0000', 'IMPORT_CSV_185540', '50.00', 'ADMIN_IMPORT', '54f4a84c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('114', '660013', '4', '2026-01-01 00:00:00', 'AJUSTE', '17.0000', '0.0000', '17.0000', 'IMPORT_CSV_185540', '35.00', 'ADMIN_IMPORT', '54f4a8a3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('115', '660014', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '220.00', 'ADMIN_IMPORT', '54f4a8f9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('116', '660015', '4', '2026-01-01 00:00:00', 'AJUSTE', '1.0000', '0.0000', '1.0000', 'IMPORT_CSV_185540', '300.00', 'ADMIN_IMPORT', '54f4a94f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('117', '660017', '4', '2026-01-01 00:00:00', 'AJUSTE', '6.0000', '0.0000', '6.0000', 'IMPORT_CSV_185540', '72.00', 'ADMIN_IMPORT', '54f4a9a5-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('118', '660030', '4', '2026-01-01 00:00:00', 'AJUSTE', '3.0000', '0.0000', '3.0000', 'IMPORT_CSV_185540', '180.00', 'ADMIN_IMPORT', '54f4a9fb-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('119', '660031', '4', '2026-01-01 00:00:00', 'AJUSTE', '2.0000', '0.0000', '2.0000', 'IMPORT_CSV_185540', '80.00', 'ADMIN_IMPORT', '54f4aa52-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('120', '660011', '4', '2026-01-29 22:53:23', 'ENTRADA', '24.0000', '2.0000', '26.0000', 'COMPRA #1', '210.00', 'Admin', '54f4aaa9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('121', '660005', '4', '2026-01-29 22:53:23', 'ENTRADA', '24.0000', '1.0000', '25.0000', 'COMPRA #1', '130.00', 'Admin', '54f4ab08-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('122', '660001', '4', '2026-01-23 22:57:36', 'VENTA', '-2.0000', '21.0000', '19.0000', 'VENTA #1', '35.00', 'Eddy', '54f4ab62-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('123', '660004', '4', '2026-01-23 22:57:36', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #1', '370.00', 'Eddy', '54f4abb9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('124', '660007', '4', '2026-01-23 22:57:36', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #1', '20.00', 'Eddy', '54f4ac12-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('125', '660008', '4', '2026-01-23 22:57:36', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #1', '150.00', 'Eddy', '54f4ac65-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('126', '660011', '4', '2026-01-23 22:57:36', 'VENTA', '-1.0000', '26.0000', '25.0000', 'VENTA #1', '210.00', 'Eddy', '54f4acba-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('127', '660012', '4', '2026-01-23 22:57:36', 'VENTA', '-4.0000', '33.0000', '29.0000', 'VENTA #1', '50.00', 'Eddy', '54f4ad12-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('128', '660013', '4', '2026-01-23 22:57:36', 'VENTA', '-7.0000', '17.0000', '10.0000', 'VENTA #1', '35.00', 'Eddy', '54f4ad6a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('129', '660017', '4', '2026-01-23 22:57:36', 'VENTA', '-2.0000', '6.0000', '4.0000', 'VENTA #1', '88.00', 'Eddy', '54f4ae1d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('130', '881108', '4', '2026-01-29 22:58:19', 'ENTRADA', '1.0000', '0.0000', '1.0000', 'COMPRA #2', '292.71', 'Admin', '54f4ae7b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('131', '660015', '4', '2026-01-23 22:59:43', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #2', '300.00', 'Eddy', '54f4aed7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('132', '660021', '4', '2026-01-23 22:59:43', 'VENTA', '-1.0000', '24.0000', '23.0000', 'VENTA #2', '217.00', 'Eddy', '54f4af2f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('133', '660023', '4', '2026-01-23 22:59:43', 'VENTA', '-13.0000', '48.0000', '35.0000', 'VENTA #2', '213.00', 'Eddy', '54f4af84-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('134', '660024', '4', '2026-01-23 22:59:43', 'VENTA', '-5.0000', '24.0000', '19.0000', 'VENTA #2', '205.00', 'Eddy', '54f4afde-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('135', '660003', '4', '2026-01-24 23:04:03', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #3', '360.00', 'Eddy', '54f4b034-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('136', '660007', '4', '2026-01-24 23:04:03', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #3', '20.00', 'Eddy', '54f4b08e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('137', '660013', '4', '2026-01-24 23:04:03', 'VENTA', '-4.0000', '10.0000', '6.0000', 'VENTA #3', '35.00', 'Eddy', '54f4b0ec-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('138', '660014', '4', '2026-01-24 23:04:03', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #3', '220.00', 'Eddy', '54f4b141-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('139', '660018', '4', '2026-01-24 23:04:03', 'VENTA', '-2.0000', '8.0000', '6.0000', 'VENTA #3', '580.00', 'Eddy', '54f4b199-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('140', '660001', '4', '2026-01-24 23:04:11', 'VENTA', '-1.0000', '19.0000', '18.0000', 'VENTA #4', '35.00', 'Eddy', '54f4b1f0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('141', '660022', '4', '2026-01-24 23:06:02', 'VENTA', '-1.0000', '24.0000', '23.0000', 'VENTA #5', '210.00', 'Eddy', '54f4b249-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('142', '660023', '4', '2026-01-24 23:06:02', 'VENTA', '-11.0000', '35.0000', '24.0000', 'VENTA #5', '213.00', 'Eddy', '54f4b2a1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('143', '660024', '4', '2026-01-24 23:06:02', 'VENTA', '-4.0000', '19.0000', '15.0000', 'VENTA #5', '205.00', 'Eddy', '54f4b2f9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('144', '660012', '4', '2026-01-24 23:06:02', 'VENTA', '-6.0000', '29.0000', '23.0000', 'VENTA #5', '50.00', 'Eddy', '54f4b341-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('145', '660029', '4', '2026-01-24 23:06:02', 'VENTA', '-5.0000', '315.0000', '310.0000', 'VENTA #5', '8.00', 'Eddy', '54f4b37c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('146', '660012', '4', '2026-01-29 23:07:42', 'DEVOLUCION', '6.0000', '23.0000', '29.0000', 'REFUND_ITEM_22', '50.00', 'CAJERO_REFUND', '54f4b3b5-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('147', '660028', '4', '2026-01-24 23:07:59', 'VENTA', '-6.0000', '6.0000', '0.0000', 'VENTA #7', '90.00', 'Eddy', '54f4b3ef-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('148', '660012', '4', '2026-01-24 23:08:54', 'VENTA', '-8.0000', '29.0000', '21.0000', 'VENTA #8', '50.00', 'Eddy', '54f4b42a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('149', '660004', '4', '2026-01-25 23:16:39', 'VENTA', '-3.0000', '7.0000', '4.0000', 'VENTA #9', '370.00', 'Admin', '54f4b46e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('150', '660009', '4', '2026-01-25 23:16:39', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #9', '120.00', 'Admin', '54f4b4ef-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('151', '660011', '4', '2026-01-25 23:16:39', 'VENTA', '-4.0000', '25.0000', '21.0000', 'VENTA #9', '210.00', 'Admin', '54f4b586-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('152', '660013', '4', '2026-01-25 23:16:39', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #9', '35.00', 'Admin', '54f4b615-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('153', '660018', '4', '2026-01-25 23:16:39', 'VENTA', '-2.0000', '6.0000', '4.0000', 'VENTA #9', '580.00', 'Admin', '54f4b6aa-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('154', '660019', '4', '2026-01-25 23:16:39', 'VENTA', '-3.0000', '100.0000', '97.0000', 'VENTA #9', '33.00', 'Admin', '54f4b743-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('155', '660013', '4', '2026-01-25 23:22:47', 'VENTA', '-2.0000', '5.0000', '3.0000', 'VENTA #10', '35.00', 'Admin', '54f4b7dc-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('156', '660020', '4', '2026-01-25 23:22:47', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #10', '570.00', 'Admin', '54f4b874-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('157', '660021', '4', '2026-01-25 23:22:47', 'VENTA', '-4.0000', '23.0000', '19.0000', 'VENTA #10', '217.00', 'Admin', '54f4b903-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('158', '660022', '4', '2026-01-25 23:22:47', 'VENTA', '-4.0000', '23.0000', '19.0000', 'VENTA #10', '210.00', 'Admin', '54f4b996-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('159', '660024', '4', '2026-01-25 23:22:47', 'VENTA', '-15.0000', '15.0000', '0.0000', 'VENTA #10', '205.00', 'Admin', '54f4ba27-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('160', '660025', '4', '2026-01-25 23:22:47', 'VENTA', '-1.0000', '12.0000', '11.0000', 'VENTA #10', '430.00', 'Admin', '54f4bab6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('161', '660026', '4', '2026-01-25 23:22:47', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #10', '430.00', 'Admin', '54f4bb49-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('162', '660027', '4', '2026-01-25 23:22:47', 'VENTA', '-3.0000', '34.0000', '31.0000', 'VENTA #10', '162.57', 'Admin', '54f4bbd9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('163', '660012', '4', '2026-01-25 23:22:47', 'VENTA', '-16.0000', '21.0000', '5.0000', 'VENTA #10', '50.00', 'Admin', '54f4bc6f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('164', '660029', '4', '2026-01-25 23:22:47', 'VENTA', '-3.0000', '310.0000', '307.0000', 'VENTA #10', '8.00', 'Admin', '54f4bd05-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('165', '660013', '4', '2026-01-29 23:25:25', 'DEVOLUCION', '1.0000', '3.0000', '4.0000', 'REFUND_ITEM_30', '35.00', 'CAJERO_REFUND', '54f4bd96-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('166', '660017', '4', '2026-01-29 23:30:04', 'ENTRADA', '2.0000', '4.0000', '6.0000', 'COMPRA #3', '72.00', 'Admin', '54f4be27-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('167', '660012', '4', '2026-01-29 23:30:04', 'ENTRADA', '29.0000', '5.0000', '34.0000', 'COMPRA #3', '50.00', 'Admin', '54f4beb7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('168', '660008', '4', '2026-01-26 23:30:43', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #12', '150.00', 'Admin', '54f4bf49-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('169', '660011', '4', '2026-01-26 23:30:43', 'VENTA', '-1.0000', '21.0000', '20.0000', 'VENTA #12', '210.00', 'Admin', '54f4bfd7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('170', '660013', '4', '2026-01-26 23:30:43', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #12', '35.00', 'Admin', '54f4c069-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('171', '660016', '4', '2026-01-26 23:30:43', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #12', '620.00', 'Admin', '54f4c0f9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('172', '660019', '4', '2026-01-26 23:30:43', 'VENTA', '-6.0000', '97.0000', '91.0000', 'VENTA #12', '33.00', 'Admin', '54f4c18c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('173', '660027', '4', '2026-01-26 23:30:43', 'VENTA', '-1.0000', '31.0000', '30.0000', 'VENTA #12', '162.57', 'Admin', '54f4c21a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('174', '660029', '4', '2026-01-26 23:30:43', 'VENTA', '-6.0000', '307.0000', '301.0000', 'VENTA #12', '8.00', 'Admin', '54f4c2aa-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('175', '660017', '4', '2026-01-26 23:30:43', 'VENTA', '-4.0000', '6.0000', '2.0000', 'VENTA #12', '88.00', 'Admin', '54f4c305-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('176', '660030', '4', '2026-01-26 23:30:43', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #12', '180.00', 'Admin', '54f4c35f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('177', '660031', '4', '2026-01-26 23:30:43', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #12', '82.00', 'Admin', '54f4c3b4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('178', '660012', '4', '2026-01-26 23:31:15', 'VENTA', '-11.0000', '34.0000', '23.0000', 'VENTA #13', '50.00', 'Admin', '54f4c409-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('179', '660026', '4', '2026-01-29 23:34:58', 'ENTRADA', '2.0000', '1.0000', '3.0000', 'COMPRA #4', '430.00', 'Admin', '54f4c461-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('180', '660012', '4', '2026-01-29 23:34:58', 'ENTRADA', '22.0000', '23.0000', '45.0000', 'COMPRA #4', '50.00', 'Admin', '54f4c4b7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('181', '660023', '4', '2026-01-29 23:34:58', 'ENTRADA', '24.0000', '24.0000', '48.0000', 'COMPRA #4', '213.00', 'Admin', '54f4c50e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('182', '660037', '4', '2026-01-29 23:34:58', 'ENTRADA', '24.0000', '24.0000', '48.0000', 'COMPRA #4', '210.00', 'Admin', '54f4c565-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('183', '660032', '4', '2026-01-29 23:34:58', 'ENTRADA', '24.0000', '24.0000', '48.0000', 'COMPRA #4', '190.00', 'Admin', '54f4c5bd-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('184', '660036', '4', '2026-01-29 23:34:58', 'ENTRADA', '27.0000', '24.0000', '51.0000', 'COMPRA #4', '135.00', 'Admin', '54f4c614-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('185', '660033', '4', '2026-01-29 23:34:58', 'ENTRADA', '32.0000', '32.0000', '64.0000', 'COMPRA #4', '20.00', 'Admin', '54f4c66d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('186', '660035', '4', '2026-01-29 23:34:58', 'ENTRADA', '32.0000', '32.0000', '64.0000', 'COMPRA #4', '15.00', 'Admin', '54f4c6c4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('187', '660034', '4', '2026-01-29 23:34:58', 'ENTRADA', '180.0000', '180.0000', '360.0000', 'COMPRA #4', '6.00', 'Admin', '54f4c71b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('188', '660004', '4', '2026-01-27 23:38:36', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #14', '370.00', 'Eddy', '54f4c772-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('189', '660006', '4', '2026-01-27 23:38:36', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #14', '212.00', 'Eddy', '54f4c7c8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('190', '660031', '4', '2026-01-27 23:38:36', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #14', '82.00', 'Eddy', '54f4c820-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('191', '660034', '4', '2026-01-27 23:38:36', 'VENTA', '-2.0000', '360.0000', '358.0000', 'VENTA #14', '6.00', 'Eddy', '54f4c877-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('192', '660036', '4', '2026-01-29 23:42:59', 'SALIDA', '-24.0000', '51.0000', '27.0000', 'MERMA #1', '135.00', 'Admin', '54f4c8ce-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('193', '660011', '4', '2026-01-27 23:43:34', 'VENTA', '-1.0000', '20.0000', '19.0000', 'VENTA #15', '210.00', 'Eddy', '54f4c924-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('194', '660021', '4', '2026-01-27 23:43:34', 'VENTA', '-1.0000', '19.0000', '18.0000', 'VENTA #15', '217.00', 'Eddy', '54f4c979-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('195', '660022', '4', '2026-01-27 23:43:34', 'VENTA', '-1.0000', '19.0000', '18.0000', 'VENTA #15', '210.00', 'Eddy', '54f4c9d3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('196', '660026', '4', '2026-01-27 23:43:34', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #15', '430.00', 'Eddy', '54f4ca29-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('197', '660027', '4', '2026-01-27 23:43:34', 'VENTA', '-1.0000', '30.0000', '29.0000', 'VENTA #15', '162.57', 'Eddy', '54f4ca7d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('198', '660029', '4', '2026-01-27 23:43:34', 'VENTA', '-41.0000', '301.0000', '260.0000', 'VENTA #15', '8.00', 'Eddy', '54f4cad4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('199', '660017', '4', '2026-01-27 23:43:34', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #15', '88.00', 'Eddy', '54f4cb2c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('200', '660012', '4', '2026-01-27 23:43:34', 'VENTA', '-13.0000', '45.0000', '32.0000', 'VENTA #15', '50.00', 'Eddy', '54f4cd73-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('201', '660023', '4', '2026-01-27 23:43:34', 'VENTA', '-3.0000', '48.0000', '45.0000', 'VENTA #15', '213.00', 'Eddy', '54f4cec0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('202', '660036', '4', '2026-01-27 23:43:34', 'VENTA', '-2.0000', '27.0000', '25.0000', 'VENTA #15', '135.00', 'Eddy', '54f4cfd8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('203', '660012', '4', '2026-01-29 23:48:01', 'ENTRADA', '26.0000', '32.0000', '58.0000', 'COMPRA #5', '50.00', 'Admin', '54f4d0f2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('204', '660099', '4', '2026-01-29 23:48:01', 'ENTRADA', '16.0000', '0.0000', '16.0000', 'COMPRA #5', '65.00', 'Admin', '54f4d23b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('205', '660015', '4', '2026-01-29 23:48:01', 'ENTRADA', '9.0000', '0.0000', '9.0000', 'COMPRA #5', '300.00', 'Admin', '54f4d353-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('206', '660014', '4', '2026-01-29 23:48:01', 'ENTRADA', '5.0000', '0.0000', '5.0000', 'COMPRA #5', '220.00', 'Admin', '54f4d469-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('207', '660012', '4', '2026-01-28 23:50:41', 'VENTA', '-10.0000', '58.0000', '48.0000', 'VENTA #16', '50.00', 'Eddy', '54f4d581-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('208', '660001', '4', '2026-01-28 23:51:49', 'VENTA', '-3.0000', '18.0000', '15.0000', 'VENTA #17', '35.00', 'Eddy', '54f4d6c9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('209', '660009', '4', '2026-01-28 23:51:49', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #17', '120.00', 'Eddy', '54f4d7e0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('210', '660019', '4', '2026-01-28 23:51:49', 'VENTA', '-2.0000', '91.0000', '89.0000', 'VENTA #17', '33.00', 'Eddy', '54f4d8f4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('211', '660021', '4', '2026-01-28 23:51:49', 'VENTA', '-2.0000', '18.0000', '16.0000', 'VENTA #17', '217.00', 'Eddy', '54f4da0a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('212', '660022', '4', '2026-01-28 23:51:49', 'VENTA', '-2.0000', '18.0000', '16.0000', 'VENTA #17', '210.00', 'Eddy', '54f4db52-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('213', '660026', '4', '2026-01-28 23:51:49', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #17', '430.00', 'Eddy', '54f4dc6b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('214', '660029', '4', '2026-01-28 23:53:01', 'VENTA', '-5.0000', '260.0000', '255.0000', 'VENTA #18', '8.00', 'Eddy', '54f4dd81-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('215', '660030', '4', '2026-01-28 23:53:01', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #18', '180.00', 'Eddy', '54f4de97-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('216', '660023', '4', '2026-01-28 23:53:01', 'VENTA', '-12.0000', '45.0000', '33.0000', 'VENTA #18', '213.00', 'Eddy', '54f4dfe1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('217', '660036', '4', '2026-01-28 23:53:25', 'VENTA', '-2.0000', '25.0000', '23.0000', 'VENTA #19', '135.00', 'Eddy', '54f4e0f8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('218', '660034', '4', '2026-01-28 23:53:25', 'VENTA', '-4.0000', '358.0000', '354.0000', 'VENTA #19', '6.00', 'Eddy', '54f4e545-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('219', '660014', '4', '2026-01-12 10:23:36', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #20', '220.00', 'Eddy', '54f4e692-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('220', '660020', '4', '2026-01-12 10:24:26', 'VENTA', '-1.0000', '9.0000', '8.0000', 'VENTA #21', '570.00', 'Eddy', '54f4e7a9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('221', '881108', '4', '2026-01-30 10:55:57', 'SALIDA', '-1.0000', '1.0000', '0.0000', 'MERMA #2', '292.71', 'Admin', '54f4e8c1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('222', '660014', '4', '2026-01-30 10:58:32', 'DEVOLUCION', '1.0000', '4.0000', '5.0000', 'REFUND_ITEM_81', '220.00', 'CAJERO_REFUND', '54f4ea09-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('223', '660020', '4', '2026-01-30 10:58:37', 'DEVOLUCION', '1.0000', '8.0000', '9.0000', 'REFUND_ITEM_82', '570.00', 'CAJERO_REFUND', '54f4eb21-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('224', '756058841446', '4', '2026-01-02 11:36:03', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #6 (Fact: f64435)', '120.00', 'Admin', '54f4ec3a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('225', '660001', '4', '2026-01-29 08:24:46', 'VENTA', '-1.0000', '15.0000', '14.0000', 'VENTA #24', '35.00', 'Eddy', '54f4ed86-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('226', '660033', '4', '2026-01-29 08:24:46', 'VENTA', '-4.0000', '64.0000', '60.0000', 'VENTA #24', '20.00', 'Eddy', '54f4eed7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('227', '660004', '4', '2026-01-29 08:24:46', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #24', '370.00', 'Eddy', '54f4f027-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('228', '660011', '4', '2026-01-29 08:24:46', 'VENTA', '-5.0000', '19.0000', '14.0000', 'VENTA #24', '210.00', 'Eddy', '54f4f141-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('229', '660020', '4', '2026-01-29 08:26:41', 'VENTA', '-1.0000', '9.0000', '8.0000', 'VENTA #25', '570.00', 'Eddy', '54f4f2e2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('230', '660019', '4', '2026-01-29 08:26:41', 'VENTA', '-6.0000', '89.0000', '83.0000', 'VENTA #25', '33.00', 'Eddy', '54f4f409-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('231', '660021', '4', '2026-01-29 08:26:41', 'VENTA', '-3.0000', '16.0000', '13.0000', 'VENTA #25', '217.00', 'Eddy', '54f4f55a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('232', '660022', '4', '2026-01-29 08:26:41', 'VENTA', '-3.0000', '16.0000', '13.0000', 'VENTA #25', '210.00', 'Eddy', '54f4f676-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('233', '660025', '4', '2026-01-29 08:26:41', 'VENTA', '-1.0000', '11.0000', '10.0000', 'VENTA #25', '430.00', 'Eddy', '54f4f7c6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('234', '660026', '4', '2026-01-29 08:26:41', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #25', '430.00', 'Eddy', '54f4f8e1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('235', '660027', '4', '2026-01-29 08:26:41', 'VENTA', '-1.0000', '29.0000', '28.0000', 'VENTA #25', '162.57', 'Eddy', '54f4fe88-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('236', '660029', '4', '2026-01-29 08:26:41', 'VENTA', '-4.0000', '255.0000', '251.0000', 'VENTA #25', '8.00', 'Eddy', '54f4ffd5-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('237', '660012', '4', '2026-01-29 09:02:12', 'VENTA', '-17.0000', '48.0000', '31.0000', 'VENTA #26', '50.00', 'Eddy', '54f500ef-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('238', '660099', '4', '2026-01-29 09:02:12', 'VENTA', '-10.0000', '16.0000', '6.0000', 'VENTA #26', '65.00', 'Eddy', '54f5020b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('239', '660036', '4', '2026-01-29 09:02:12', 'VENTA', '-1.0000', '23.0000', '22.0000', 'VENTA #26', '135.00', 'Eddy', '54f50354-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('240', '660034', '4', '2026-01-29 09:02:12', 'VENTA', '-1.0000', '354.0000', '353.0000', 'VENTA #26', '6.00', 'Eddy', '54f5046f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('241', '660035', '4', '2026-01-29 09:02:12', 'VENTA', '-3.0000', '64.0000', '61.0000', 'VENTA #26', '15.00', 'Eddy', '54f50a1a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('242', '660023', '4', '2026-01-29 09:05:09', 'VENTA', '-9.0000', '33.0000', '24.0000', 'VENTA #27', '213.00', 'Eddy', '54f50b66-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('243', '660037', '4', '2026-01-29 09:05:09', 'VENTA', '-8.0000', '72.0000', '64.0000', 'VENTA #27', '210.00', 'Eddy', '54f50c7c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('244', '660026', '4', '2026-01-31 09:52:34', 'SALIDA', '2.0000', '0.0000', '2.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '430.00', 'Admin', '54f55fa4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('245', '660012', '4', '2026-01-31 09:52:34', 'SALIDA', '22.0000', '31.0000', '53.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '50.00', 'Admin', '54f562af-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('246', '660023', '4', '2026-01-31 09:52:34', 'SALIDA', '24.0000', '24.0000', '48.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '213.00', 'Admin', '54f56358-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('247', '660037', '4', '2026-01-31 09:52:34', 'SALIDA', '24.0000', '64.0000', '88.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '210.00', 'Admin', '54f563ed-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('248', '660032', '4', '2026-01-31 09:52:34', 'SALIDA', '24.0000', '48.0000', '72.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '190.00', 'Admin', '54f56658-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('249', '660036', '4', '2026-01-31 09:52:34', 'SALIDA', '27.0000', '22.0000', '49.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '135.00', 'Admin', '54f566f1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('250', '660033', '4', '2026-01-31 09:52:34', 'SALIDA', '-32.0000', '60.0000', '28.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '20.00', 'Admin', '54f569de-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('251', '660035', '4', '2026-01-31 09:52:34', 'SALIDA', '32.0000', '61.0000', '93.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '15.00', 'Admin', '54f56c61-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('252', '660034', '4', '2026-01-31 09:52:34', 'SALIDA', '180.0000', '353.0000', '533.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '6.00', 'Admin', '54f56ee2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('253', '756058841446', '4', '2026-01-31 10:08:03', 'ENTRADA', '2.0000', '2.0000', '4.0000', 'COMPRA #7', '120.00', 'Admin', '54f57162-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('254', '756058841446', '4', '2026-01-31 10:08:32', 'SALIDA', '2.0000', '4.0000', '6.0000', 'CANCELACION COMPRA #7 (POR ERROR)', '120.00', 'Admin', '54f5787e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('255', '756058841446', '4', '2026-01-31 10:09:07', 'SALIDA', '-2.0000', '6.0000', '4.0000', 'CANCELACION COMPRA #6 (POR ERROR)', '120.00', 'Admin', '54f578e9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('256', '756058841480', '4', '2026-02-01 08:39:18', 'ENTRADA', '2300.0000', '0.0000', '2300.0000', 'COMPRA #8', '100.00', 'Admin', '54f57948-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('257', '660010', '4', '2026-02-02 20:38:55', 'ENTRADA', '4.0000', '0.0000', '4.0000', 'COMPRA #9', '130.00', 'Admin', '54f579a6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('258', '660009', '4', '2026-02-02 20:38:55', 'ENTRADA', '6.0000', '-2.0000', '4.0000', 'COMPRA #9', '120.00', 'Admin', '54f57a00-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('259', '660017', '4', '2026-02-02 20:38:55', 'ENTRADA', '9.0000', '-6.0000', '3.0000', 'COMPRA #9', '72.00', 'Admin', '54f57a5b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('260', '756058841478', '4', '2026-02-02 20:38:55', 'ENTRADA', '7.0000', '-5.0000', '2.0000', 'COMPRA #9', '40.00', 'Admin', '54f57ab8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('261', '660098', '4', '2026-02-02 20:38:55', 'ENTRADA', '1.0000', '-1.0000', '0.0000', 'COMPRA #9', '2000.00', 'Admin', '54f57b13-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('262', '660043', '4', '2026-02-02 20:38:55', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #9', '700.00', 'Admin', '54f57b6c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('263', '756058841480', '4', '2026-02-01 20:39:04', 'SALIDA', '-2300.0000', '2300.0000', '0.0000', 'CANCELACION COMPRA #8 (POR ERROR)', '100.00', 'Admin', '54f57bc8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('264', '660001', '4', '2026-01-30 20:41:34', 'VENTA', '-1.0000', '14.0000', '13.0000', 'VENTA #28', '35.00', 'Admin', '54f57c26-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('265', '660033', '4', '2026-01-30 20:41:34', 'VENTA', '-2.0000', '60.0000', '58.0000', 'VENTA #28', '20.00', 'Admin', '54f57c83-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('266', '660002', '4', '2026-01-30 20:41:34', 'VENTA', '-4.0000', '22.0000', '18.0000', 'VENTA #28', '25.00', 'Admin', '54f57cde-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('267', '660004', '4', '2026-01-30 20:41:34', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #28', '370.00', 'Admin', '54f57d37-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('268', '660011', '4', '2026-01-30 20:41:34', 'VENTA', '-4.0000', '14.0000', '10.0000', 'VENTA #28', '210.00', 'Admin', '54f57d91-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('269', '660098', '4', '2026-01-30 20:54:53', 'VENTA', '-1.0000', '0.0000', '-1.0000', 'VENTA #29', '2000.00', 'Admin', '54f57de8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('270', '660043', '4', '2026-01-30 20:54:53', 'VENTA', '-1.0000', '0.0000', '-1.0000', 'VENTA #29', '700.00', 'Admin', '54f57e42-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('271', '660027', '4', '2026-01-30 20:56:11', 'VENTA', '-1.0000', '28.0000', '27.0000', 'VENTA #30', '162.57', 'Admin', '54f57e9b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('272', '660026', '4', '2026-02-01 21:26:22', 'SALIDA', '-2.0000', '2.0000', '0.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '430.00', 'Admin', '54f57ef3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('273', '660012', '4', '2026-02-01 21:26:22', 'SALIDA', '-22.0000', '53.0000', '31.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '50.00', 'Admin', '54f57f4e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('274', '660023', '4', '2026-02-01 21:26:22', 'SALIDA', '-24.0000', '48.0000', '24.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '213.00', 'Admin', '54f57fa8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('275', '660037', '4', '2026-02-01 21:26:22', 'SALIDA', '-24.0000', '88.0000', '64.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '210.00', 'Admin', '54f58001-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('276', '660032', '4', '2026-02-01 21:26:22', 'SALIDA', '-24.0000', '72.0000', '48.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '190.00', 'Admin', '54f5805a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('277', '660036', '4', '2026-02-01 21:26:22', 'SALIDA', '-27.0000', '49.0000', '22.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '135.00', 'Admin', '54f580b4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('278', '660033', '4', '2026-02-01 21:26:22', 'SALIDA', '-32.0000', '58.0000', '26.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '20.00', 'Admin', '54f5810d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('279', '660035', '4', '2026-02-01 21:26:22', 'SALIDA', '-32.0000', '93.0000', '61.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '15.00', 'Admin', '54f58167-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('280', '660034', '4', '2026-02-01 21:26:22', 'SALIDA', '-180.0000', '533.0000', '353.0000', 'CANCELACION COMPRA #4 (POR ERROR)', '6.00', 'Admin', '54f581c1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('281', '660019', '4', '2026-01-30 21:33:07', 'VENTA', '-2.0000', '83.0000', '81.0000', 'VENTA #31', '33.00', 'Admin', '54f5821b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('282', '660021', '4', '2026-01-30 21:33:07', 'VENTA', '-2.0000', '13.0000', '11.0000', 'VENTA #31', '217.00', 'Admin', '54f58274-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('283', '660022', '4', '2026-01-30 21:33:07', 'VENTA', '-3.0000', '13.0000', '10.0000', 'VENTA #31', '210.00', 'Admin', '54f582cd-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('284', '660025', '4', '2026-01-30 21:33:07', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #31', '430.00', 'Admin', '54f58329-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('285', '660034', '4', '2026-01-30 21:33:07', 'VENTA', '-41.0000', '353.0000', '312.0000', 'VENTA #31', '6.00', 'Admin', '54f58383-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('286', '660012', '4', '2026-01-30 21:33:07', 'VENTA', '-10.0000', '31.0000', '21.0000', 'VENTA #31', '50.00', 'Admin', '54f583da-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('287', '660099', '4', '2026-01-30 21:33:07', 'VENTA', '-3.0000', '6.0000', '3.0000', 'VENTA #31', '65.00', 'Admin', '54f58433-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('288', '660015', '4', '2026-01-30 21:35:17', 'VENTA', '-1.0000', '9.0000', '8.0000', 'VENTA #32', '300.00', 'Admin', '54f5848c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('289', '660032', '4', '2026-01-30 21:35:17', 'VENTA', '-7.0000', '48.0000', '41.0000', 'VENTA #32', '190.00', 'Admin', '54f584e4-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('290', '660036', '4', '2026-01-30 21:35:17', 'VENTA', '-1.0000', '22.0000', '21.0000', 'VENTA #32', '135.00', 'Admin', '54f58540-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('291', '660035', '4', '2026-01-30 21:35:17', 'VENTA', '-10.0000', '61.0000', '51.0000', 'VENTA #32', '15.00', 'Admin', '54f58598-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('292', '660017', '4', '2026-01-30 21:35:17', 'VENTA', '-2.0000', '0.0000', '-2.0000', 'VENTA #32', '88.00', 'Admin', '54f585f7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('293', '756058841478', '4', '2026-01-30 21:35:17', 'VENTA', '-3.0000', '0.0000', '-3.0000', 'VENTA #32', '40.00', 'Admin', '54f58651-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('294', '660037', '4', '2026-01-30 21:37:20', 'ENTRADA', '24.0000', '48.0000', '72.0000', 'COMPRA #10 (f000)', '210.00', 'Admin', '54f586ab-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('295', '660097', '4', '2026-01-30 21:37:20', 'ENTRADA', '4.0000', '0.0000', '4.0000', 'COMPRA #10 (f000)', '160.00', 'Admin', '54f58704-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('296', '660004', '4', '2026-01-30 21:37:20', 'ENTRADA', '1.0000', '2.0000', '3.0000', 'COMPRA #10 (f000)', '370.00', 'Admin', '54f5875f-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('297', '660004', '4', '2026-01-30 21:38:39', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #33', '370.00', 'Admin', '54f587ba-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('298', '660037', '4', '2026-01-30 21:38:39', 'VENTA', '-16.0000', '64.0000', '48.0000', 'VENTA #33', '210.00', 'Admin', '54f58815-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('299', '660097', '4', '2026-01-30 21:38:39', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #33', '160.00', 'Admin', '54f5886e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('300', '660029', '4', '2026-01-30 21:41:00', 'VENTA', '-1.0000', '251.0000', '250.0000', 'VENTA #34', '8.00', 'Admin', '54f588c9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('301', '660043', '4', '2026-02-02 18:41:43', 'ENTRADA', '1.0000', '-1.0000', '0.0000', 'COMPRA #11', '700.00', 'Admin', '54f58924-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('302', '660012', '4', '2026-02-02 18:41:43', 'ENTRADA', '20.0000', '21.0000', '41.0000', 'COMPRA #11', '50.00', 'Admin', '54f58980-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('303', '660017', '4', '2026-02-02 18:41:43', 'ENTRADA', '6.0000', '-2.0000', '4.0000', 'COMPRA #11', '72.00', 'Admin', '54f589dc-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('304', '660023', '4', '2026-02-02 18:41:43', 'ENTRADA', '24.0000', '24.0000', '48.0000', 'COMPRA #11', '213.00', 'Admin', '54f58a42-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('305', '660002', '4', '2026-02-02 18:41:43', 'ENTRADA', '10.0000', '18.0000', '28.0000', 'COMPRA #11', '25.00', 'Admin', '54f58c9e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('306', '660096', '4', '2026-02-02 18:44:49', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #12', '120.00', 'Admin', '54f58d03-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('307', '660031', '4', '2026-02-02 18:44:49', 'ENTRADA', '3.0000', '0.0000', '3.0000', 'COMPRA #12', '80.00', 'Admin', '54f58d60-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('308', '660017', '4', '2026-02-02 18:45:38', 'SALIDA', '-3.0000', '4.0000', '1.0000', 'MERMA #3', '72.00', 'Admin', '54f58dbb-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('309', '660094', '4', '2026-02-03 19:09:47', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #13', '200.00', 'Admin', '54f58e18-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('310', '756058841478', '4', '2026-02-03 19:09:47', 'ENTRADA', '4.0000', '2.0000', '6.0000', 'COMPRA #13', '40.00', 'Admin', '54f58e75-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('311', '660031', '4', '2026-02-03 19:09:47', 'ENTRADA', '2.0000', '1.0000', '3.0000', 'COMPRA #13', '80.00', 'Admin', '54f58f29-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('312', '660012', '4', '2026-02-03 19:09:47', 'ENTRADA', '12.0000', '42.0000', '54.0000', 'COMPRA #13', '50.00', 'Admin', '54f58f7d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('313', '660095', '4', '2026-02-03 19:09:47', 'ENTRADA', '4.0000', '-4.0000', '0.0000', 'COMPRA #13', '70.00', 'Admin', '54f58fd9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('314', '660093', '4', '2026-02-03 19:09:47', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #13', '180.00', 'Admin', '54f59034-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('315', '660026', '4', '2026-02-03 19:09:47', 'ENTRADA', '3.0000', '-1.0000', '2.0000', 'COMPRA #13', '430.00', 'Admin', '54f59091-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('316', '660017', '4', '2026-02-03 19:09:47', 'ENTRADA', '8.0000', '3.0000', '11.0000', 'COMPRA #13', '72.00', 'Admin', '54f590ea-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('317', '660037', '4', '2026-02-03 19:09:47', 'ENTRADA', '24.0000', '37.0000', '61.0000', 'COMPRA #13', '210.00', 'Admin', '54f59146-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('318', '990091', '4', '2026-02-03 19:09:47', 'ENTRADA', '24.0000', '-11.0000', '13.0000', 'COMPRA #13', '210.00', 'Admin', '54f591a3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('319', '660002', '4', '2026-01-31 19:12:03', 'VENTA', '-1.0000', '28.0000', '27.0000', 'VENTA #35', '25.00', 'Eddy', '54f591ff-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('320', '660019', '4', '2026-01-31 19:12:03', 'VENTA', '-6.0000', '81.0000', '75.0000', 'VENTA #35', '33.00', 'Eddy', '54f59259-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('321', '660015', '4', '2026-01-31 19:12:03', 'VENTA', '-2.0000', '8.0000', '6.0000', 'VENTA #35', '300.00', 'Eddy', '54f592b3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('322', '660097', '4', '2026-01-31 19:12:03', 'VENTA', '-3.0000', '3.0000', '0.0000', 'VENTA #35', '160.00', 'Eddy', '54f5930d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('323', '660009', '4', '2026-01-31 19:12:03', 'VENTA', '-2.0000', '0.0000', '-2.0000', 'VENTA #35', '120.00', 'Eddy', '54f59367-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('324', '660012', '4', '2026-01-31 19:12:03', 'VENTA', '-5.0000', '41.0000', '36.0000', 'VENTA #35', '50.00', 'Eddy', '54f593be-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('325', '660095', '4', '2026-01-31 19:12:19', 'VENTA', '-4.0000', '0.0000', '-4.0000', 'VENTA #36', '70.00', 'Eddy', '54f59418-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('326', '660012', '4', '2026-02-02 19:16:32', 'SALIDA', '-22.0000', '36.0000', '14.0000', 'MERMA #4', '50.00', 'Admin', '54f59471-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('327', '660033', '4', '2026-01-31 19:20:45', 'ENTRADA', '32.0000', '28.0000', '60.0000', 'COMPRA #14', '20.00', 'Admin', '54f594cb-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('328', '660033', '4', '2026-01-31 19:25:31', 'VENTA', '-2.0000', '26.0000', '24.0000', 'VENTA #37', '20.00', 'Eddy', '54f59524-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('329', '660001', '4', '2026-01-31 19:25:31', 'VENTA', '-1.0000', '13.0000', '12.0000', 'VENTA #37', '35.00', 'Eddy', '54f5957d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('330', '660021', '4', '2026-01-31 19:25:31', 'VENTA', '-2.0000', '11.0000', '9.0000', 'VENTA #37', '217.00', 'Eddy', '54f595d6-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('331', '660022', '4', '2026-01-31 19:25:31', 'VENTA', '-10.0000', '10.0000', '0.0000', 'VENTA #37', '210.00', 'Eddy', '54f59630-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('332', '660026', '4', '2026-01-31 19:25:31', 'VENTA', '-1.0000', '0.0000', '-1.0000', 'VENTA #37', '430.00', 'Eddy', '54f59687-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('333', '660027', '4', '2026-01-31 19:25:31', 'VENTA', '-1.0000', '27.0000', '26.0000', 'VENTA #37', '162.57', 'Eddy', '54f596e0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('334', '660034', '4', '2026-01-31 19:25:31', 'VENTA', '-5.0000', '312.0000', '307.0000', 'VENTA #37', '6.00', 'Eddy', '54f59739-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('335', '660099', '4', '2026-01-31 19:25:31', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #37', '65.00', 'Eddy', '54f59791-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('336', '660014', '4', '2026-01-31 19:25:31', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #37', '220.00', 'Eddy', '54f597e8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('337', '660017', '4', '2026-01-31 19:25:31', 'VENTA', '-7.0000', '1.0000', '-6.0000', 'VENTA #37', '88.00', 'Eddy', '54f59844-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('338', '660037', '4', '2026-01-31 19:25:31', 'VENTA', '-11.0000', '48.0000', '37.0000', 'VENTA #37', '210.00', 'Eddy', '54f598a1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('339', '990091', '4', '2026-01-31 19:25:31', 'VENTA', '-11.0000', '0.0000', '-11.0000', 'VENTA #37', '210.00', 'Eddy', '54f598fd-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('340', '660036', '4', '2026-01-31 19:25:31', 'VENTA', '-7.0000', '21.0000', '14.0000', 'VENTA #37', '135.00', 'Eddy', '54f59954-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('341', '660035', '4', '2026-01-31 19:25:31', 'VENTA', '-1.0000', '51.0000', '50.0000', 'VENTA #37', '15.00', 'Eddy', '54f599ac-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('342', '756058841478', '4', '2026-01-31 19:25:31', 'VENTA', '-2.0000', '-3.0000', '-5.0000', 'VENTA #37', '40.00', 'Eddy', '54f59a07-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('343', '660031', '4', '2026-01-31 19:25:54', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #38', '82.00', 'Eddy', '54f59a60-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('344', '660020', '4', '2026-02-02 19:42:25', 'SALIDA', '-1.0000', '8.0000', '7.0000', 'MERMA #5', '560.00', 'Admin', '54f59ab8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('345', '660011', '4', '2026-02-01 08:26:07', 'VENTA', '-2.0000', '10.0000', '8.0000', 'VENTA #39', '210.00', 'Eddy', '54f59b11-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('346', '660021', '4', '2026-02-01 08:26:07', 'VENTA', '-1.0000', '9.0000', '8.0000', 'VENTA #39', '217.00', 'Eddy', '54f59b6a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('347', '990091', '4', '2026-02-01 08:26:07', 'VENTA', '-4.0000', '13.0000', '9.0000', 'VENTA #39', '210.00', 'Eddy', '54f59bc2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('348', '660036', '4', '2026-02-01 08:26:07', 'VENTA', '-3.0000', '14.0000', '11.0000', 'VENTA #39', '135.00', 'Eddy', '54f59c1c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('349', '660025', '4', '2026-02-01 08:26:07', 'VENTA', '-2.0000', '9.0000', '7.0000', 'VENTA #39', '430.00', 'Eddy', '54f59c76-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('350', '660019', '4', '2026-02-01 08:40:54', 'VENTA', '-4.0000', '75.0000', '71.0000', 'VENTA #40', '33.00', 'Eddy', '54f59cce-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('351', '660026', '4', '2026-02-01 08:40:54', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #40', '430.00', 'Eddy', '54f59d29-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('352', '660027', '4', '2026-02-01 08:40:54', 'VENTA', '-6.0000', '26.0000', '20.0000', 'VENTA #40', '162.57', 'Eddy', '54f59d80-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('353', '660034', '4', '2026-02-01 08:40:54', 'VENTA', '-4.0000', '307.0000', '303.0000', 'VENTA #40', '6.00', 'Eddy', '54f59dd7-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('354', '660099', '4', '2026-02-01 08:40:54', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #40', '65.00', 'Eddy', '54f59f7b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('355', '660015', '4', '2026-02-01 08:40:54', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #40', '300.00', 'Eddy', '54f59fd9-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('356', '660014', '4', '2026-02-01 08:40:54', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #40', '220.00', 'Eddy', '54f5a032-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('357', '660017', '4', '2026-02-01 08:40:54', 'VENTA', '-6.0000', '11.0000', '5.0000', 'VENTA #40', '88.00', 'Eddy', '54f5a08a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('358', '756058841478', '4', '2026-02-01 08:40:54', 'VENTA', '-2.0000', '6.0000', '4.0000', 'VENTA #40', '40.00', 'Eddy', '54f5a0e3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('359', '660094', '4', '2026-02-01 08:40:54', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #40', '200.00', 'Eddy', '54f5a13d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('360', '660012', '4', '2026-02-01 08:40:54', 'VENTA', '-7.0000', '54.0000', '47.0000', 'VENTA #40', '50.00', 'Eddy', '54f5a198-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('361', '660043', '4', '2026-02-01 08:40:54', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #40', '700.00', 'Eddy', '54f5a1ef-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('362', '660010', '4', '2026-02-01 08:40:54', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #40', '130.00', 'Eddy', '54f5a248-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('363', '660033', '4', '2026-02-02 09:40:34', 'VENTA', '-3.0000', '24.0000', '21.0000', 'VENTA #41', '20.00', 'Eddy', '54f5a2a5-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('364', '660011', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #41', '210.00', 'Eddy', '54f5a301-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('365', '660037', '4', '2026-02-02 09:40:34', 'VENTA', '-2.0000', '61.0000', '59.0000', 'VENTA #41', '210.00', 'Eddy', '54f5a35a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('366', '660025', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '7.0000', '6.0000', 'VENTA #41', '430.00', 'Eddy', '54f5a3b3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('367', '660029', '4', '2026-02-02 09:40:34', 'VENTA', '-6.0000', '250.0000', '244.0000', 'VENTA #41', '8.00', 'Eddy', '54f5a40c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('368', '660034', '4', '2026-02-02 09:40:34', 'VENTA', '-29.0000', '303.0000', '274.0000', 'VENTA #41', '6.00', 'Eddy', '54f5a466-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('369', '660017', '4', '2026-02-02 09:40:34', 'VENTA', '-3.0000', '5.0000', '2.0000', 'VENTA #41', '88.00', 'Eddy', '54f5a4bd-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('370', '660093', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #41', '180.00', 'Eddy', '54f5a513-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('371', '660012', '4', '2026-02-02 09:40:34', 'VENTA', '-10.0000', '47.0000', '37.0000', 'VENTA #41', '50.00', 'Eddy', '54f5a56d-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('372', '660096', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #41', '120.00', 'Eddy', '54f5a5c8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('373', '660043', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #41', '700.00', 'Eddy', '54f5a620-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('374', '660021', '4', '2026-02-02 09:40:34', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #41', '217.00', 'Eddy', '54f5a67a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('375', '660036', '4', '2026-02-04 09:55:48', 'ENTRADA', '3.0000', '11.0000', '14.0000', 'COMPRA #15', '135.00', 'Admin', '54f5a6d2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('376', '660018', '4', '2026-02-04 09:57:03', 'SALIDA', '-2.0000', '4.0000', '2.0000', 'MERMA #6', '580.00', 'Admin', '54f5a72b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('377', '660032', '4', '2026-02-04 09:58:42', 'SALIDA', '-24.0000', '41.0000', '17.0000', 'MERMA #7', '190.00', 'Admin', '54f5a785-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('378', '660037', '4', '2026-02-04 10:00:47', 'SALIDA', '-48.0000', '59.0000', '11.0000', 'MERMA #8', '210.00', 'Admin', '54f5a7dc-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('379', '660023', '4', '2026-02-04 10:01:18', 'SALIDA', '-24.0000', '48.0000', '24.0000', 'MERMA #9', '213.00', 'Admin', '54f5a837-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('380', '660034', '4', '2026-02-04 10:01:52', 'SALIDA', '-180.0000', '274.0000', '94.0000', 'MERMA #10', '6.00', 'Admin', '54f5a892-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('381', '660035', '4', '2026-02-04 10:02:42', 'SALIDA', '-29.0000', '50.0000', '21.0000', 'MERMA #11', '15.00', 'Admin', '54f5a8ea-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('382', '756058841478', '4', '2026-02-04 10:22:30', 'SALIDA', '-4.0000', '4.0000', '0.0000', 'MERMA #12', '40.00', 'Admin', '54f5a940-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('383', '660012', '4', '2026-02-04 10:24:06', 'ENTRADA', '1.0000', '37.0000', '38.0000', 'COMPRA #16', '50.00', 'Admin', '54f5a999-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('384', '660033', '4', '2026-02-03 10:40:12', 'VENTA', '-1.0000', '21.0000', '20.0000', 'VENTA #42', '20.00', 'Eddy', '54f5a9f1-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('385', '660021', '4', '2026-02-03 10:40:12', 'VENTA', '-3.0000', '7.0000', '4.0000', 'VENTA #42', '217.00', 'Eddy', '54f5aa4a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('386', '660025', '4', '2026-02-03 10:40:12', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #42', '430.00', 'Eddy', '54f5aaa5-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('387', '660027', '4', '2026-02-03 10:40:12', 'VENTA', '-1.0000', '44.0000', '43.0000', 'VENTA #42', '162.57', 'Eddy', '54f5ab01-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('388', '660034', '4', '2026-02-03 10:40:12', 'VENTA', '-8.0000', '94.0000', '86.0000', 'VENTA #42', '6.00', 'Eddy', '54f5ab5c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('389', '660017', '4', '2026-02-03 10:40:12', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #42', '88.00', 'Eddy', '54f5ad87-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('390', '660031', '4', '2026-02-03 10:40:12', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #42', '82.00', 'Eddy', '54f5ade2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('391', '660035', '4', '2026-02-03 10:40:12', 'VENTA', '-4.0000', '21.0000', '17.0000', 'VENTA #42', '15.00', 'Eddy', '54f5ae3b-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('392', '660012', '4', '2026-02-03 10:51:07', 'ENTRADA', '28.0000', '14.0000', '42.0000', 'COMPRA #17', '50.00', 'Admin', '54f5ae94-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('393', '660090', '4', '2026-02-03 10:51:07', 'ENTRADA', '4.0000', '0.0000', '4.0000', 'COMPRA #17', '1150.00', 'Admin', '54f5aeee-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('394', '660016', '4', '2026-02-03 10:51:07', 'ENTRADA', '3.0000', '0.0000', '3.0000', 'COMPRA #17', '620.00', 'Admin', '54f5af4a-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('395', '660089', '4', '2026-02-03 10:51:07', 'ENTRADA', '24.0000', '0.0000', '24.0000', 'COMPRA #17', '20.00', 'Admin', '54f5afa3-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('396', '660088', '4', '2026-02-03 10:51:07', 'ENTRADA', '10.0000', '0.0000', '10.0000', 'COMPRA #17', '18.00', 'Admin', '54f5affe-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('397', '660087', '4', '2026-02-03 10:51:07', 'ENTRADA', '7.0000', '0.0000', '7.0000', 'COMPRA #17', '143.00', 'Admin', '54f5b058-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('398', '660087', '4', '2026-02-03 10:51:07', 'ENTRADA', '25.0000', '7.0000', '32.0000', 'COMPRA #17', '40.00', 'Admin', '54f5b0b0-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('399', '660100', '4', '2026-02-03 10:59:41', 'ENTRADA', '25.0000', '0.0000', '25.0000', 'COMPRA #18', '40.00', 'Admin', '54f5b10c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('400', '660007', '4', '2026-02-03 10:59:41', 'ENTRADA', '70.0000', '0.0000', '70.0000', 'COMPRA #18', '20.00', 'Admin', '54f5b164-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('402', '660102', '4', '2026-02-03 10:59:41', 'ENTRADA', '3.0000', '0.0000', '3.0000', 'COMPRA #18', '170.00', 'Admin', '54f5b217-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('403', '660103', '4', '2026-02-03 10:59:41', 'ENTRADA', '10.0000', '0.0000', '10.0000', 'COMPRA #18', '130.00', 'Admin', '54f5b26e-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('404', '660104', '4', '2026-02-03 11:04:23', 'ENTRADA', '10.0000', '0.0000', '10.0000', 'COMPRA #19', '120.00', 'Admin', '54f5b2c8-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('405', '660012', '4', '2026-02-03 11:08:00', 'VENTA', '-9.0000', '38.0000', '29.0000', 'VENTA #43', '50.00', 'Eddy', '54f5b320-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('406', '660016', '4', '2026-02-03 11:08:00', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #43', '620.00', 'Eddy', '54f5b379-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('407', '660007', '4', '2026-02-03 11:08:00', 'VENTA', '-1.0000', '70.0000', '69.0000', 'VENTA #43', '20.00', 'Eddy', '54f5b3d2-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('408', '660017', '4', '2026-02-03 11:21:13', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #44', '88.00', 'Eddy', '54f5b42c-01f4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('409', '660033', '4', '2026-02-04 11:00:24', 'VENTA', '-2.0000', '20.0000', '18.0000', 'VENTA #70', '20.00', 'Eddy', 'f28dccc0-0374-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('410', '660011', '4', '2026-02-04 12:10:31', 'VENTA', '-2.0000', '7.0000', '5.0000', 'VENTA #71', '210.00', 'Sistema', '84d9f676-f7b6-48eb-b31e-48a43588d60b', '4');
INSERT INTO `kardex` VALUES ('411', '660033', '4', '2026-02-04 16:02:51', 'VENTA', '-2.0000', '18.0000', '16.0000', 'VENTA #72', '20.00', 'Sistema', 'e912fa71-885b-432a-901d-969b92a37d2a', '4');
INSERT INTO `kardex` VALUES ('412', '660011', '4', '2026-02-04 16:02:51', 'VENTA', '-2.0000', '5.0000', '3.0000', 'VENTA #72', '210.00', 'Sistema', '5f37d981-bc9e-40e0-a077-5381bed96cb9', '4');
INSERT INTO `kardex` VALUES ('413', '660021', '4', '2026-02-04 16:02:51', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #72', '217.00', 'Sistema', '0fc10a02-fc41-486e-b129-edf921d6af4e', '4');
INSERT INTO `kardex` VALUES ('414', '660037', '4', '2026-02-04 16:02:51', 'VENTA', '-10.0000', '35.0000', '25.0000', 'VENTA #72', '210.00', 'Sistema', '621a0de6-a82c-4196-96a4-93a97ac6af22', '4');
INSERT INTO `kardex` VALUES ('415', '990091', '4', '2026-02-04 16:02:51', 'VENTA', '-8.0000', '9.0000', '1.0000', 'VENTA #73', '210.00', 'Sistema', 'c04a4f28-3b63-429c-9441-ef8db57e47d3', '4');
INSERT INTO `kardex` VALUES ('416', '660033', '4', '2026-02-07 09:02:05', 'DEVOLUCION', '2.0000', '16.0000', '18.0000', 'REFUND_ITEM_219', '20.00', 'CAJERO_REFUND', '959d117f-042d-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('417', '660011', '4', '2026-02-07 09:07:50', 'DEVOLUCION', '2.0000', '3.0000', '5.0000', 'REFUND_ITEM_220', '210.00', 'CAJERO_REFUND', 'kdx_6987473641b1e', '4');
INSERT INTO `kardex` VALUES ('418', '660023', '4', '2026-02-04 09:45:26', 'VENTA', '-9.0000', '24.0000', '15.0000', 'VENTA #86', '213.00', 'Sistema', 'kdx_69875006ca84c', '4');
INSERT INTO `kardex` VALUES ('419', '660036', '4', '2026-02-04 09:45:26', 'VENTA', '-8.0000', '14.0000', '6.0000', 'VENTA #86', '135.00', 'Sistema', 'kdx_69875006ccb6e', '4');
INSERT INTO `kardex` VALUES ('420', '660025', '4', '2026-02-04 09:46:06', 'VENTA', '-2.0000', '5.0000', '3.0000', 'VENTA #87', '430.00', 'Sistema', 'kdx_6987502eec81f', '4');
INSERT INTO `kardex` VALUES ('421', '660020', '4', '2026-02-04 09:47:06', 'VENTA', '-1.0000', '12.0000', '11.0000', 'VENTA #88', '570.00', 'Sistema', 'kdx_6987506adf187', '4');
INSERT INTO `kardex` VALUES ('422', '660027', '4', '2026-02-04 09:47:06', 'VENTA', '-1.0000', '43.0000', '42.0000', 'VENTA #88', '162.57', 'Sistema', 'kdx_6987506adfb74', '4');
INSERT INTO `kardex` VALUES ('423', '660027', '4', '2026-02-04 09:48:07', 'ENTRADA', '24.0000', '20.0000', '44.0000', 'COMPRA #20', '160.00', 'Admin', 'kdx_698750a756b08', '4');
INSERT INTO `kardex` VALUES ('424', '660006', '4', '2026-02-04 09:48:07', 'ENTRADA', '12.0000', '0.0000', '12.0000', 'COMPRA #20', '212.00', 'Admin', 'kdx_698750a7587f9', '4');
INSERT INTO `kardex` VALUES ('425', '660034', '4', '2026-02-04 09:49:29', 'VENTA', '-20.0000', '86.0000', '66.0000', 'VENTA #89', '6.00', 'Sistema', 'kdx_698750f958485', '4');
INSERT INTO `kardex` VALUES ('426', '660015', '4', '2026-02-04 09:49:29', 'VENTA', '-2.0000', '5.0000', '3.0000', 'VENTA #89', '300.00', 'Sistema', 'kdx_698750f958f3b', '4');
INSERT INTO `kardex` VALUES ('427', '660014', '4', '2026-02-04 09:49:29', 'VENTA', '-2.0000', '8.0000', '6.0000', 'VENTA #89', '220.00', 'Sistema', 'kdx_698750f95989c', '4');
INSERT INTO `kardex` VALUES ('428', '660009', '4', '2026-02-04 09:49:29', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #89', '120.00', 'Sistema', 'kdx_698750f95a21b', '4');
INSERT INTO `kardex` VALUES ('429', '660093', '4', '2026-02-04 09:49:29', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #89', '180.00', 'Sistema', 'kdx_698750f95ab3c', '4');
INSERT INTO `kardex` VALUES ('430', '660010', '4', '2026-02-04 09:49:29', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #89', '130.00', 'Sistema', 'kdx_698750f95b41d', '4');
INSERT INTO `kardex` VALUES ('431', '660012', '4', '2026-02-04 09:50:01', 'VENTA', '-17.0000', '46.0000', '29.0000', 'VENTA #90', '50.00', 'Sistema', 'kdx_698751193d302', '4');
INSERT INTO `kardex` VALUES ('432', '660090', '4', '2026-02-04 09:50:14', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #91', '1150.00', 'Sistema', 'kdx_698751263c094', '4');
INSERT INTO `kardex` VALUES ('433', '660088', '4', '2026-02-04 09:50:38', 'VENTA', '-2.0000', '10.0000', '8.0000', 'VENTA #92', '18.00', 'Sistema', 'kdx_6987513eefb80', '4');
INSERT INTO `kardex` VALUES ('434', '660089', '4', '2026-02-04 09:50:49', 'VENTA', '-2.0000', '24.0000', '22.0000', 'VENTA #93', '20.00', 'Sistema', 'kdx_69875149b621c', '4');
INSERT INTO `kardex` VALUES ('435', '660087', '4', '2026-02-07 09:57:23', 'SALIDA', '-25.0000', '32.0000', '7.0000', 'MERMA #14', '62.53', 'Admin', 'kdx_698752d3bd385', '4');
INSERT INTO `kardex` VALUES ('436', '660087', '4', '2026-02-04 09:58:21', 'VENTA', '-3.0000', '7.0000', '4.0000', 'VENTA #94', '62.53', 'Sistema', 'kdx_6987530de8916', '4');
INSERT INTO `kardex` VALUES ('437', '660100', '4', '2026-02-04 09:58:59', 'VENTA', '-3.0000', '25.0000', '22.0000', 'VENTA #95', '40.00', 'Sistema', 'kdx_69875333392d5', '4');
INSERT INTO `kardex` VALUES ('438', '660007', '4', '2026-02-04 09:59:05', 'VENTA', '-2.0000', '69.0000', '67.0000', 'VENTA #96', '20.00', 'Sistema', 'kdx_698753392d796', '4');
INSERT INTO `kardex` VALUES ('439', '660102', '4', '2026-02-04 09:59:26', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #97', '170.00', 'Sistema', 'kdx_6987534e087f5', '4');
INSERT INTO `kardex` VALUES ('440', '660103', '4', '2026-02-04 09:59:26', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #97', '130.00', 'Sistema', 'kdx_6987534e092a2', '4');
INSERT INTO `kardex` VALUES ('441', '660006', '4', '2026-02-04 09:59:36', 'VENTA', '-1.0000', '12.0000', '11.0000', 'VENTA #98', '212.00', 'Sistema', 'kdx_6987535864d3a', '4');
INSERT INTO `kardex` VALUES ('442', '660001', '4', '2026-02-05 10:18:53', 'VENTA', '-2.0000', '12.0000', '10.0000', 'VENTA #99', '35.00', 'Sistema', 'kdx_698757dd90381', '4');
INSERT INTO `kardex` VALUES ('443', '660033', '4', '2026-02-05 10:18:53', 'VENTA', '-1.0000', '18.0000', '17.0000', 'VENTA #99', '20.00', 'Sistema', 'kdx_698757dd90e2d', '4');
INSERT INTO `kardex` VALUES ('444', '660011', '4', '2026-02-05 10:19:40', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #100', '210.00', 'Sistema', 'kdx_6987580cc1923', '4');
INSERT INTO `kardex` VALUES ('445', '660021', '4', '2026-02-05 10:19:40', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #100', '217.00', 'Sistema', 'kdx_6987580cc2307', '4');
INSERT INTO `kardex` VALUES ('446', '660037', '4', '2026-02-05 10:19:40', 'VENTA', '-1.0000', '25.0000', '24.0000', 'VENTA #100', '210.00', 'Sistema', 'kdx_6987580cc2bf3', '4');
INSERT INTO `kardex` VALUES ('447', '990091', '4', '2026-02-05 10:20:45', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #101', '210.00', 'Sistema', 'kdx_6987584daba07', '4');
INSERT INTO `kardex` VALUES ('448', '660023', '4', '2026-02-05 10:27:03', 'VENTA', '-1.0000', '15.0000', '14.0000', 'VENTA #102', '213.00', 'Sistema', 'kdx_698759c757a4c', '4');
INSERT INTO `kardex` VALUES ('449', '660036', '4', '2026-02-05 10:27:03', 'VENTA', '-6.0000', '6.0000', '0.0000', 'VENTA #102', '135.00', 'Sistema', 'kdx_698759c7583ac', '4');
INSERT INTO `kardex` VALUES ('450', '660025', '4', '2026-02-05 10:27:03', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #102', '430.00', 'Sistema', 'kdx_698759c758c35', '4');
INSERT INTO `kardex` VALUES ('451', '660019', '4', '2026-02-05 10:27:03', 'VENTA', '-4.0000', '71.0000', '67.0000', 'VENTA #102', '33.00', 'Sistema', 'kdx_698759c7594c0', '4');
INSERT INTO `kardex` VALUES ('452', '660029', '4', '2026-02-05 10:28:05', 'VENTA', '-4.0000', '244.0000', '240.0000', 'VENTA #103', '8.00', 'Sistema', 'kdx_69875a05462e0', '4');
INSERT INTO `kardex` VALUES ('453', '660034', '4', '2026-02-05 10:28:05', 'VENTA', '-5.0000', '66.0000', '61.0000', 'VENTA #103', '6.00', 'Sistema', 'kdx_69875a0547b2e', '4');
INSERT INTO `kardex` VALUES ('454', '660015', '4', '2026-02-05 10:28:05', 'VENTA', '-3.0000', '3.0000', '0.0000', 'VENTA #103', '300.00', 'Sistema', 'kdx_69875a05483c4', '4');
INSERT INTO `kardex` VALUES ('455', '660014', '4', '2026-02-05 10:28:05', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #103', '220.00', 'Sistema', 'kdx_69875a0548c8b', '4');
INSERT INTO `kardex` VALUES ('456', '660035', '4', '2026-02-05 10:28:33', 'VENTA', '-1.0000', '20.0000', '19.0000', 'VENTA #104', '15.00', 'Sistema', 'kdx_69875a21cd642', '4');
INSERT INTO `kardex` VALUES ('457', '660012', '4', '2026-02-05 10:29:06', 'VENTA', '-12.0000', '29.0000', '17.0000', 'VENTA #105', '50.00', 'Sistema', 'kdx_69875a4269b49', '4');
INSERT INTO `kardex` VALUES ('458', '660088', '4', '2026-02-05 10:29:32', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #106', '18.00', 'Sistema', 'kdx_69875a5c71a2a', '4');
INSERT INTO `kardex` VALUES ('459', '440001', '4', '2026-02-05 11:06:14', 'ENTRADA', '8.0000', '0.0000', '8.0000', 'COMPRA #21', '90.00', 'Admin', 'kdx_698762f603f20', '4');
INSERT INTO `kardex` VALUES ('460', '660026', '4', '2026-02-05 11:06:14', 'ENTRADA', '3.0000', '0.0000', '3.0000', 'COMPRA #21', '430.00', 'Admin', 'kdx_698762f605862', '4');
INSERT INTO `kardex` VALUES ('461', '660087', '4', '2026-02-05 11:11:52', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #107', '62.53', 'Sistema', 'kdx_698764490ac59', '4');
INSERT INTO `kardex` VALUES ('462', '660103', '4', '2026-02-05 11:11:52', 'VENTA', '-1.0000', '9.0000', '8.0000', 'VENTA #107', '130.00', 'Sistema', 'kdx_698764490b542', '4');
INSERT INTO `kardex` VALUES ('463', '660007', '4', '2026-02-05 11:11:52', 'VENTA', '-11.0000', '67.0000', '56.0000', 'VENTA #107', '20.00', 'Sistema', 'kdx_698764490bd9e', '4');
INSERT INTO `kardex` VALUES ('464', '440001', '4', '2026-02-05 11:12:27', 'VENTA', '-8.0000', '12.0000', '4.0000', 'VENTA #108', '90.00', 'Sistema', 'kdx_6987646bbfeed', '4');
INSERT INTO `kardex` VALUES ('465', '660020', '4', '2026-02-06 09:03:42', 'VENTA', '-6.0000', '11.0000', '5.0000', 'VENTA #109', '570.00', 'Sistema', 'kdx_698897be7e6f1', '4');
INSERT INTO `kardex` VALUES ('466', '660018', '4', '2026-02-06 09:03:42', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #109', '580.00', 'Sistema', 'kdx_698897be7ef93', '4');
INSERT INTO `kardex` VALUES ('467', '660019', '4', '2026-02-06 09:03:42', 'VENTA', '-5.0000', '67.0000', '62.0000', 'VENTA #109', '33.00', 'Sistema', 'kdx_698897be7f76a', '4');
INSERT INTO `kardex` VALUES ('468', '660009', '4', '2026-02-06 09:03:42', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #109', '120.00', 'Sistema', 'kdx_698897be7ff1a', '4');
INSERT INTO `kardex` VALUES ('469', '660034', '4', '2026-02-06 09:03:42', 'VENTA', '-2.0000', '61.0000', '59.0000', 'VENTA #109', '6.00', 'Sistema', 'kdx_698897be80772', '4');
INSERT INTO `kardex` VALUES ('470', '660100', '4', '2026-02-06 09:03:42', 'VENTA', '-3.0000', '22.0000', '19.0000', 'VENTA #109', '40.00', 'Sistema', 'kdx_698897be80f3b', '4');
INSERT INTO `kardex` VALUES ('471', '660090', '4', '2026-02-06 09:03:42', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #109', '1150.00', 'Sistema', 'kdx_698897be816f1', '4');
INSERT INTO `kardex` VALUES ('472', '660013', '4', '2026-02-06 09:07:39', 'ENTRADA', '16.0000', '2.0000', '18.0000', 'COMPRA #22', '35.00', 'Admin', 'kdx_698898ab1d392', '4');
INSERT INTO `kardex` VALUES ('473', '660020', '4', '2026-02-06 09:07:39', 'ENTRADA', '5.0000', '7.0000', '12.0000', 'COMPRA #22', '570.00', 'Admin', 'kdx_698898ab1e093', '4');
INSERT INTO `kardex` VALUES ('474', '660018', '4', '2026-02-06 09:07:39', 'ENTRADA', '2.0000', '2.0000', '4.0000', 'COMPRA #22', '580.00', 'Admin', 'kdx_698898ab1fd81', '4');
INSERT INTO `kardex` VALUES ('475', '660096', '4', '2026-02-06 09:07:39', 'ENTRADA', '4.0000', '1.0000', '5.0000', 'COMPRA #22', '120.00', 'Admin', 'kdx_698898ab20b0a', '4');
INSERT INTO `kardex` VALUES ('476', '660003', '4', '2026-02-06 09:07:39', 'ENTRADA', '8.0000', '0.0000', '8.0000', 'COMPRA #22', '360.00', 'Admin', 'kdx_698898ab225cf', '4');
INSERT INTO `kardex` VALUES ('477', '660037', '4', '2026-02-06 09:07:39', 'ENTRADA', '24.0000', '11.0000', '35.0000', 'COMPRA #22', '210.00', 'Admin', 'kdx_698898ab2372e', '4');
INSERT INTO `kardex` VALUES ('478', '660012', '4', '2026-02-06 09:07:39', 'ENTRADA', '17.0000', '29.0000', '46.0000', 'COMPRA #22', '50.00', 'Admin', 'kdx_698898ab243f9', '4');
INSERT INTO `kardex` VALUES ('479', '660017', '4', '2026-02-06 09:07:39', 'ENTRADA', '11.0000', '0.0000', '11.0000', 'COMPRA #22', '88.00', 'Admin', 'kdx_698898ab25053', '4');
INSERT INTO `kardex` VALUES ('480', '660014', '4', '2026-02-06 09:07:39', 'ENTRADA', '5.0000', '3.0000', '8.0000', 'COMPRA #22', '220.00', 'Admin', 'kdx_698898ab25d2f', '4');
INSERT INTO `kardex` VALUES ('481', '440001', '4', '2026-02-06 09:07:39', 'ENTRADA', '4.0000', '8.0000', '12.0000', 'COMPRA #22', '90.00', 'Admin', 'kdx_698898ab26b01', '4');
INSERT INTO `kardex` VALUES ('482', '660013', '4', '2026-02-06 09:08:19', 'VENTA', '-4.0000', '18.0000', '14.0000', 'VENTA #110', '35.00', 'Sistema', 'kdx_698898d390333', '4');
INSERT INTO `kardex` VALUES ('483', '660012', '4', '2026-02-06 09:08:19', 'VENTA', '-10.0000', '17.0000', '7.0000', 'VENTA #110', '50.00', 'Sistema', 'kdx_698898d390cb1', '4');
INSERT INTO `kardex` VALUES ('484', '660017', '4', '2026-02-06 09:08:19', 'VENTA', '-1.0000', '15.0000', '14.0000', 'VENTA #110', '88.00', 'Sistema', 'kdx_698898d391527', '4');
INSERT INTO `kardex` VALUES ('485', '660029', '4', '2026-02-06 09:17:55', 'VENTA', '-16.0000', '240.0000', '224.0000', 'VENTA #111', '8.00', 'Sistema', 'kdx_69889b139d1ef', '4');
INSERT INTO `kardex` VALUES ('486', '660003', '4', '2026-02-06 09:17:55', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #111', '360.00', 'Sistema', 'kdx_69889b139e11a', '4');
INSERT INTO `kardex` VALUES ('487', '660001', '4', '2026-02-06 10:10:46', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #112', '35.00', 'Sistema', 'kdx_6988a77647586', '4');
INSERT INTO `kardex` VALUES ('488', '660033', '4', '2026-02-06 10:10:46', 'VENTA', '-5.0000', '17.0000', '12.0000', 'VENTA #112', '20.00', 'Sistema', 'kdx_6988a77647ef1', '4');
INSERT INTO `kardex` VALUES ('489', '660008', '4', '2026-02-06 10:11:16', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #113', '150.00', 'Sistema', 'kdx_6988a794742c1', '4');
INSERT INTO `kardex` VALUES ('490', '660011', '4', '2026-02-06 10:11:16', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #113', '210.00', 'Sistema', 'kdx_6988a79474b77', '4');
INSERT INTO `kardex` VALUES ('491', '660023', '4', '2026-02-06 10:11:53', 'VENTA', '-4.0000', '14.0000', '10.0000', 'VENTA #114', '213.00', 'Sistema', 'kdx_6988a7b98d5bb', '4');
INSERT INTO `kardex` VALUES ('492', '660019', '4', '2026-02-06 10:12:44', 'VENTA', '-1.0000', '62.0000', '61.0000', 'VENTA #115', '33.00', 'Sistema', 'kdx_6988a7ec06b9b', '4');
INSERT INTO `kardex` VALUES ('493', '660027', '4', '2026-02-06 10:12:55', 'VENTA', '-7.0000', '42.0000', '35.0000', 'VENTA #116', '162.57', 'Sistema', 'kdx_6988a7f7e9e40', '4');
INSERT INTO `kardex` VALUES ('494', '660034', '4', '2026-02-06 10:13:22', 'VENTA', '-7.0000', '59.0000', '52.0000', 'VENTA #117', '6.00', 'Sistema', 'kdx_6988a8125aeb0', '4');
INSERT INTO `kardex` VALUES ('495', '660087', '4', '2026-02-06 10:13:53', 'VENTA', '-3.0000', '3.0000', '0.0000', 'VENTA #118', '62.53', 'Sistema', 'kdx_6988a831a42f3', '4');
INSERT INTO `kardex` VALUES ('496', '660104', '4', '2026-02-06 10:15:45', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #119', '120.00', 'Sistema', 'kdx_6988a8a13952e', '4');
INSERT INTO `kardex` VALUES ('497', '660007', '4', '2026-02-06 10:15:45', 'VENTA', '-3.0000', '56.0000', '53.0000', 'VENTA #119', '20.00', 'Sistema', 'kdx_6988a8a139e19', '4');
INSERT INTO `kardex` VALUES ('498', '440001', '4', '2026-02-06 10:15:45', 'VENTA', '-4.0000', '4.0000', '0.0000', 'VENTA #119', '90.00', 'Sistema', 'kdx_6988a8a13a5ed', '4');
INSERT INTO `kardex` VALUES ('499', '660014', '4', '2026-02-06 10:15:45', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #119', '220.00', 'Sistema', 'kdx_6988a8a13adbf', '4');
INSERT INTO `kardex` VALUES ('500', '660017', '4', '2026-02-06 10:15:45', 'VENTA', '-5.0000', '14.0000', '9.0000', 'VENTA #119', '88.00', 'Sistema', 'kdx_6988a8a13c5d5', '4');
INSERT INTO `kardex` VALUES ('501', '660012', '4', '2026-02-06 10:15:45', 'VENTA', '-7.0000', '7.0000', '0.0000', 'VENTA #119', '50.00', 'Sistema', 'kdx_6988a8a13ceb5', '4');
INSERT INTO `kardex` VALUES ('502', '660035', '4', '2026-02-06 14:33:49', 'ENTRADA', '3.0000', '17.0000', '20.0000', 'COMPRA #23', '15.00', 'Admin', 'kdx_6988e51d55efe', '4');
INSERT INTO `kardex` VALUES ('503', '660017', '4', '2026-02-08 14:44:34', 'DEVOLUCION', '5.0000', '14.0000', '19.0000', 'REFUND_ITEM_305', '88.00', 'CAJERO_REFUND', 'kdx_6988e7a2dd628', '4');
INSERT INTO `kardex` VALUES ('504', '660017', '4', '2026-02-06 14:45:06', 'VENTA', '-4.0000', '19.0000', '15.0000', 'VENTA #121', '88.00', 'Sistema', 'kdx_6988e7c2f314d', '4');
INSERT INTO `kardex` VALUES ('505', '660001', '4', '2026-02-07 14:50:34', 'VENTA', '-2.0000', '9.0000', '7.0000', 'VENTA #122', '35.00', 'Sistema', 'kdx_6988e90a10839', '4');
INSERT INTO `kardex` VALUES ('506', '660033', '4', '2026-02-07 14:50:34', 'VENTA', '-4.0000', '12.0000', '8.0000', 'VENTA #122', '20.00', 'Sistema', 'kdx_6988e90a1111f', '4');
INSERT INTO `kardex` VALUES ('507', '660017', '4', '2026-02-07 19:25:31', 'ENTRADA', '4.0000', '11.0000', '15.0000', 'COMPRA #24', '88.00', 'Admin', 'kdx_6989297b287df', '4');
INSERT INTO `kardex` VALUES ('508', '660030', '4', '2026-02-07 19:25:31', 'ENTRADA', '4.0000', '0.0000', '4.0000', 'COMPRA #24', '180.00', 'Admin', 'kdx_6989297b2aa48', '4');
INSERT INTO `kardex` VALUES ('509', '881108', '4', '2026-02-07 19:25:31', 'ENTRADA', '3.0000', '0.0000', '3.0000', 'COMPRA #24', '292.71', 'Admin', 'kdx_6989297b2b906', '4');
INSERT INTO `kardex` VALUES ('510', '660026', '4', '2026-02-07 20:01:26', 'VENTA', '-3.0000', '3.0000', '0.0000', 'VENTA #123', '430.00', 'Sistema', 'kdx_698931e662e06', '4');
INSERT INTO `kardex` VALUES ('511', '660032', '4', '2026-02-07 20:01:26', 'VENTA', '-4.0000', '17.0000', '13.0000', 'VENTA #123', '190.00', 'Sistema', 'kdx_698931e66379d', '4');
INSERT INTO `kardex` VALUES ('512', '660025', '4', '2026-02-07 20:01:26', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #123', '430.00', 'Sistema', 'kdx_698931e66407e', '4');
INSERT INTO `kardex` VALUES ('513', '660013', '4', '2026-02-07 20:01:26', 'VENTA', '-10.0000', '14.0000', '4.0000', 'VENTA #123', '35.00', 'Sistema', 'kdx_698931e664867', '4');
INSERT INTO `kardex` VALUES ('514', '660096', '4', '2026-02-07 20:01:26', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #123', '120.00', 'Sistema', 'kdx_698931e6662af', '4');
INSERT INTO `kardex` VALUES ('515', '660014', '4', '2026-02-07 20:01:26', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #123', '220.00', 'Sistema', 'kdx_698931e666bb7', '4');
INSERT INTO `kardex` VALUES ('516', '660031', '4', '2026-02-07 20:02:33', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #124', '82.00', 'Sistema', 'kdx_69893229a0162', '4');
INSERT INTO `kardex` VALUES ('517', '660006', '4', '2026-02-07 10:58:42', 'VENTA', '-1.0000', '11.0000', '10.0000', 'VENTA #125', '212.00', 'Sistema', 'kdx_698b55b2c15b9', '4');
INSERT INTO `kardex` VALUES ('518', '660005', '4', '2026-02-07 11:00:46', 'VENTA', '-2.0000', '25.0000', '23.0000', 'VENTA #126', '130.00', 'Sistema', 'kdx_698b562e48c3e', '4');
INSERT INTO `kardex` VALUES ('519', '660011', '4', '2026-02-07 11:01:05', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #127', '210.00', 'Sistema', 'kdx_698b5641c1c46', '4');
INSERT INTO `kardex` VALUES ('520', '660023', '4', '2026-02-07 11:02:38', 'VENTA', '-9.0000', '34.0000', '25.0000', 'VENTA #128', '213.00', 'Sistema', 'kdx_698b569ea782d', '4');
INSERT INTO `kardex` VALUES ('521', '660032', '4', '2026-02-07 11:02:38', 'VENTA', '-5.0000', '13.0000', '8.0000', 'VENTA #128', '190.00', 'Sistema', 'kdx_698b569ea88f3', '4');
INSERT INTO `kardex` VALUES ('522', '660037', '4', '2026-02-07 11:02:38', 'VENTA', '-24.0000', '24.0000', '0.0000', 'VENTA #128', '210.00', 'Sistema', 'kdx_698b569ea91cb', '4');
INSERT INTO `kardex` VALUES ('523', '660020', '4', '2026-02-07 11:03:12', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #129', '570.00', 'Sistema', 'kdx_698b56c084e18', '4');
INSERT INTO `kardex` VALUES ('524', '660018', '4', '2026-02-07 11:43:15', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #130', '580.00', 'Sistema', 'kdx_698b6023af80c', '4');
INSERT INTO `kardex` VALUES ('525', '660019', '4', '2026-02-07 11:43:15', 'VENTA', '-1.0000', '61.0000', '60.0000', 'VENTA #130', '33.00', 'Sistema', 'kdx_698b6023b02e0', '4');
INSERT INTO `kardex` VALUES ('526', '660027', '4', '2026-02-07 11:43:15', 'VENTA', '-6.0000', '35.0000', '29.0000', 'VENTA #130', '162.57', 'Sistema', 'kdx_698b6023b15e6', '4');
INSERT INTO `kardex` VALUES ('527', '660034', '4', '2026-02-07 11:43:15', 'VENTA', '-29.0000', '52.0000', '23.0000', 'VENTA #130', '6.00', 'Sistema', 'kdx_698b6023b1f5d', '4');
INSERT INTO `kardex` VALUES ('528', '660096', '4', '2026-02-07 11:47:51', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #131', '120.00', 'Sistema', 'kdx_698b6137c40d6', '4');
INSERT INTO `kardex` VALUES ('529', '660007', '4', '2026-02-07 11:47:51', 'VENTA', '-14.0000', '53.0000', '39.0000', 'VENTA #131', '20.00', 'Sistema', 'kdx_698b6137c54bf', '4');
INSERT INTO `kardex` VALUES ('530', '660014', '4', '2026-02-07 11:47:51', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #131', '220.00', 'Sistema', 'kdx_698b6137c5db7', '4');
INSERT INTO `kardex` VALUES ('531', '660017', '4', '2026-02-07 11:47:51', 'VENTA', '-7.0000', '15.0000', '8.0000', 'VENTA #131', '88.00', 'Sistema', 'kdx_698b6137c65ce', '4');
INSERT INTO `kardex` VALUES ('532', '660010', '4', '2026-02-07 11:53:18', 'VENTA', '-1.0000', '5.0000', '4.0000', 'VENTA #132', '130.00', 'Sistema', 'kdx_698b627ee5d73', '4');
INSERT INTO `kardex` VALUES ('533', '660001', '4', '2026-02-08 12:12:38', 'VENTA', '-4.0000', '7.0000', '3.0000', 'VENTA #133', '35.00', 'Sistema', 'kdx_698b6706caff8', '4');
INSERT INTO `kardex` VALUES ('534', '660033', '4', '2026-02-08 12:12:38', 'VENTA', '-4.0000', '8.0000', '4.0000', 'VENTA #133', '20.00', 'Sistema', 'kdx_698b6706cba23', '4');
INSERT INTO `kardex` VALUES ('535', '660005', '4', '2026-02-08 12:12:38', 'VENTA', '-1.0000', '23.0000', '22.0000', 'VENTA #133', '130.00', 'Sistema', 'kdx_698b6706cc380', '4');
INSERT INTO `kardex` VALUES ('536', '660013', '4', '2026-02-08 12:12:38', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #133', '35.00', 'Sistema', 'kdx_698b6706ccc6f', '4');
INSERT INTO `kardex` VALUES ('537', '660034', '4', '2026-02-08 12:12:38', 'VENTA', '-23.0000', '23.0000', '0.0000', 'VENTA #133', '6.00', 'Sistema', 'kdx_698b6706cd520', '4');
INSERT INTO `kardex` VALUES ('538', '660029', '4', '2026-02-08 12:12:38', 'VENTA', '-14.0000', '224.0000', '210.0000', 'VENTA #133', '8.00', 'Sistema', 'kdx_698b6706cdd82', '4');
INSERT INTO `kardex` VALUES ('539', '660035', '4', '2026-02-08 12:14:14', 'VENTA', '-2.0000', '19.0000', '17.0000', 'VENTA #134', '15.00', 'Sistema', 'kdx_698b6766ae318', '4');
INSERT INTO `kardex` VALUES ('540', '660096', '4', '2026-02-08 12:14:14', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #134', '120.00', 'Sistema', 'kdx_698b6766aec22', '4');
INSERT INTO `kardex` VALUES ('541', '660016', '4', '2026-02-08 12:14:14', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #134', '620.00', 'Sistema', 'kdx_698b6766af49a', '4');
INSERT INTO `kardex` VALUES ('542', '660103', '4', '2026-02-08 12:14:14', 'VENTA', '-1.0000', '8.0000', '7.0000', 'VENTA #134', '130.00', 'Sistema', 'kdx_698b6766b0c14', '4');
INSERT INTO `kardex` VALUES ('543', '660014', '4', '2026-02-08 12:15:38', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #135', '220.00', 'Sistema', 'kdx_698b67ba9412b', '4');
INSERT INTO `kardex` VALUES ('544', '881108', '4', '2026-02-08 12:15:38', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #135', '292.71', 'Sistema', 'kdx_698b67ba94a14', '4');
INSERT INTO `kardex` VALUES ('545', '660023', '4', '2026-02-08 12:21:55', 'ENTRADA', '24.0000', '10.0000', '34.0000', 'COMPRA #25', '213.00', 'Admin', 'kdx_698b6933a699c', '4');
INSERT INTO `kardex` VALUES ('546', '660021', '4', '2026-02-08 12:21:55', 'ENTRADA', '24.0000', '0.0000', '24.0000', 'COMPRA #25', '217.00', 'Admin', 'kdx_698b6933a7eba', '4');
INSERT INTO `kardex` VALUES ('547', '660010', '4', '2026-02-08 12:22:41', 'ENTRADA', '4.0000', '1.0000', '5.0000', 'COMPRA #26', '130.00', 'Admin', 'kdx_698b6961418cc', '4');
INSERT INTO `kardex` VALUES ('548', '660015', '4', '2026-02-08 12:22:41', 'ENTRADA', '1.0000', '0.0000', '1.0000', 'COMPRA #26', '300.00', 'Admin', 'kdx_698b6961434bf', '4');
INSERT INTO `kardex` VALUES ('549', '660010', '4', '2026-02-08 12:24:30', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #136', '130.00', 'Sistema', 'kdx_698b69ce8e75a', '4');
INSERT INTO `kardex` VALUES ('550', '660023', '4', '2026-02-08 12:24:30', 'VENTA', '-23.0000', '25.0000', '2.0000', 'VENTA #136', '213.00', 'Sistema', 'kdx_698b69ce8f059', '4');
INSERT INTO `kardex` VALUES ('551', '660021', '4', '2026-02-08 12:25:05', 'VENTA', '-4.0000', '24.0000', '20.0000', 'VENTA #137', '217.00', 'Sistema', 'kdx_698b69f158500', '4');
INSERT INTO `kardex` VALUES ('552', '881108', '4', '2026-02-08 12:25:05', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #137', '292.71', 'Sistema', 'kdx_698b69f158dd5', '4');
INSERT INTO `kardex` VALUES ('553', '756058841446', '4', '2026-02-11 09:34:10', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #138', '120.00', 'Admin', 'kdx_0ZKlBBzYbN3Mc', '4');
INSERT INTO `kardex` VALUES ('554', '756058841446', '4', '2026-02-11 14:26:29', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #139', '120.00', 'Eddy', 'kdx_vGQaVqGkonwql', '4');
INSERT INTO `kardex` VALUES ('555', '756058841446', '4', '2026-02-11 17:57:10', 'VENTA', '-1.0000', '1.0000', '0.0000', 'VENTA #140', '120.00', 'Eddy', 'kdx_wpfjZo1KvZMyR', '4');
INSERT INTO `kardex` VALUES ('556', '660009', '4', '2026-02-08 13:02:40', 'ENTRADA', '4.0000', '2.0000', '6.0000', 'COMPRA #27', '120.00', 'Admin', 'kdx_698e15c07daae', '4');
INSERT INTO `kardex` VALUES ('557', '881108', '4', '2026-02-12 13:03:48', 'SALIDA', '-1.0000', '1.0000', '0.0000', 'MERMA #15', '292.71', 'Admin', 'kdx_698e1604a87d9', '4');
INSERT INTO `kardex` VALUES ('558', '660015', '4', '2026-02-08 13:06:53', 'ENTRADA', '3.0000', '1.0000', '4.0000', 'COMPRA #28', '300.00', 'Admin', 'kdx_698e16bde6c25', '4');
INSERT INTO `kardex` VALUES ('559', '660015', '4', '2026-02-08 13:07:59', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #145', '0.00', 'Sistema', 'kdx_698e1775b8c9f', '4');
INSERT INTO `kardex` VALUES ('560', '660015', '4', '2026-02-12 13:12:27', 'DEVOLUCION', '1.0000', '3.0000', '4.0000', 'REFUND_ITEM_357', '0.00', 'CAJERO_REFUND', 'kdx_698e180b80aee', '4');
INSERT INTO `kardex` VALUES ('561', '660017', '4', '2026-02-08 13:13:46', 'ENTRADA', '5.0000', '9.0000', '14.0000', 'COMPRA #29', '88.00', 'Admin', 'kdx_698e185a6a78d', '4');
INSERT INTO `kardex` VALUES ('562', '660017', '4', '2026-02-08 13:13:59', 'VENTA', '-5.0000', '18.0000', '13.0000', 'VENTA #147', '0.00', 'Sistema', 'kdx_698e187c4baf0', '4');
INSERT INTO `kardex` VALUES ('563', '660021', '4', '2026-02-12 13:21:04', 'DEVOLUCION', '4.0000', '20.0000', '24.0000', 'REFUND_ITEM_348', '0.00', 'CAJERO_REFUND', 'kdx_698e1a10a5179', '4');
INSERT INTO `kardex` VALUES ('564', '660021', '4', '2026-02-08 13:21:15', 'VENTA', '-4.0000', '24.0000', '20.0000', 'VENTA #150', '0.00', 'Sistema', 'kdx_698e1a30a251f', '4');
INSERT INTO `kardex` VALUES ('565', '881108', '4', '2026-02-12 13:23:16', 'DEVOLUCION', '1.0000', '0.0000', '1.0000', 'REFUND_ITEM_345', '0.00', 'CAJERO_REFUND', 'kdx_698e1a941dd46', '4');
INSERT INTO `kardex` VALUES ('566', '881108', '4', '2026-02-12 13:23:48', 'DEVOLUCION', '1.0000', '1.0000', '2.0000', 'REFUND_ITEM_349', '0.00', 'CAJERO_REFUND', 'kdx_698e1ab4e4f63', '4');
INSERT INTO `kardex` VALUES ('567', '660015', '4', '2026-02-08 13:24:09', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #153', '0.00', 'Sistema', 'kdx_698e1ade53fd4', '4');
INSERT INTO `kardex` VALUES ('569', '660033', '4', '2026-02-09 13:53:40', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c91283d', '4');
INSERT INTO `kardex` VALUES ('570', '660005', '4', '2026-02-09 13:53:40', 'VENTA', '-4.0000', '22.0000', '18.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c91337e', '4');
INSERT INTO `kardex` VALUES ('571', '660032', '4', '2026-02-09 13:53:40', 'VENTA', '-2.0000', '8.0000', '6.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c914982', '4');
INSERT INTO `kardex` VALUES ('572', '660023', '4', '2026-02-09 13:53:40', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c91545a', '4');
INSERT INTO `kardex` VALUES ('573', '660020', '4', '2026-02-09 13:53:40', 'VENTA', '-2.0000', '4.0000', '2.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c915e34', '4');
INSERT INTO `kardex` VALUES ('574', '660019', '4', '2026-02-09 13:53:40', 'VENTA', '-2.0000', '60.0000', '58.0000', 'VENTA #155', '0.00', 'Sistema', 'kdx_698e21c9167be', '4');
INSERT INTO `kardex` VALUES ('575', '660027', '4', '2026-02-09 13:55:05', 'VENTA', '0.0000', '29.0000', '29.0000', 'VENTA #156', '162.57', 'Sistema', 'kdx_698e221e57d25', '4');
INSERT INTO `kardex` VALUES ('576', '660029', '4', '2026-02-09 13:55:05', 'VENTA', '-9.0000', '210.0000', '201.0000', 'VENTA #156', '0.00', 'Sistema', 'kdx_698e221e586bb', '4');
INSERT INTO `kardex` VALUES ('577', '660035', '4', '2026-02-09 13:55:05', 'VENTA', '-1.0000', '17.0000', '16.0000', 'VENTA #156', '0.00', 'Sistema', 'kdx_698e221e59006', '4');
INSERT INTO `kardex` VALUES ('578', '660096', '4', '2026-02-09 13:55:05', 'VENTA', '-2.0000', '2.0000', '0.0000', 'VENTA #156', '0.00', 'Sistema', 'kdx_698e221e5986a', '4');
INSERT INTO `kardex` VALUES ('579', '660103', '4', '2026-02-09 13:55:05', 'VENTA', '-3.0000', '7.0000', '4.0000', 'VENTA #156', '0.00', 'Sistema', 'kdx_698e221e5a0a9', '4');
INSERT INTO `kardex` VALUES ('580', '660104', '4', '2026-02-09 13:55:05', 'VENTA', '-3.0000', '9.0000', '6.0000', 'VENTA #156', '0.00', 'Sistema', 'kdx_698e221e5a8fd', '4');
INSERT INTO `kardex` VALUES ('581', '660007', '4', '2026-02-09 13:55:38', 'VENTA', '-6.0000', '39.0000', '33.0000', 'VENTA #157', '0.00', 'Sistema', 'kdx_698e223f7d3e7', '4');
INSERT INTO `kardex` VALUES ('582', '660017', '4', '2026-02-09 13:56:15', 'VENTA', '-3.0000', '13.0000', '10.0000', 'VENTA #158', '0.00', 'Sistema', 'kdx_698e22646da62', '4');
INSERT INTO `kardex` VALUES ('583', '660015', '4', '2026-02-09 13:56:15', 'VENTA', '-1.0000', '3.0000', '2.0000', 'VENTA #158', '0.00', 'Sistema', 'kdx_698e22646f428', '4');
INSERT INTO `kardex` VALUES ('584', '660021', '4', '2026-02-09 13:56:15', 'VENTA', '-2.0000', '20.0000', '18.0000', 'VENTA #158', '0.00', 'Sistema', 'kdx_698e226470ea6', '4');
INSERT INTO `kardex` VALUES ('585', '660030', '4', '2026-02-09 13:58:55', 'VENTA', '-1.0000', '4.0000', '3.0000', 'VENTA #159', '0.00', 'Sistema', 'kdx_698e2304017d0', '4');
INSERT INTO `kardex` VALUES ('586', '660010', '4', '2026-02-09 13:58:55', 'VENTA', '-2.0000', '3.0000', '1.0000', 'VENTA #159', '0.00', 'Sistema', 'kdx_698e230402ae8', '4');
INSERT INTO `kardex` VALUES ('587', '440002', '4', '2026-02-10 14:09:11', 'ENTRADA', '24.0000', '0.0000', '24.0000', 'COMPRA #30', '200.00', 'Admin', 'kdx_698e2557999b6', '4');
INSERT INTO `kardex` VALUES ('588', '440001', '4', '2026-02-10 14:09:11', 'ENTRADA', '15.0000', '0.0000', '15.0000', 'COMPRA #30', '90.00', 'Admin', 'kdx_698e25579aa34', '4');
INSERT INTO `kardex` VALUES ('589', '660017', '4', '2026-02-10 14:09:11', 'ENTRADA', '10.0000', '8.0000', '18.0000', 'COMPRA #30', '88.00', 'Admin', 'kdx_698e25579ba12', '4');
INSERT INTO `kardex` VALUES ('590', '660026', '4', '2026-02-10 14:09:11', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #30', '430.00', 'Admin', 'kdx_698e25579c9bf', '4');
INSERT INTO `kardex` VALUES ('591', '660025', '4', '2026-02-10 14:09:11', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #30', '430.00', 'Admin', 'kdx_698e25579dbda', '4');
INSERT INTO `kardex` VALUES ('592', '660015', '4', '2026-02-10 14:12:49', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #160', '0.00', 'Sistema', 'kdx_698e2646c086e', '4');
INSERT INTO `kardex` VALUES ('593', '660089', '4', '2026-02-10 14:12:49', 'VENTA', '-2.0000', '22.0000', '20.0000', 'VENTA #160', '0.00', 'Sistema', 'kdx_698e2646c11e7', '4');
INSERT INTO `kardex` VALUES ('594', '660032', '4', '2026-02-10 14:12:49', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #160', '0.00', 'Sistema', 'kdx_698e2646c19f0', '4');
INSERT INTO `kardex` VALUES ('595', '440002', '4', '2026-02-10 14:12:49', 'VENTA', '-1.0000', '24.0000', '23.0000', 'VENTA #160', '0.00', 'Sistema', 'kdx_698e2646c2249', '4');
INSERT INTO `kardex` VALUES ('596', '440001', '4', '2026-02-10 14:12:49', 'VENTA', '-5.0000', '15.0000', '10.0000', 'VENTA #160', '0.00', 'Sistema', 'kdx_698e2646c2a89', '4');
INSERT INTO `kardex` VALUES ('597', '660032', '4', '2026-02-10 14:13:55', 'VENTA', '-5.0000', '5.0000', '0.0000', 'VENTA #161', '0.00', 'Sistema', 'kdx_698e26881cb92', '4');
INSERT INTO `kardex` VALUES ('598', '440002', '4', '2026-02-10 14:13:55', 'VENTA', '-5.0000', '23.0000', '18.0000', 'VENTA #161', '0.00', 'Sistema', 'kdx_698e26881d610', '4');
INSERT INTO `kardex` VALUES ('599', '660019', '4', '2026-02-10 14:13:55', 'VENTA', '-5.0000', '58.0000', '53.0000', 'VENTA #161', '0.00', 'Sistema', 'kdx_698e26881e010', '4');
INSERT INTO `kardex` VALUES ('600', '660027', '4', '2026-02-10 14:13:55', 'VENTA', '-2.0000', '29.0000', '27.0000', 'VENTA #161', '162.57', 'Sistema', 'kdx_698e26881e9be', '4');
INSERT INTO `kardex` VALUES ('601', '660029', '4', '2026-02-10 14:15:23', 'VENTA', '-4.0000', '201.0000', '197.0000', 'VENTA #162', '0.00', 'Sistema', 'kdx_698e26e0d8a8d', '4');
INSERT INTO `kardex` VALUES ('602', '660035', '4', '2026-02-10 14:15:23', 'VENTA', '-2.0000', '16.0000', '14.0000', 'VENTA #162', '0.00', 'Sistema', 'kdx_698e26e0d95b8', '4');
INSERT INTO `kardex` VALUES ('603', '660009', '4', '2026-02-10 14:15:23', 'VENTA', '-1.0000', '6.0000', '5.0000', 'VENTA #162', '0.00', 'Sistema', 'kdx_698e26e0da0c1', '4');
INSERT INTO `kardex` VALUES ('604', '660090', '4', '2026-02-10 14:15:23', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #162', '0.00', 'Sistema', 'kdx_698e26e0dabc1', '4');
INSERT INTO `kardex` VALUES ('605', '660007', '4', '2026-02-10 14:15:23', 'VENTA', '-1.0000', '33.0000', '32.0000', 'VENTA #162', '0.00', 'Sistema', 'kdx_698e26e0db5e0', '4');
INSERT INTO `kardex` VALUES ('606', '660030', '4', '2026-02-10 14:17:02', 'VENTA', '-3.0000', '3.0000', '0.0000', 'VENTA #163', '0.00', 'Sistema', 'kdx_698e274325bbe', '4');
INSERT INTO `kardex` VALUES ('607', '660021', '4', '2026-02-10 14:17:02', 'VENTA', '-1.0000', '18.0000', '17.0000', 'VENTA #163', '0.00', 'Sistema', 'kdx_698e274326543', '4');
INSERT INTO `kardex` VALUES ('608', '660002', '4', '2026-02-10 14:17:02', 'VENTA', '-2.0000', '27.0000', '25.0000', 'VENTA #163', '0.00', 'Sistema', 'kdx_698e274326d9c', '4');
INSERT INTO `kardex` VALUES ('609', '440001', '4', '2026-02-10 14:17:02', 'VENTA', '-1.0000', '10.0000', '9.0000', 'VENTA #163', '0.00', 'Sistema', 'kdx_698e274327607', '4');
INSERT INTO `kardex` VALUES ('610', '660026', '4', '2026-02-10 14:17:02', 'VENTA', '-1.0000', '2.0000', '1.0000', 'VENTA #163', '0.00', 'Sistema', 'kdx_698e274327e83', '4');
INSERT INTO `kardex` VALUES ('611', '440002', '1', '2026-02-11 20:06:16', 'VENTA', '-9.0000', '0.0000', '-9.0000', 'Venta #180 (Sistema)', '200.00', 'Sistema', '1eb00e51-087b-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `kardex` VALUES ('612', '440002', '1', '2026-02-11 20:10:52', 'VENTA', '-1.0000', '-9.0000', '-10.0000', 'Venta #181 (Sistema)', '200.00', 'Sistema', '1ec962b8-087b-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `kardex` VALUES ('613', '660020', '1', '2026-02-11 20:15:52', 'VENTA', '-1.0000', '0.0000', '-1.0000', 'Venta #182 (Sistema)', '570.00', 'Sistema', '1edc243c-087b-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `kardex` VALUES ('618', '440002', '1', '2026-02-13 08:54:54', 'AJUSTE_POSITIVO', '10.0000', '-10.0000', '0.0000', 'Corrección de stock negativo (a 0) - Ajuste Sistema (Corrección Saldos Negativos)', '200.00', 'Sistema', '92ebb6bf-08e3-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `kardex` VALUES ('619', '660020', '1', '2026-02-13 08:54:54', 'AJUSTE_POSITIVO', '1.0000', '-1.0000', '0.0000', 'Corrección de stock negativo (a 0) - Ajuste Sistema (Corrección Saldos Negativos)', '570.00', 'Sistema', '92ec0e8c-08e3-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `kardex` VALUES ('624', '660101', '4', '2026-02-08 13:26:07', 'VENTA', '-1.0000', '0.0000', '-1.0000', 'Venta #154 (Efectivo)', '25.00', 'Sistema', '07fab79d-08e4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('625', '660101', '4', '2026-02-11 00:28:11', 'DEVOLUCION', '1.0000', '-1.0000', '0.0000', 'Venta #183 (Efectivo)', '25.00', 'Sistema', '07fb88f5-08e4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('626', '660101', '4', '2026-02-11 02:00:36', 'DEVOLUCION', '1.0000', '0.0000', '1.0000', 'Venta #185 (Efectivo)', '25.00', 'Sistema', '07fc5f7a-08e4-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('628', '991118', '4', '2026-02-13 12:40:11', 'AJUSTE_INTERNO', '1000.0000', '0.0000', '1000.0000', 'ajuste manual', '1.20', 'Sistema', '0c15af0d-0903-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('629', '660027', '4', '2026-02-11 09:26:53', 'VENTA', '-1.0000', '27.0000', '26.0000', 'Venta #187 (Eddy)', '162.57', 'Sistema', '5f8dc616-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('630', '660029', '4', '2026-02-11 09:26:53', 'VENTA', '-7.0000', '197.0000', '190.0000', 'Venta #187 (Eddy)', '8.00', 'Sistema', '5f8e3364-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('631', '660035', '4', '2026-02-11 09:26:53', 'VENTA', '-2.0000', '14.0000', '12.0000', 'Venta #187 (Eddy)', '15.00', 'Sistema', '5f8e8a26-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('632', '660101', '4', '2026-02-11 09:26:53', 'VENTA', '-1.0000', '1.0000', '0.0000', 'Venta #187 (Eddy)', '25.00', 'Sistema', '5f8ed792-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('633', '660100', '4', '2026-02-11 09:26:53', 'VENTA', '-3.0000', '19.0000', '16.0000', 'Venta #187 (Eddy)', '40.00', 'Sistema', '5f8f2922-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('634', '660103', '4', '2026-02-11 09:26:53', 'VENTA', '-1.0000', '4.0000', '3.0000', 'Venta #187 (Eddy)', '130.00', 'Sistema', '5f8f72e1-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('635', '660007', '4', '2026-02-11 09:29:48', 'VENTA', '-7.0000', '32.0000', '25.0000', 'Venta #188 (Eddy)', '20.00', 'Sistema', 'c82246c7-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('636', '881108', '4', '2026-02-11 09:29:48', 'VENTA', '-1.0000', '2.0000', '1.0000', 'Venta #188 (Eddy)', '292.71', 'Sistema', 'c82298d4-0a7a-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('637', '660021', '4', '2026-02-11 09:31:38', 'VENTA', '-3.0000', '17.0000', '14.0000', 'Venta #189 (Eddy)', '217.00', 'Sistema', '0973e2bd-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('638', '660017', '4', '2026-02-11 09:31:38', 'VENTA', '-2.0000', '18.0000', '16.0000', 'Venta #189 (Eddy)', '88.00', 'Sistema', '09743142-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('639', '660021', '4', '2026-02-11 09:32:11', 'VENTA', '-1.0000', '14.0000', '13.0000', 'Venta #190 (Eddy)', '217.00', 'Sistema', '1d6c1697-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('640', '660021', '4', '2026-02-11 09:35:34', 'VENTA', '-5.0000', '13.0000', '8.0000', 'Venta #191 (Eddy)', '217.00', 'Sistema', '962333ac-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('641', '660010', '4', '2026-02-11 09:35:34', 'VENTA', '-1.0000', '1.0000', '0.0000', 'Venta #191 (Eddy)', '130.00', 'Sistema', '96238492-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('642', '440001', '4', '2026-02-11 09:35:34', 'VENTA', '-9.0000', '9.0000', '0.0000', 'Venta #191 (Eddy)', '90.00', 'Sistema', '9623d6bd-0a7b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('643', '660012', '4', '2026-02-11 09:40:12', 'ENTRADA', '20.0000', '0.0000', '20.0000', 'COMPRA #31 (f122)', '60.00', 'Sistema', '3c4914cf-0a7c-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('644', '660017', '4', '2026-02-11 09:40:12', 'ENTRADA', '10.0000', '16.0000', '26.0000', 'COMPRA #31 (f122)', '88.00', 'Sistema', '3c498fbf-0a7c-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('645', '660017', '4', '2026-02-11 12:01:22', 'VENTA', '-8.0000', '26.0000', '18.0000', 'Venta #192 (Eddy)', '88.00', 'Sistema', 'f469c3a4-0a8f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('646', '660025', '4', '2026-02-11 12:25:44', 'VENTA', '-1.0000', '2.0000', '1.0000', 'Venta #193 (Eddy)', '430.00', 'Sistema', '5c3bead2-0a93-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('647', '660012', '4', '2026-02-11 12:46:49', 'VENTA', '-18.0000', '20.0000', '2.0000', 'Venta #194 (Eddy)', '60.00', 'Sistema', '4e10b188-0a96-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('648', '660101', '4', '2026-02-15 12:53:14', 'AJUSTE_INTERNO', '6.0000', '0.0000', '6.0000', 'error anterior\r\n', '25.00', 'Sistema', '33b3005a-0a97-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('649', '660001', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '3.0000', '1.0000', 'Venta #195 (Eddy)', '35.00', 'Sistema', 'ebb9f247-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('650', '440002', '4', '2026-02-12 13:12:42', 'VENTA', '-8.0000', '18.0000', '10.0000', 'Venta #195 (Eddy)', '200.00', 'Sistema', 'ebba4224-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('651', '660029', '4', '2026-02-12 13:12:42', 'VENTA', '-3.0000', '190.0000', '187.0000', 'Venta #195 (Eddy)', '8.00', 'Sistema', 'ebbb3c43-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('652', '660009', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '5.0000', '3.0000', 'Venta #195 (Eddy)', '120.00', 'Sistema', 'ebbc3530-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('653', '660088', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '7.0000', '5.0000', 'Venta #195 (Eddy)', '18.00', 'Sistema', 'ebbc9842-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('654', '660100', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '16.0000', '14.0000', 'Venta #195 (Eddy)', '40.00', 'Sistema', 'ebbd052c-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('655', '660103', '4', '2026-02-12 13:12:42', 'VENTA', '-1.0000', '3.0000', '2.0000', 'Venta #195 (Eddy)', '130.00', 'Sistema', 'ebbe3f75-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('656', '660006', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '10.0000', '8.0000', 'Venta #195 (Eddy)', '212.00', 'Sistema', 'ebbe8d7a-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('657', '660007', '4', '2026-02-12 13:12:42', 'VENTA', '-5.0000', '25.0000', '20.0000', 'Venta #195 (Eddy)', '20.00', 'Sistema', 'ebbf90a1-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('658', '660021', '4', '2026-02-12 13:12:42', 'VENTA', '-2.0000', '8.0000', '6.0000', 'Venta #195 (Eddy)', '217.00', 'Sistema', 'ebbfdf79-0a99-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('659', '660015', '4', '2026-02-12 13:25:02', 'ENTRADA', '11.0000', '1.0000', '12.0000', 'COMPRA #32', '300.00', 'Sistema', 'a5064206-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('660', '660043', '4', '2026-02-12 13:25:02', 'ENTRADA', '1.0000', '0.0000', '1.0000', 'COMPRA #32', '700.00', 'Sistema', 'a50784ab-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('661', '440003', '4', '2026-02-12 13:25:02', 'ENTRADA', '1.0000', '0.0000', '1.0000', 'COMPRA #32', '1100.00', 'Sistema', 'a509baa4-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('662', '440001', '4', '2026-02-12 13:25:02', 'ENTRADA', '6.0000', '0.0000', '6.0000', 'COMPRA #32', '90.00', 'Sistema', 'a50afabe-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('663', '660017', '4', '2026-02-12 13:25:02', 'ENTRADA', '8.0000', '18.0000', '26.0000', 'COMPRA #32', '88.00', 'Sistema', 'a50c1706-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('664', '660031', '4', '2026-02-12 13:25:02', 'ENTRADA', '1.0000', '0.0000', '1.0000', 'COMPRA #32', '82.00', 'Sistema', 'a50e07b7-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('665', '660014', '4', '2026-02-12 13:25:02', 'ENTRADA', '6.0000', '0.0000', '6.0000', 'COMPRA #32', '220.00', 'Sistema', 'a50fe993-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('666', '660026', '4', '2026-02-12 13:25:02', 'ENTRADA', '1.0000', '1.0000', '2.0000', 'COMPRA #32', '430.00', 'Sistema', 'a511478e-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('667', '660025', '4', '2026-02-12 13:25:02', 'ENTRADA', '1.0000', '1.0000', '2.0000', 'COMPRA #32', '430.00', 'Sistema', 'a511ad2e-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('668', '660012', '4', '2026-02-12 13:25:02', 'ENTRADA', '2.0000', '2.0000', '4.0000', 'COMPRA #32', '60.00', 'Sistema', 'a512389c-0a9b-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('669', '660015', '4', '2026-02-15 13:34:54', 'AJUSTE_INTERNO', '-1.0000', '12.0000', '11.0000', 'error', '300.00', 'Sistema', '05c60eb4-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('670', '660017', '4', '2026-02-15 13:36:27', 'AJUSTE_INTERNO', '-8.0000', '26.0000', '18.0000', 'error', '88.00', 'Sistema', '3ccc3ed7-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('671', '440005', '4', '2026-02-12 13:38:34', 'ENTRADA', '2.0000', '0.0000', '2.0000', 'COMPRA #34', '500.00', 'Sistema', '88989cf7-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('672', '660010', '4', '2026-02-12 13:38:34', 'ENTRADA', '10.0000', '0.0000', '10.0000', 'COMPRA #34', '130.00', 'Sistema', '88990c5d-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('673', '660015', '4', '2026-02-12 13:39:43', 'VENTA', '-2.0000', '11.0000', '9.0000', 'Venta #196 (Eddy)', '300.00', 'Sistema', 'b1d96c63-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('674', '440003', '4', '2026-02-12 13:39:43', 'VENTA', '-1.0000', '1.0000', '0.0000', 'Venta #196 (Eddy)', '1100.00', 'Sistema', 'b1d9b403-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('675', '440001', '4', '2026-02-12 13:39:43', 'VENTA', '-1.0000', '6.0000', '5.0000', 'Venta #196 (Eddy)', '90.00', 'Sistema', 'b1da02e9-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('676', '660017', '4', '2026-02-12 13:39:43', 'VENTA', '-9.0000', '18.0000', '9.0000', 'Venta #196 (Eddy)', '88.00', 'Sistema', 'b1da48aa-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('677', '660026', '4', '2026-02-12 13:39:43', 'VENTA', '-1.0000', '2.0000', '1.0000', 'Venta #196 (Eddy)', '430.00', 'Sistema', 'b1da9539-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('678', '660012', '4', '2026-02-12 13:39:43', 'VENTA', '-2.0000', '4.0000', '2.0000', 'Venta #196 (Eddy)', '60.00', 'Sistema', 'b1dad96b-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('679', '660012', '4', '2026-02-15 13:40:51', 'AJUSTE_INTERNO', '-2.0000', '2.0000', '0.0000', 'por error de entrada', '60.00', 'Sistema', 'da4d302d-0a9d-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('680', '660001', '4', '2026-02-13 13:51:21', 'VENTA', '-1.0000', '1.0000', '0.0000', 'Venta #197 (Eddy)', '35.00', 'Sistema', '51b00b17-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('681', '660001', '4', '2026-02-15 13:51:47', 'AJUSTE_INTERNO', '1.0000', '0.0000', '1.0000', 'entarda\r\n', '35.00', 'Sistema', '611f57c6-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('682', '660033', '4', '2026-02-15 13:52:01', 'AJUSTE_INTERNO', '-1.0000', '2.0000', '1.0000', 'me lo pago extra.por error', '20.00', 'Sistema', '69ddd740-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('683', '660018', '4', '2026-02-15 13:53:05', 'AJUSTE_INTERNO', '-1.0000', '2.0000', '1.0000', 'la pago extra', '580.00', 'Sistema', '8fef1a48-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('684', '660010', '4', '2026-02-13 13:53:22', 'VENTA', '-2.0000', '10.0000', '8.0000', 'Venta #198 (Eddy)', '130.00', 'Sistema', '99eff495-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('685', '660020', '4', '2026-02-13 13:53:22', 'VENTA', '-1.0000', '2.0000', '1.0000', 'Venta #198 (Eddy)', '570.00', 'Sistema', '99f0d732-0a9f-11f1-9614-0affd1a0dee5', '4');
INSERT INTO `kardex` VALUES ('686', '660018', '4', '2026-02-13 13:53:22', 'VENTA', '-1.0000', '1.0000', '0.0000', 'Venta #198 (Eddy)', '580.00', 'Sistema', '99f12895-0a9f-11f1-9614-0affd1a0dee5', '4');

DROP TABLE IF EXISTS `mermas_cabecera`;
CREATE TABLE `mermas_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT current_timestamp(),
  `usuario` varchar(50) DEFAULT NULL,
  `motivo_general` varchar(100) DEFAULT NULL,
  `total_costo_perdida` decimal(12,2) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp(),
  `estado` varchar(20) DEFAULT 'PROCESADA',
  `uuid` char(36) DEFAULT NULL,
  `id_sucursal` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mermas_cabecera` VALUES ('1', '2026-01-29 23:42:59', 'Admin', 'General', '3240.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe3a4d-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('2', '2026-01-30 10:55:57', 'Admin', 'General', '292.71', '2026-02-04 11:33:39', 'PROCESADA', '54fe3e25-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('3', '2026-02-02 18:45:38', 'Admin', 'General', '216.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe3ea9-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('4', '2026-02-02 19:16:32', 'Admin', 'General', '1100.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe3f12-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('5', '2026-02-02 19:42:25', 'Admin', 'General', '560.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe3f78-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('6', '2026-02-04 09:57:03', 'Admin', 'General', '1160.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe3fe0-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('7', '2026-02-04 09:58:42', 'Admin', 'General', '4560.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe4047-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('8', '2026-02-04 10:00:47', 'Admin', 'General', '10080.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe40a5-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('9', '2026-02-04 10:01:18', 'Admin', 'General', '5112.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe410b-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('10', '2026-02-04 10:01:52', 'Admin', 'General', '1080.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe420a-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('11', '2026-02-04 10:02:42', 'Admin', 'General', '435.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe4272-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('12', '2026-02-04 10:22:30', 'Admin', 'General', '160.00', '2026-02-04 11:33:39', 'PROCESADA', '54fe42d1-01f4-11f1-b0a7-0affd1a0dee5', '1');
INSERT INTO `mermas_cabecera` VALUES ('14', '2026-02-07 09:57:23', 'Admin', 'General', '1563.25', '2026-02-07 09:57:23', 'PROCESADA', '4f6f8d21-0435-11f1-b0a7-0affd1a0dee5', '4');
INSERT INTO `mermas_cabecera` VALUES ('15', '2026-02-12 13:03:48', 'Admin', 'General', '292.71', '2026-02-12 13:03:48', 'PROCESADA', '2e3b9565-083d-11f1-b0a7-0affd1a0dee5', '4');

DROP TABLE IF EXISTS `mermas_detalle`;
CREATE TABLE `mermas_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_merma` int(11) DEFAULT NULL,
  `id_producto` varchar(50) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `costo_al_momento` decimal(10,2) DEFAULT NULL,
  `motivo_especifico` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mermas_detalle` VALUES ('1', '1', '660036', '24.00', '135.00', 'Vencimiento');
INSERT INTO `mermas_detalle` VALUES ('2', '2', '881108', '1.00', '292.71', 'Vencimiento');
INSERT INTO `mermas_detalle` VALUES ('3', '3', '660017', '3.00', '72.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('4', '4', '660012', '22.00', '50.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('5', '5', '660020', '1.00', '560.00', 'Consumo');
INSERT INTO `mermas_detalle` VALUES ('6', '6', '660018', '2.00', '580.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('7', '7', '660032', '24.00', '190.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('8', '8', '660037', '48.00', '210.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('9', '9', '660023', '24.00', '213.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('10', '10', '660034', '180.00', '6.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('11', '11', '660035', '29.00', '15.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('12', '12', '756058841478', '4.00', '40.00', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('14', '14', '660087', '25.00', '62.53', 'Error de Entrada');
INSERT INTO `mermas_detalle` VALUES ('15', '15', '881108', '1.00', '292.71', 'Error de Entrada');

DROP TABLE IF EXISTS `mesas`;
CREATE TABLE `mesas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `id_piso` int(10) unsigned DEFAULT NULL,
  `capacidad` int(11) DEFAULT 4,
  `pos_x` decimal(6,2) DEFAULT 50.00,
  `pos_y` decimal(6,2) DEFAULT 50.00,
  `estado` enum('libre','ocupada','reservada') DEFAULT 'libre',
  `id_orden_actual` int(10) unsigned DEFAULT NULL,
  `forma` varchar(20) DEFAULT 'circulo',
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `metricas_web`;
CREATE TABLE `metricas_web` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) DEFAULT NULL,
  `pais` varchar(50) DEFAULT 'Desconocido',
  `url_visitada` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `session_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `metricas_web` VALUES ('1', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:38:04', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('2', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=h', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:38:33', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('3', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ha', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:38:34', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('4', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ham', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:38:34', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('5', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:38:42', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('6', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:41:31', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('7', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 14:41:33', '3hrd7tkjm3ob60fjmherru37p2');
INSERT INTO `metricas_web` VALUES ('8', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:37:20', '1horjomthgceshfsvjc5mibk74');
INSERT INTO `metricas_web` VALUES ('9', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:37:27', '1horjomthgceshfsvjc5mibk74');
INSERT INTO `metricas_web` VALUES ('10', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783083', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:37:33', '1horjomthgceshfsvjc5mibk74');
INSERT INTO `metricas_web` VALUES ('11', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:38:24', '1horjomthgceshfsvjc5mibk74');
INSERT INTO `metricas_web` VALUES ('12', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:39:33', '1horjomthgceshfsvjc5mibk74');
INSERT INTO `metricas_web` VALUES ('13', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:40:29', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('14', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:40:40', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('15', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:40:42', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('16', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:40:49', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('17', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:41:11', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('18', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:43:40', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('19', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:45:41', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('20', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:45:43', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('21', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ham', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:45:46', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('22', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:46:00', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('23', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:46:18', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('24', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:46:29', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('25', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:46:40', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('26', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:47:22', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('27', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:47:47', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('28', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:47:51', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('29', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=53348756', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:48:02', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('30', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=53348756', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:07', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('31', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:12', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('32', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:13', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('33', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:16', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('34', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783083', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:25', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('35', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:30', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('36', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=53348756', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:34', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('37', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:49:47', 'r8e2somqsqcorh7u36aba9u5jn');
INSERT INTO `metricas_web` VALUES ('38', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:50:19', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('39', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:50:21', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('40', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:50:31', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('41', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:50:48', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('42', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:50:55', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('43', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:51:10', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('44', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=admin', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:51:14', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('45', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:51:17', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('46', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:51:23', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('47', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:51:35', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('48', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:52:05', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('49', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:52:59', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('50', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:53:21', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('51', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:53:48', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('52', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:55:26', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('53', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:55:31', 'qgpeb69i8l5l350srbcunojq9b');
INSERT INTO `metricas_web` VALUES ('54', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:38', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('55', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:44', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('56', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:44', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('57', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:49', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('58', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:49', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('59', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=5352783030', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 17:56:54', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('60', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:08:59', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('61', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:09:34', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('62', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:10:40', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('63', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:10:44', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('64', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:10:45', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('65', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:10:47', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('66', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 18:10:47', 'f5tlq369400mdjlsgecl0fiuue');
INSERT INTO `metricas_web` VALUES ('67', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:11:17', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('68', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '2026-02-13 18:11:31', 'nsajqab5mvvgo3oosm604ktbuu');
INSERT INTO `metricas_web` VALUES ('69', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:12:17', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('70', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:19:43', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('71', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:19:56', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('72', '129.222.0.124', 'Desconocido', '/marinero/shop.php?cat=BODEGON&sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:21:47', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('73', '129.222.0.124', 'Desconocido', '/marinero/shop.php?cat=CARNICOS&sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:21:49', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('74', '129.222.0.124', 'Desconocido', '/marinero/shop.php?cat=CARNICOS&sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:22:57', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('75', '129.222.0.124', 'Desconocido', '/marinero/shop.php?sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:23:04', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('76', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '2026-02-13 18:26:37', 'nsajqab5mvvgo3oosm604ktbuu');
INSERT INTO `metricas_web` VALUES ('77', '129.222.0.124', 'Desconocido', '/marinero/shop.php?sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:32:37', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('78', '129.222.0.124', 'Desconocido', '/marinero/shop.php?sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 18:32:47', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('79', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '2026-02-13 19:19:53', 'jjk2oug7vtpfgrh8rarp6ah49a');
INSERT INTO `metricas_web` VALUES ('80', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 20:43:43', 'abtt6kbjr2q6ih1o6mam2nksvs');
INSERT INTO `metricas_web` VALUES ('81', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=h', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 20:46:23', 'abtt6kbjr2q6ih1o6mam2nksvs');
INSERT INTO `metricas_web` VALUES ('82', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ha', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 20:46:23', 'abtt6kbjr2q6ih1o6mam2nksvs');
INSERT INTO `metricas_web` VALUES ('83', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ham', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 20:46:23', 'abtt6kbjr2q6ih1o6mam2nksvs');
INSERT INTO `metricas_web` VALUES ('84', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 20:55:33', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('85', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:21:07', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('86', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:21:12', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('87', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:21:58', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('88', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:22:03', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('89', '152.206.234.128', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:26:05', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('90', '152.206.234.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660021', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:27:34', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('91', '152.206.234.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660021', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:27:39', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('92', '152.206.234.128', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:27:45', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('93', '152.206.234.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660101', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:27:46', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('94', '152.206.234.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660026', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:27:53', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('95', '152.206.210.128', 'Desconocido', '/marinero/shop.php?cat=CARNICOS&sort=categoria_asc', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:27', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('96', '152.206.210.128', 'Desconocido', '/marinero/shop.php?cat=CERVEZAS&sort=categoria_asc', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:30', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('97', '152.206.210.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660023', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:36', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('98', '152.206.210.128', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:37', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('99', '152.206.210.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660023', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:40', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('100', '152.206.210.128', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:42', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('101', '152.206.210.128', 'Desconocido', '/marinero/shop.php?ajax_search=Cer', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:46', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('102', '152.206.210.128', 'Desconocido', '/marinero/shop.php?ajax_search=Cerv', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:47', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('103', '152.206.210.128', 'Desconocido', '/marinero/shop.php?ajax_search=Cerve', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:48', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('104', '152.206.210.128', 'Desconocido', '/marinero/shop.php?action_view_product&code=660038', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-02-13 21:31:52', '8om868roh5lhhkl0pkgn7uh3r8');
INSERT INTO `metricas_web` VALUES ('105', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=h', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:35:27', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('106', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ha', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:35:27', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('107', '129.222.0.124', 'Desconocido', '/marinero/shop.php?ajax_search=ham', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:35:28', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('108', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_view_product&code=660015', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:35:30', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('109', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_track&q=52783030', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:35:50', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('110', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:36:41', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('111', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:02', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('112', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:02', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('113', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:08', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('114', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:26', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('115', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:32', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('116', '129.222.0.124', 'Desconocido', '/marinero/shop.php?action_view_product&code=660025', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:52', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('117', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-13 21:37:52', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('118', '129.222.0.124', 'Desconocido', '/marinero/shop.php?sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:48:21', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('119', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:23', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('120', '129.222.0.124', 'Desconocido', '/marinero/shop.php?sort=categoria_asc', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:23', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('121', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:28', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('122', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:32', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('123', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:33', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('124', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:34', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('125', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:54', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('126', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-02-13 21:49:57', '3ldiuji83qu87pjr8s8pdbk5tm');
INSERT INTO `metricas_web` VALUES ('127', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-14 00:13:24', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('128', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '2026-02-14 00:13:30', 'fql0jq8unsunj88grr9tv0asvf');
INSERT INTO `metricas_web` VALUES ('129', '129.222.0.124', 'Desconocido', '/marinero/shop.php', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-02-14 12:02:49', '91cf0qd8o1e73p6juvu709k2ke');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1', '0001_01_01_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('2', '2026_02_10_190715_create_personal_access_tokens_table', '2');

DROP TABLE IF EXISTS `ordenes_paralelas`;
CREATE TABLE `ordenes_paralelas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_sesion_caja` int(11) DEFAULT NULL,
  `id_mesa` int(10) unsigned DEFAULT NULL,
  `items_json` longtext NOT NULL CHECK (json_valid(`items_json`)),
  `estado` enum('activa','cerrada','cancelada') DEFAULT 'activa',
  `tipo_servicio` varchar(30) DEFAULT 'Mesa',
  `cliente_nombre` varchar(200) DEFAULT 'Mostrador',
  `precio_tipo` varchar(20) DEFAULT 'normal',
  `descuento_orden` decimal(5,2) DEFAULT 0.00,
  `notas` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ordenes_paralelas` VALUES ('1', NULL, NULL, '[{\"codigo\":\"660021\",\"nombre\":\"Refresco cola lata 300ml\",\"precio\":240,\"cantidad\":2,\"descuento\":10,\"nota\":\"Extra picante\",\"curso\":1}]', 'cancelada', 'Mesa', 'Mostrador', 'normal', '5.00', NULL, '2026-02-12 03:06:33', '2026-02-12 03:06:40');
INSERT INTO `ordenes_paralelas` VALUES ('2', NULL, NULL, '[{\"codigo\":\"660021\",\"nombre\":\"Refresco cola lata 300ml\",\"precio\":240,\"cantidad\":2,\"descuento\":10,\"nota\":\"Extra picante\",\"curso\":1}]', 'activa', 'Mesa', 'Mostrador', 'normal', '5.00', NULL, '2026-02-12 03:06:43', '2026-02-12 03:06:43');

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `pedidos_cabecera`;
CREATE TABLE `pedidos_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_nombre` varchar(100) DEFAULT NULL,
  `cliente_direccion` varchar(255) DEFAULT NULL,
  `cliente_telefono` varchar(20) DEFAULT NULL,
  `cliente_email` varchar(100) DEFAULT NULL,
  `cliente_contacto_pref` varchar(50) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'pendiente',
  `fecha` datetime DEFAULT current_timestamp(),
  `fecha_programada` datetime DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `notas_admin` text DEFAULT NULL,
  `id_empresa` int(11) DEFAULT 1,
  `id_sucursal` int(11) DEFAULT 1,
  `fecha_actualizacion` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pedidos_cabecera` VALUES ('1', 'JUAN PEREZ', '[DELIVERY: Cerro - Palatino] CAL ARBOL SECO #32', '5352783030', NULL, NULL, '700.00', 'completado', '2026-02-11 18:32:56', '2026-02-14 00:00:00', 'CON ROSAS', '', '1', '4', '2026-02-14 19:22:07');
INSERT INTO `pedidos_cabecera` VALUES ('4', 'mesa 5 juan', NULL, NULL, NULL, NULL, '50.00', 'completado', '2026-02-14 19:43:18', NULL, 'AUTOPEDIDO KIOSCO\n', NULL, '1', '1', '2026-02-14 20:04:06');

DROP TABLE IF EXISTS `pedidos_detalle`;
CREATE TABLE `pedidos_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) DEFAULT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL,
  `id_producto` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pedido` (`id_pedido`),
  CONSTRAINT `pedidos_detalle_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos_cabecera` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pedidos_detalle` VALUES ('1', '1', '1.00', '150.00', '756058841446');
INSERT INTO `pedidos_detalle` VALUES ('2', '4', '1.00', '50.00', 'TEST-999');

DROP TABLE IF EXISTS `pedidos_espera`;
CREATE TABLE `pedidos_espera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_referencia` varchar(100) DEFAULT NULL,
  `datos_json` longtext DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `cajero` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `personal_access_tokens` VALUES ('1', 'App\\Models\\User', '4', 'pos-session', 'd0546141bdc1b8f7f1e98a2335857a6cf0d9be448ba3c2da27a4556aa5776022', '[\"*\"]', '2026-02-10 14:14:31', '2026-02-11 02:14:27', '2026-02-10 14:14:27', '2026-02-10 14:14:31');
INSERT INTO `personal_access_tokens` VALUES ('2', 'App\\Models\\User', '1', 'test', 'ac6656f15705c7b684232aa19430161ddd9c83d54364ca2710fa2b192600e81c', '[\"*\"]', NULL, NULL, '2026-02-10 14:55:20', '2026-02-10 14:55:20');
INSERT INTO `personal_access_tokens` VALUES ('3', 'App\\Models\\User', '4', 'pos-session', 'a0e7916491eca0402e478ff892281dff858e7243acf2a56fa5212a3a864dc00d', '[\"*\"]', NULL, '2026-02-11 02:58:47', '2026-02-10 14:58:47', '2026-02-10 14:58:47');
INSERT INTO `personal_access_tokens` VALUES ('5', 'App\\Models\\User', '4', 'pos-session', 'b73cd0ea169e76f5cc171fe2221dfe814996f0e11a2ecedc9f7d53b24db9d277', '[\"*\"]', '2026-02-11 11:38:28', '2026-02-11 19:43:05', '2026-02-11 07:43:05', '2026-02-11 11:38:28');
INSERT INTO `personal_access_tokens` VALUES ('6', 'App\\Models\\User', '1', 'pos-session', 'd2bd499796c14d49cec9d23d4f74992c1f1517ed455927562cd3225d8441d70a', '[\"*\"]', '2026-02-11 19:48:36', '2026-02-11 19:49:05', '2026-02-11 07:49:05', '2026-02-11 19:48:36');
INSERT INTO `personal_access_tokens` VALUES ('7', 'App\\Models\\User', '4', 'pos-session', '7b678c32e0d4b0b5ed1a7f313f80179b909ef3ba0d538cbf79936c9a52655df7', '[\"*\"]', '2026-02-11 08:43:04', '2026-02-11 19:53:23', '2026-02-11 07:53:23', '2026-02-11 08:43:04');
INSERT INTO `personal_access_tokens` VALUES ('9', 'App\\Models\\User', '1', 'pos-session', '8fb5d1e744293be3b97845c8965a67fd4b7b0c3bd9501925ffff392dc5a34c22', '[\"*\"]', '2026-02-11 10:24:50', '2026-02-11 21:39:05', '2026-02-11 09:39:05', '2026-02-11 10:24:50');
INSERT INTO `personal_access_tokens` VALUES ('10', 'App\\Models\\User', '4', 'pos-session', '0d7f50b7cec11f7fcabbd6db422398a21516ef183bed3c1b7402068813f0f248', '[\"*\"]', '2026-02-12 14:38:36', '2026-02-12 14:38:58', '2026-02-12 02:38:58', '2026-02-12 14:38:36');
INSERT INTO `personal_access_tokens` VALUES ('11', 'App\\Models\\User', '1', 'pos-session', '259da8f49090adb0f86f184d3ebfb14e45a9548bf0d68b64f575bed02efdc1c5', '[\"*\"]', NULL, '2026-02-12 20:30:31', '2026-02-12 08:30:31', '2026-02-12 08:30:31');
INSERT INTO `personal_access_tokens` VALUES ('12', 'App\\Models\\User', '1', 'pos-session', 'f829f26e8d8ef629dfca6600b6cc1ce74094a8a3e5b11c74b20bd7710a349beb', '[\"*\"]', '2026-02-12 09:23:24', '2026-02-12 20:30:33', '2026-02-12 08:30:33', '2026-02-12 09:23:24');
INSERT INTO `personal_access_tokens` VALUES ('13', 'App\\Models\\User', '4', 'pos-session', 'f988c525bf3b73ab3e05218af3cbadec6e8749c6b7431ee54bc9f1adbc8b1a4e', '[\"*\"]', '2026-02-12 21:21:36', '2026-02-13 02:39:56', '2026-02-12 14:39:56', '2026-02-12 21:21:36');
INSERT INTO `personal_access_tokens` VALUES ('14', 'App\\Models\\User', '1', 'pos-session', '72dc6c9915d4b4b819683a4a5819a7a00047c2d81b2949e363faee13721e7378', '[\"*\"]', '2026-02-13 12:33:36', '2026-02-13 15:55:23', '2026-02-13 03:55:23', '2026-02-13 12:33:36');

DROP TABLE IF EXISTS `pisos`;
CREATE TABLE `pisos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `orden` int(11) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pisos` VALUES ('1', 'Planta Baja', '1', '1');

DROP TABLE IF EXISTS `producciones_historial`;
CREATE TABLE `producciones_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_receta` int(11) DEFAULT NULL,
  `nombre_receta` varchar(150) DEFAULT NULL,
  `id_producto_final` varchar(50) DEFAULT NULL,
  `cantidad_lotes` decimal(10,2) DEFAULT NULL,
  `unidades_creadas` decimal(12,2) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `usuario` varchar(50) DEFAULT NULL,
  `costo_total` decimal(12,2) DEFAULT NULL,
  `revertido` tinyint(4) DEFAULT 0,
  `json_snapshot` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `producciones_historial` VALUES ('1', '2', 'picadillo en jaba ', '881110', '2.00', '2.00', '2026-01-27 21:10:13', 'Admin', '585.20', '1', '[{\"id\":\"991152\",\"cant\":920,\"costo\":\"0.63\"},{\"id\":\"991145\",\"cant\":20,\"costo\":\"0.28\"}]');
INSERT INTO `producciones_historial` VALUES ('2', '2', 'picadillo en jaba ', '881110', '5.00', '5.00', '2026-01-27 21:10:34', 'Admin', '1463.00', '0', '[{\"id\":\"991152\",\"cant\":2300,\"costo\":\"0.63\"},{\"id\":\"991145\",\"cant\":50,\"costo\":\"0.28\"}]');

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(200) DEFAULT NULL,
  `precio` decimal(15,2) DEFAULT NULL,
  `costo` decimal(15,2) DEFAULT NULL,
  `precio_mayorista` decimal(15,2) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `version_row` bigint(20) DEFAULT 0,
  `id_empresa` int(11) NOT NULL DEFAULT 1,
  `categoria` varchar(100) DEFAULT 'General',
  `stock_minimo` decimal(10,2) DEFAULT 0.00,
  `fecha_vencimiento` date DEFAULT NULL,
  `es_elaborado` tinyint(1) DEFAULT 1,
  `es_materia_prima` tinyint(1) DEFAULT 0,
  `es_servicio` tinyint(1) DEFAULT 0,
  `es_cocina` tinyint(4) DEFAULT 0,
  `unidad_medida` varchar(20) DEFAULT 'UNIDAD',
  `descripcion` text DEFAULT NULL,
  `impuesto` decimal(5,2) DEFAULT 0.00,
  `peso` decimal(10,2) DEFAULT 0.00,
  `color` varchar(50) DEFAULT NULL,
  `es_web` tinyint(1) DEFAULT 1,
  `es_pos` tinyint(1) DEFAULT 1,
  `tiene_variantes` tinyint(1) DEFAULT 0,
  `variantes_json` text DEFAULT NULL,
  `es_suc1` tinyint(1) DEFAULT 1,
  `es_suc2` tinyint(1) DEFAULT 1,
  `es_suc3` tinyint(1) DEFAULT 1,
  `es_suc4` tinyint(1) DEFAULT 1,
  `es_suc5` tinyint(1) DEFAULT 1,
  `es_suc6` tinyint(1) DEFAULT 1,
  `sucursales_web` varchar(255) DEFAULT '1',
  `uuid` char(36) DEFAULT NULL,
  `id_sucursal_origen` int(11) DEFAULT 1,
  `etiqueta_web` varchar(50) DEFAULT NULL,
  `etiqueta_color` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `idx_uuid` (`uuid`),
  KEY `idx_version` (`version_row`),
  KEY `idx_prod_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `productos` VALUES ('440001', 'Donas Grandes', '140.00', '90.00', '94.50', '1', '0', '1', 'DULCES', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('440002', 'Cerveza star lager', '240.00', '200.00', NULL, '1', '1770923482', '1', 'CERVEZAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '507bf900-0846-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('440003', 'minicake 2000', '2000.00', '1100.00', NULL, '1', '0', '1', 'DULCES', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', 'a5080f58-0a9b-11f1-9614-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('440004', 'Whiskey', '1600.00', '1250.00', NULL, '1', '0', '1', 'BEBIDAS_A', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '0b866fed-0a9c-11f1-9614-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('440005', 'shaka', '600.00', '500.00', NULL, '1', '0', '1', 'BEBIDAS_A', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '8898456b-0a9d-11f1-9614-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660001', 'Chupa chus grandes', '70.00', '35.00', '36.75', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1ecd1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660002', 'Carritos chocolate', '40.00', '25.00', '26.25', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1efce-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660003', 'Pure de tomate 400g lata', '440.00', '360.00', '378.00', '1', '1770559589', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f07e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660004', 'Mini Whiskey 200ml', '400.00', '370.00', '388.50', '1', '1769730940', '1', 'BEBIDAS_A', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f10c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660005', 'Galletas Porleo', '150.00', '130.00', '136.50', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f190-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660006', 'Espagetis 500g', '280.00', '212.00', '222.60', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f211-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660007', 'Refresco en polvo', '40.00', '20.00', '21.00', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f294-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660008', 'Galleta Biskiato minion', '180.00', '150.00', '157.50', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f310-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660009', 'Galletas Rellenitas', '150.00', '120.00', '126.00', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f390-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660010', 'Galletas Blackout azul', '150.00', '130.00', '136.50', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660011', 'Energizante', '280.00', '210.00', '220.50', '1', '1769730940', '1', 'BEBIDAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f490-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660012', 'Tartaleta', '100.00', '60.00', '52.50', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660013', 'Cabezote', '80.00', '35.00', '36.75', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', 'Cabezote cubano , almibarados', '0.00', '0.56', 'amarillo', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f589-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660014', 'Albondigas pqt', '370.00', '220.00', '231.00', '1', '1769730940', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', 'albondigas de pollo', '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660015', 'Hamgurgesa 5u pqt', '500.00', '300.00', '315.00', '1', '1769730940', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660016', 'Higado de pollo pqt', '730.00', '620.00', '651.00', '1', '1769730940', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f717-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660017', 'Croquetas pollo pqt', '150.00', '88.00', '92.40', '1', '1770558559', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660018', 'Azucar 1kg pqt', '680.00', '580.00', '609.00', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', 'Azúcar blanca cristalina', '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f812-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660019', 'Pinguinos gelatina', '60.00', '33.00', '34.65', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f893-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660020', 'Arroz 1kg pqt', '650.00', '570.00', '598.50', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', 'Arroz de importación, calidad premium, 1kg tipo 1 pulido.limpio.listo para cocinar.', '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f914-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660021', 'Refresco cola lata 300ml', '250.00', '217.00', '227.85', '1', '1769730940', '1', 'BEBIDAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1f98e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660022', 'Refresco limon lata 300ml', '240.00', '210.00', '220.50', '1', '1769730940', '1', 'BEBIDAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fa0e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660023', 'Cerveza Shekels', '240.00', '213.00', '223.65', '1', '1769730940', '1', 'CERVEZAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', 'Cerveza shekels,', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660024', 'Cerveza Sta Isabel', '230.00', '205.00', '215.25', '1', '1769730940', '1', 'CERVEZAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fb03-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660025', 'Leche condensada', '520.00', '430.00', '451.50', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660026', 'Fanguito', '580.00', '430.00', '451.50', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660027', 'Marranetas', '240.00', '162.57', '170.70', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660028', 'Tartaletas especiales', '140.00', '90.00', '94.50', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fceb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660029', 'Caramelos de 15', '15.00', '8.00', '8.40', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fd65-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660030', 'San jacobo', '280.00', '180.00', '189.00', '1', '1769730940', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fddd-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660031', 'Croquetas Buffet', '160.00', '82.00', '86.10', '1', '1770558582', '1', 'CARNICOS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660032', 'Cerveza Esple', '230.00', '190.00', '199.50', '1', '1769730940', '1', 'CERVEZAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1fed4-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660033', 'Chupa chus 40', '40.00', '20.00', '21.00', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1ff4f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660034', 'Caramelos 10', '10.00', '6.00', '6.30', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e1ffcb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660035', 'chicle 30', '30.00', '15.00', '15.75', '1', '1769730940', '1', 'CONFITURAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20047-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660036', 'jugo cajita 200ml', '180.00', '135.00', '141.75', '1', '1769730940', '1', 'BEBIDAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e200c3-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660037', 'Cerveza La Fria', '240.00', '210.00', '220.50', '1', '1769730940', '1', 'CERVEZAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e2013f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660038', 'Cerveza Beer azul', '240.00', '210.00', '220.50', '1', '1769730940', '1', 'CERVEZAS', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e201b9-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660039', 'Helado Mousse 7oz', '150.00', '90.00', '94.50', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20235-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660040', 'Dulce 3 leches vaso 7oz', '250.00', '150.00', '157.50', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e202b1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660041', 'Torticas', '70.00', '35.00', '36.75', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2032c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660042', 'Pan de Gloria', '80.00', '35.00', '36.75', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e205ab-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660043', 'Minicake 18cm', '1500.00', '700.00', '735.00', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20629-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660044', 'Minicake Fanguito', '1700.00', '800.00', '840.00', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20721-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660045', 'Minicake Bombom', '2000.00', '1105.00', '1160.25', '1', '1769730940', '1', 'DULCES', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e207ad-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660046', 'Harina 1kg', '600.00', '500.00', '525.00', '1', '1769730940', '1', 'BODEGON', '0.00', NULL, '0', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20827-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660087', 'Galletas Saltitacos', '200.00', '62.53', '65.66', '1', '0', '1', 'CONFITURAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e208a4-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660088', 'Caldo de pollo sobrecito', '30.00', '18.00', '18.90', '1', '0', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20921-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660089', 'pastillita pollo con tomate', '40.00', '20.00', '21.00', '1', '0', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e2099d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660090', 'lomo en bandeja 1lb', '1300.00', '1150.00', '1207.50', '1', '0', '1', 'CARNICOS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20a18-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660093', 'Pqt de 4 panques', '280.00', '180.00', '189.00', '1', '0', '1', 'DULCES', '5.00', NULL, '1', '0', '0', '0', 'U', '', '0.00', '0.00', '#cccccc', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20a99-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660094', 'Gacenigas mini', '280.00', '200.00', '210.00', '1', '0', '1', 'DULCES', '5.00', NULL, '1', '0', '0', '0', 'U', '', '0.00', '0.00', '#cccccc', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20b21-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660095', 'Panque de chocolate', '100.00', '70.00', '73.50', '1', '0', '1', 'DULCES', '5.00', NULL, '1', '0', '0', '0', 'U', '', '0.00', '0.00', '#cccccc', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20ba2-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660096', 'pqt torticas 6u', '220.00', '120.00', '126.00', '1', '0', '1', 'DULCES', '5.00', NULL, '1', '0', '0', '0', 'U', '', '0.00', '0.00', '#cccccc', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20c23-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660097', 'Bolsa de 8 panes', '200.00', '160.00', '168.00', '1', '0', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', 'Pan suave, 8 unidades de 50g. acabados de hornear y envasados al vacio', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20ca1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660098', 'Cake 2900', '2900.00', '2000.00', '2100.00', '1', '1769996399', '1', 'DULCES', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', 'Cake mediano de 22 cm, 1 piso, pude escoger gratis, el color, el sabor del relleno y algun mensaje corto escrito.', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20d22-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660099', 'Marquesita', '100.00', '65.00', '68.25', '1', '1769749678', '1', 'DULCES', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', 'Con merengue', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20da7-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660100', 'ojitos gummy gum', '80.00', '40.00', '42.00', '1', '0', '1', 'CONFITURAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20eb0-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660101', 'Cafe en sobre', '40.00', '25.00', '26.25', '1', '1770223525', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20f35-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660102', 'Jabon de carbon', '200.00', '170.00', '178.50', '1', '0', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e20fb5-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660103', 'jabon de bano', '150.00', '130.00', '136.50', '1', '0', '1', 'BODEGON', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e21032-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('660104', 'Donas Donuts', '160.00', '120.00', '126.00', '1', '0', '1', 'CONFITURAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e210ac-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841446', 'COCA COLA GRANDE', '150.00', '120.00', '126.00', '1', '0', '1', 'BEBIDAS', '5.00', NULL, '1', '0', '0', '0', 'U', 'Deliciosa cocacola, toma coca', '5.00', '0.00', '#4d2f79', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,4', '54e2112e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841453', 'Refresco de naranja', '240.00', '210.00', '220.50', '1', '0', '1', 'BEBIDAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e211be-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841477', 'melcocha', '40.00', '20.00', '21.00', '1', '1769730604', '1', 'Pruebas', '0.00', NULL, '1', '0', '0', '1', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '2,4', '54e21241-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841478', 'Cupcakes', '120.00', '40.00', '42.00', '1', '1769886848', '1', 'DULCES', '5.00', NULL, '1', '0', '0', '0', 'UNIDAD', 'Deliciosos cup cakes', '1.00', '0.00', '#cccccc', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,4', '54e212c4-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841479', 'Capacillo de papel', '2.00', '1.00', '1.05', '1', '0', '1', 'INSUMOS', '5.00', NULL, '1', '1', '0', '0', 'U', '', '1.00', '0.00', '#712d2d', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21347-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('756058841480', 'Yuca en Pure', '120.00', '100.00', '105.00', '1', '0', '1', 'INSUMOS', '5.00', NULL, '1', '1', '0', '0', 'U', '', '0.00', '0.00', '#2c7c81', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e213cb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('88011', 'Producto de Prueba', '50.00', '20.00', '21.00', '1', '1769730604', '1', 'Pruebas', '0.00', NULL, '0', '0', '1', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21447-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('88012', 'Producto de Prueba2', '50.00', '20.00', '21.00', '1', '1769730604', '1', 'Pruebas', '0.00', NULL, '0', '0', '1', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e214cb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881101', 'Minicake 1500', '1500.00', '1041.35', '1093.42', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-15', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,3,4,5,6', '54e2154d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881102', 'Minicake fanguito', '1700.00', '565.04', '593.29', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-15', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,3,5,6', '54e215d5-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881103', 'Tortica grande', '70.00', '45.00', '47.25', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-15', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21884-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881104', 'Torticas chiquita', '80.00', '35.00', '36.75', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2190d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881105', 'Tartaletas', '100.00', '50.00', '52.50', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2198e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881106', 'Minicake 1500 choco', '1500.00', '1041.35', '1093.42', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,3,4,5,6', '54e21a14-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881107', 'Mini Cake', '1500.00', '567.90', '596.30', '1', '1769730604', '1', 'DULCES', '0.00', '2026-01-20', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881108', 'Hamburguesas pollo', '480.00', '292.71', '307.35', '1', '1769730604', '1', 'CONGELADOS', '1.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', 'Deliciosas Hamburgesas de 100g de picadillo de pollo mdm, saborizadas con ingredientes naturales', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,3', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881109', 'Cabezotes', '80.00', '33.55', '35.23', '1', '1769730604', '1', 'DULCES', '1.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21ba0-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('881110', 'PQT Picadillo 1lb', '330.00', '289.80', '304.29', '1', '1769730604', '1', 'CONGELADOS', '0.00', '2026-01-24', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '2', '54e21c24-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('990091', 'Cerveza Presidente', '240.00', '210.00', '220.50', '1', '0', '1', 'CERVEZAS', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,4', '54e21ca6-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991101', 'Azucar Blanca', '0.65', '0.58', '0.61', '1', '1769730604', '1', 'INSUMOS', '5.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21d30-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991102', 'azucar prieta', '0.65', '0.61', '0.64', '1', '1769730604', '1', 'INSUMOS', '5.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21dbe-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991103', 'Harina trigo', '0.60', '0.50', '0.53', '1', '1770504191', '1', 'INSUMOS', '5.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21e50-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991104', 'leche en polvo', '1.65', '1.50', '1.58', '1', '1769730604', '1', 'INSUMOS', '5.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21ed8-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991105', 'maicena', '1.20', '1.20', '1.26', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21f5d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991106', 'polvo hornear', '2.00', '1.80', '1.89', '1', '1769885570', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e21fe2-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991107', 'levadura', '2.80', '2.40', '2.52', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22064-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991108', 'guayaba en barra', '1.00', '0.85', '0.89', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e220e5-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991109', 'canela en polvo', '3.00', '2.50', '2.63', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22169-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991110', 'Bicarbonato', '4.00', '3.60', '3.78', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e221eb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991111', 'mejorador de pan', '2.00', '1.80', '1.89', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2226d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991112', 'CMC', '8.00', '5.00', '5.25', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e222ec-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991113', 'Emulsionante redolmy', '4.50', '4.15', '4.36', '1', '1769730604', '1', 'INSUMOS', '0.00', '2026-01-24', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2236e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991114', 'sazon en sobre', '70.00', '45.00', '47.25', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e223ef-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991115', 'pastillita de sabor', '50.00', '25.00', '26.25', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2246c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991116', 'yema huevo', '55.00', '50.00', '52.50', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e224ec-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991117', 'clara huevo', '55.00', '50.00', '52.50', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2256c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991118', 'Aceite', '1.80', '1.20', '1.26', '1', '1771004258', '1', 'BODEGON', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', 'aceite', '0.00', '0.00', 'amarillo', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '2,3,4', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991119', 'Sal comun', '0.15', '0.12', '0.13', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22672-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991120', 'Vainilla liquida', '2.20', '2.00', '2.10', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e226ef-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991121', 'Pan Rayado', '0.60', '0.43', '0.45', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22770-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991122', 'chapilla chocolate oscuro', '3.80', '3.50', '3.68', '1', '1769730604', '1', 'INSUMOS', '6.00', '2026-01-15', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e227ec-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991123', 'Gelatina fresa', '6.00', '5.00', '5.25', '1', '1769730604', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2286c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991124', 'pasta de ajo', '0.50', '0.40', '0.42', '1', '1769730604', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e228eb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991125', 'Pasta verde cebollino', '0.29', '0.27', '0.28', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22968-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991126', 'mostaza', '2.80', '2.50', '2.63', '1', '1769730604', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e229e5-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991127', 'mostaza agranel', '2.80', '2.50', '2.63', '1', '1769730604', '1', 'INSUMOS', '2.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22a63-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991128', 'semifrio de kiwi', '1.80', '1.50', '1.58', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', 'delicioso wiki', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22ae3-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991129', 'Mousse limon', '1.80', '1.50', '1.58', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22b67-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991130', 'Mouse Chocolate', '1.80', '1.50', '1.58', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e22d84-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991131', 'semifrio choco', '1.80', '1.50', '1.58', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2481e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991132', 'Mouse de fresa', '1.80', '1.50', '1.58', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e24ac1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991133', 'Crema Pastelera', '2.20', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e24c94-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991134', 'Grenatina', '5.00', '4.60', '4.83', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e24e33-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991135', 'cocoa pura', '1.20', '1.00', '1.05', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-08-03', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e24fcc-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991136', 'gragea de colores', '3.00', '2.90', '3.05', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-08-03', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e25137-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991137', 'grageas de chocolate', '3.00', '2.90', '3.05', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-08-03', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e252d4-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991138', 'Natilla de coco', '1.00', '0.50', '0.53', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e25472-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991139', 'margarina', '3.00', '2.60', '2.73', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2573d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991140', 'Natilla de Chocolate', '0.80', '0.64', '0.67', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2590f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991141', 'Natilla de Fresa', '0.50', '0.43', '0.45', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e25aad-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991142', 'Natilla de Limon', '0.50', '0.43', '0.45', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e25c4d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991143', 'Natilla de Fanguito', '0.60', '0.50', '0.53', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e25dea-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991144', 'Fanguito', '1.20', '1.25', '1.31', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2601e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991145', 'Almibar (1:1,5)', '0.46', '0.36', '0.38', '1', '1769734349', '1', 'DULCES', '0.00', '2026-01-24', '1', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e261ba-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991146', 'Pesto', '0.30', '0.27', '0.28', '1', '1769730605', '1', 'DULCES', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e26357-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991147', 'Queso', '0.55', '0.50', '0.53', '1', '1769730605', '1', 'DULCES', '0.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e26529-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991148', 'Panetelas Redolmy minicake', '253.00', '253.00', '265.65', '1', '1769730605', '1', 'DULCES', '0.00', '2026-01-24', '0', '0', '0', '1', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '2', '54e266c7-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991149', 'merengue emul', '150.00', '129.00', '135.45', '1', '1769730605', '1', 'DULCES', '0.00', '2026-01-20', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e26863-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991150', 'merengue italiano', '200.00', '159.19', '167.15', '1', '1769730605', '1', 'DULCES', '0.00', '2026-01-20', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e26a00-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991151', 'Azucar de Vainilla', '0.90', '0.80', '0.84', '1', '1770581047', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1,2,3', '54e26b9a-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991152', 'Picadillo pollo mdm', '0.68', '0.63', '0.66', '1', '1769730605', '1', 'CONGELADOS', '1.00', '2026-08-08', '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '2', '54e26d35-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991153', 'jugo de limon', '0.30', '0.25', '0.26', '1', '1770602766', '1', 'INSUMOS', '0.00', '2026-08-08', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e26ed8-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991154', 'Ron o alcohol', '0.25', '0.20', '0.21', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-08-08', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e27073-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991155', 'vinagre', '0.50', '0.35', '0.37', '1', '1769730605', '1', 'INSUMOS', '0.00', '2026-08-08', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e27209-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991156', 'natilla guayaba', '0.40', '0.37', '0.39', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-01-20', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e273a0-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991157', 'Colorante amarillo polvo', '38.00', '35.00', '36.75', '1', '1769730605', '1', 'INSUMOS', '1.00', '2026-08-08', '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e27b5f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991158', 'Almibar (1:1)', '0.50', '0.41', '0.43', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e27d5f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991159', 'Colorante ENCO 40g', '40.00', '37.00', '38.85', '1', '1769886124', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e27f03-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991160', 'Colorante ENCO 20g', '60.00', '55.00', '57.75', '1', '1769885983', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e280a1-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991161', 'Colorante Cheffmaster 20g', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2823c-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991162', 'Colorante Tinta negra', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2840a-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991163', 'Colorante Tinta rosada', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2856f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991164', 'Colorante Tinta namarilla', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e28706-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991165', 'Colorante Soft Gel (MIX) 25g', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2889d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991166', 'Colorante OTELSA azul', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e28a03-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991167', 'Colorante OTELSA rojo', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e28b99-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991168', 'Colorante Star Chemical', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e28d2e-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991169', 'Colorante agranel', '35.00', '30.00', '31.50', '1', '1769886213', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e28ecb-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991170', 'Chips horneables de chocolate', '5.00', '4.50', '4.73', '1', '1769889295', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e29067-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991171', 'Emulsionante supernortemul', '8.00', '7.00', '7.35', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e291ff-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991172', 'Saborizante Carolesen 60 ml', '40.00', '37.00', '38.85', '1', '1769886142', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e29367-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991173', 'Saborizante Carolesen Tutifruti 510 ml', '38.00', '35.00', '36.75', '1', '1769886173', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e29502-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991174', 'Saborizante Loran 118 ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2969d-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991175', 'Saborizante La Anita 120 ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e29833-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991176', 'Saborizante ENCO 120 ml', '22.00', '21.00', '22.05', '1', '1770604046', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e299c5-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991177', 'Saborizante ENCO 60 ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e29b28-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991178', 'Saborizante Star Chemical', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2a346-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991179', 'Saborizante Flor d Arancio', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2a521-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991180', 'Saborizante Lorsnn Tutifruti', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991181', 'Saborizante DUCHE mangp 120 ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2a816-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991182', 'Saborizante DEIMPIN guanabana 120 ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991183', 'Saborizante Esencia 3,7ml', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2ab49-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991184', 'Saborizantes agranel', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2acdc-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991185', 'Tartaletas (base)', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2ae75-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991186', 'Nata', '2.60', '2.20', '2.31', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2afde-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991187', 'Leche condensada', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2b175-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991188', 'Refresco polvo Mayar', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'BEBIDAS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2b30b-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991189', 'Mantequilla de mani', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2b49f-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('991190', 'Coco deshidratado', '1.00', '2.00', '2.10', '1', '1769730605', '1', 'INSUMOS', '0.00', NULL, '0', '1', '0', '0', 'UNIDAD', NULL, '0.00', '0.00', NULL, '0', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2b604-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);
INSERT INTO `productos` VALUES ('TEST-999', 'Producto de Prueba', '50.00', '20.00', '21.00', '1', '1769730605', '1', 'Pruebas', '0.00', NULL, '1', '0', '0', '0', 'UNIDAD', '', '0.00', '0.00', '', '1', '1', '0', NULL, '1', '1', '1', '1', '1', '1', '1', '54e2b7d7-01f4-11f1-b0a7-0affd1a0dee5', '1', NULL, NULL);

DROP TABLE IF EXISTS `recetas_cabecera`;
CREATE TABLE `recetas_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_producto_final` varchar(50) DEFAULT NULL,
  `nombre_receta` varchar(150) DEFAULT NULL,
  `unidades_resultantes` decimal(10,2) DEFAULT 1.00,
  `costo_total_lote` decimal(12,2) DEFAULT 0.00,
  `costo_unitario` decimal(12,2) DEFAULT 0.00,
  `descripcion` text DEFAULT NULL,
  `fecha_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `activo` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `id_producto_final` (`id_producto_final`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `recetas_cabecera` VALUES ('1', '881107', 'cake 1500', '3.00', '1698.00', '566.00', 'cake pequeno', '2026-01-27 20:40:06', '1');
INSERT INTO `recetas_cabecera` VALUES ('2', '881110', 'picadillo en jaba ', '1.00', '292.60', '292.60', '', '2026-01-27 20:40:56', '1');
INSERT INTO `recetas_cabecera` VALUES ('3', '881107', 'cake 1500 (Copia)', '3.00', '1698.00', '566.00', 'cake pequeno', '2026-01-27 21:12:38', '1');
INSERT INTO `recetas_cabecera` VALUES ('4', '756058841478', 'Cupcakes cubanos', '26.00', '1208.10', '46.47', 'hacer el batido pesado y hornear los moldes 20 mins a 180grados', '2026-01-31 14:48:15', '1');
INSERT INTO `recetas_cabecera` VALUES ('5', '756058841478', 'Cupcakes cubanos (Copia)', '30.00', '1042.10', '34.74', 'hacer el batido pesado y hornear los moldes 20 mins a 180grados', '2026-01-31 16:32:59', '1');
INSERT INTO `recetas_cabecera` VALUES ('6', '756058841446', 'croquetas de yuca', '19.00', '1527.80', '80.41', '', '2026-02-05 11:49:25', '1');
INSERT INTO `recetas_cabecera` VALUES ('7', '881105', 'tartaletas santo', '21.00', '1108.60', '52.79', 'mezclare y hornear\n', '2026-02-07 17:48:09', '1');
INSERT INTO `recetas_cabecera` VALUES ('8', '881103', 'torticas', '16.00', '606.86', '37.93', 'a mano', '2026-02-07 17:55:41', '1');
INSERT INTO `recetas_cabecera` VALUES ('9', '881109', 'cabezotee', '28.00', '834.36', '29.80', '', '2026-02-07 18:05:33', '1');
INSERT INTO `recetas_cabecera` VALUES ('10', '881109', 'cabezotee', '28.00', '834.36', '29.80', '', '2026-02-07 18:05:33', '1');

DROP TABLE IF EXISTS `recetas_detalle`;
CREATE TABLE `recetas_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_receta` int(11) DEFAULT NULL,
  `id_ingrediente` varchar(50) DEFAULT NULL,
  `cantidad` decimal(12,4) DEFAULT NULL,
  `costo_calculado` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_receta` (`id_receta`),
  CONSTRAINT `recetas_detalle_ibfk_1` FOREIGN KEY (`id_receta`) REFERENCES `recetas_cabecera` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `recetas_detalle` VALUES ('17', '1', '991148', '3.0000', '759.00');
INSERT INTO `recetas_detalle` VALUES ('18', '1', '991140', '600.0000', '384.00');
INSERT INTO `recetas_detalle` VALUES ('19', '1', '991149', '3.0000', '387.00');
INSERT INTO `recetas_detalle` VALUES ('20', '1', '991145', '600.0000', '168.00');
INSERT INTO `recetas_detalle` VALUES ('23', '3', '991148', '3.0000', '759.00');
INSERT INTO `recetas_detalle` VALUES ('24', '3', '991140', '600.0000', '384.00');
INSERT INTO `recetas_detalle` VALUES ('25', '3', '991149', '3.0000', '387.00');
INSERT INTO `recetas_detalle` VALUES ('26', '3', '991145', '600.0000', '168.00');
INSERT INTO `recetas_detalle` VALUES ('30', '2', '991152', '460.0000', '289.80');
INSERT INTO `recetas_detalle` VALUES ('31', '2', '991145', '12.0000', '3.36');
INSERT INTO `recetas_detalle` VALUES ('53', '4', '991103', '375.0000', '150.00');
INSERT INTO `recetas_detalle` VALUES ('54', '4', '991110', '15.0000', '54.00');
INSERT INTO `recetas_detalle` VALUES ('55', '4', '991120', '10.0000', '20.00');
INSERT INTO `recetas_detalle` VALUES ('56', '4', '991119', '5.0000', '0.60');
INSERT INTO `recetas_detalle` VALUES ('57', '4', '991104', '25.0000', '37.50');
INSERT INTO `recetas_detalle` VALUES ('58', '4', '991101', '300.0000', '174.00');
INSERT INTO `recetas_detalle` VALUES ('59', '4', '991149', '1.0000', '129.00');
INSERT INTO `recetas_detalle` VALUES ('60', '4', '991159', '1.0000', '37.00');
INSERT INTO `recetas_detalle` VALUES ('61', '4', '756058841479', '26.0000', '26.00');
INSERT INTO `recetas_detalle` VALUES ('62', '4', '991116', '4.0000', '200.00');
INSERT INTO `recetas_detalle` VALUES ('63', '4', '991117', '4.0000', '200.00');
INSERT INTO `recetas_detalle` VALUES ('64', '4', '991118', '180.0000', '180.00');
INSERT INTO `recetas_detalle` VALUES ('80', '5', '991103', '375.0000', '150.00');
INSERT INTO `recetas_detalle` VALUES ('81', '5', '991110', '15.0000', '54.00');
INSERT INTO `recetas_detalle` VALUES ('82', '5', '991120', '10.0000', '20.00');
INSERT INTO `recetas_detalle` VALUES ('83', '5', '991119', '5.0000', '0.60');
INSERT INTO `recetas_detalle` VALUES ('84', '5', '991104', '25.0000', '37.50');
INSERT INTO `recetas_detalle` VALUES ('85', '5', '991101', '300.0000', '174.00');
INSERT INTO `recetas_detalle` VALUES ('86', '5', '756058841479', '26.0000', '26.00');
INSERT INTO `recetas_detalle` VALUES ('87', '5', '991116', '4.0000', '200.00');
INSERT INTO `recetas_detalle` VALUES ('88', '5', '991117', '4.0000', '200.00');
INSERT INTO `recetas_detalle` VALUES ('89', '5', '991118', '180.0000', '180.00');
INSERT INTO `recetas_detalle` VALUES ('90', '6', '756058841480', '2.0000', '200.00');
INSERT INTO `recetas_detalle` VALUES ('91', '6', '991103', '2000.0000', '800.00');
INSERT INTO `recetas_detalle` VALUES ('92', '6', '991152', '460.0000', '289.80');
INSERT INTO `recetas_detalle` VALUES ('93', '6', '991119', '100.0000', '12.00');
INSERT INTO `recetas_detalle` VALUES ('94', '6', '991124', '100.0000', '40.00');
INSERT INTO `recetas_detalle` VALUES ('95', '6', '991125', '100.0000', '27.00');
INSERT INTO `recetas_detalle` VALUES ('96', '6', '991169', '1.0000', '30.00');
INSERT INTO `recetas_detalle` VALUES ('97', '6', '991121', '300.0000', '129.00');
INSERT INTO `recetas_detalle` VALUES ('108', '7', '991117', '1.0000', '50.00');
INSERT INTO `recetas_detalle` VALUES ('109', '7', '991116', '1.0000', '50.00');
INSERT INTO `recetas_detalle` VALUES ('110', '7', '991101', '110.0000', '63.80');
INSERT INTO `recetas_detalle` VALUES ('111', '7', '991139', '20.0000', '52.00');
INSERT INTO `recetas_detalle` VALUES ('112', '7', '991103', '350.0000', '175.00');
INSERT INTO `recetas_detalle` VALUES ('113', '7', '991118', '120.0000', '144.00');
INSERT INTO `recetas_detalle` VALUES ('114', '7', '991119', '5.0000', '0.60');
INSERT INTO `recetas_detalle` VALUES ('115', '7', '991120', '2.0000', '4.00');
INSERT INTO `recetas_detalle` VALUES ('116', '7', '991140', '630.0000', '403.20');
INSERT INTO `recetas_detalle` VALUES ('117', '7', '991149', '1.0000', '129.00');
INSERT INTO `recetas_detalle` VALUES ('118', '7', '991159', '1.0000', '37.00');
INSERT INTO `recetas_detalle` VALUES ('119', '8', '991101', '150.0000', '87.00');
INSERT INTO `recetas_detalle` VALUES ('120', '8', '991103', '450.0000', '225.00');
INSERT INTO `recetas_detalle` VALUES ('121', '8', '991139', '20.0000', '52.00');
INSERT INTO `recetas_detalle` VALUES ('122', '8', '991118', '195.0000', '234.00');
INSERT INTO `recetas_detalle` VALUES ('123', '8', '991119', '3.0000', '0.36');
INSERT INTO `recetas_detalle` VALUES ('124', '8', '991108', '10.0000', '8.50');
INSERT INTO `recetas_detalle` VALUES ('125', '9', '991101', '20.0000', '11.60');
INSERT INTO `recetas_detalle` VALUES ('126', '9', '991103', '20.0000', '10.00');
INSERT INTO `recetas_detalle` VALUES ('127', '9', '991116', '12.0000', '600.00');
INSERT INTO `recetas_detalle` VALUES ('128', '9', '991117', '1.0000', '50.00');
INSERT INTO `recetas_detalle` VALUES ('129', '9', '991105', '100.0000', '120.00');
INSERT INTO `recetas_detalle` VALUES ('130', '9', '991119', '3.0000', '0.36');
INSERT INTO `recetas_detalle` VALUES ('131', '9', '991106', '3.0000', '5.40');
INSERT INTO `recetas_detalle` VALUES ('132', '9', '991159', '1.0000', '37.00');
INSERT INTO `recetas_detalle` VALUES ('133', '10', '991101', '20.0000', '11.60');
INSERT INTO `recetas_detalle` VALUES ('134', '10', '991103', '20.0000', '10.00');
INSERT INTO `recetas_detalle` VALUES ('135', '10', '991116', '12.0000', '600.00');
INSERT INTO `recetas_detalle` VALUES ('136', '10', '991117', '1.0000', '50.00');
INSERT INTO `recetas_detalle` VALUES ('137', '10', '991105', '100.0000', '120.00');
INSERT INTO `recetas_detalle` VALUES ('138', '10', '991119', '3.0000', '0.36');
INSERT INTO `recetas_detalle` VALUES ('139', '10', '991106', '3.0000', '5.40');
INSERT INTO `recetas_detalle` VALUES ('140', '10', '991159', '1.0000', '37.00');

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `stock_almacen`;
CREATE TABLE `stock_almacen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_almacen` int(11) NOT NULL,
  `id_producto` varchar(50) NOT NULL,
  `cantidad` decimal(15,4) DEFAULT NULL,
  `ultima_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `id_sucursal` int(11) DEFAULT 1,
  `codigo_temp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_almacen_prod` (`id_almacen`,`id_producto`),
  KEY `idx_stock_prod` (`id_producto`),
  KEY `idx_stk_prod` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=1580 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_almacen` VALUES ('1', '1', '991101', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('2', '1', '991102', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('3', '1', '991103', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('4', '1', '991104', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('5', '1', '991105', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('6', '1', '991106', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('7', '1', '991107', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('8', '1', '991108', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('9', '1', '991109', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('10', '1', '991110', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('11', '1', '991111', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('12', '1', '991112', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('13', '1', '991113', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('14', '1', '991114', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('15', '1', '991115', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('16', '1', '991116', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('17', '1', '991117', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('18', '1', '991118', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('19', '1', '991119', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('20', '1', '991120', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('21', '1', '991121', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('22', '1', '991122', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('23', '1', '991123', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('24', '1', '991124', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('25', '1', '991125', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('26', '1', '991126', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('27', '1', '991127', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('28', '1', '991128', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('29', '1', '991129', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('30', '1', '991130', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('31', '1', '991131', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('32', '1', '991132', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('33', '1', '991133', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('34', '1', '991134', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('35', '1', '991135', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('36', '1', '991136', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('37', '1', '991137', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('38', '1', '991138', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('39', '1', '991139', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('40', '1', '991140', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('41', '1', '881101', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('42', '1', '881102', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('43', '1', '881103', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('44', '1', '881104', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('45', '1', '881105', '0.0000', '2026-01-28 09:20:26', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('46', '1', '991141', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('47', '1', '991142', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('48', '1', '991143', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('49', '1', '991144', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('50', '1', '991145', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('51', '1', '991146', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('52', '1', '991147', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('53', '1', '991148', '0.0000', '2026-01-28 00:40:54', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('54', '1', '991149', '0.0000', '2026-01-26 02:53:27', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('55', '1', '991150', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('56', '1', '881106', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('57', '1', '881107', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('58', '1', '991151', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('59', '1', '991152', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('60', '1', '991153', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('61', '1', '991154', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('62', '1', '991155', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('63', '1', '881108', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('64', '1', '991156', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('65', '1', '991157', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('66', '1', '881109', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('67', '1', '881110', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('122', '1', 'TEST-999', '0.0000', '2026-01-26 11:38:32', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('541', '1', '88011', '0.0000', '2026-01-29 15:05:18', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('542', '1', '756058841477', '0.0000', '2026-01-26 14:21:06', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('543', '1', '88012', '0.0000', '2026-01-26 12:20:42', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('567', '2', '756058841477', '5.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('568', '2', '881105', '29.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('569', '2', '991101', '6290.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('570', '2', '991102', '320.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('571', '2', '991103', '5735.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('572', '2', '991105', '2530.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('573', '2', '991106', '700.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('574', '2', '991107', '695.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('575', '2', '991108', '500.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('576', '2', '991109', '200.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('577', '2', '991110', '415.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('578', '2', '991111', '1365.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('579', '2', '991112', '315.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('580', '2', '991113', '930.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('581', '2', '991114', '3.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('582', '2', '991115', '29.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('583', '2', '991116', '14.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('584', '2', '991117', '13.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('585', '2', '991118', '110.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('586', '2', '991119', '1740.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('587', '2', '991120', '180.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('588', '2', '991121', '1145.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('589', '2', '991122', '1855.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('590', '2', '991123', '910.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('591', '2', '991124', '500.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('592', '2', '991125', '240.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('593', '2', '991126', '300.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('594', '2', '991127', '1775.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('595', '2', '991128', '830.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('596', '2', '991129', '240.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('597', '2', '991130', '115.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('598', '2', '991131', '140.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('599', '2', '991132', '630.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('600', '2', '991133', '625.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('601', '2', '991134', '230.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('602', '2', '991135', '65.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('603', '2', '991136', '435.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('604', '2', '991137', '390.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('605', '2', '991139', '2775.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('606', '2', '991141', '180.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('607', '2', '991144', '135.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('608', '2', '991146', '75.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('609', '2', '991147', '630.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('610', '2', '991148', '1.5000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('611', '2', '991149', '0.2500', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('612', '2', '991151', '1020.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('613', '2', '991152', '5500.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('614', '2', '991153', '915.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('615', '2', '991154', '50.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('616', '2', '991157', '285.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('617', '2', '991158', '725.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('618', '2', '991159', '345.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('619', '2', '991160', '60.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('620', '2', '991161', '60.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('621', '2', '991162', '100.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('622', '2', '991163', '50.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('623', '2', '991164', '40.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('624', '2', '991165', '50.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('625', '2', '991166', '810.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('626', '2', '991167', '390.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('627', '2', '991168', '80.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('628', '2', '991169', '855.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('629', '2', '991170', '185.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('630', '2', '991171', '995.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('631', '2', '991172', '140.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('632', '2', '991173', '365.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('633', '2', '991174', '305.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('634', '2', '991175', '95.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('635', '2', '991176', '345.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('636', '2', '991177', '110.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('637', '2', '991178', '40.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('638', '2', '991179', '75.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('639', '2', '991180', '55.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('640', '2', '991181', '105.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('641', '2', '991182', '90.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('642', '2', '991183', '70.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('643', '2', '991184', '3625.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('644', '2', '991185', '26.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('645', '2', '991186', '775.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('646', '2', '991187', '6.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('647', '2', '991188', '2.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('648', '2', '991189', '160.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('649', '2', '991190', '325.0000', '2026-02-13 09:45:36', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('657', '2', '881103', '0.0000', '2026-01-29 15:05:18', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('670', '6', '660034', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('671', '6', '660029', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('672', '6', '660035', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('673', '6', '660007', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('674', '6', '660033', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('675', '6', '660002', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('676', '6', '660019', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('677', '6', '660001', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('678', '6', '660028', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('679', '6', '660009', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('680', '6', '660005', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('681', '6', '660036', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('682', '6', '660008', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('683', '6', '660027', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('684', '6', '660032', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('685', '6', '660024', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('686', '6', '660011', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('687', '6', '660021', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('688', '6', '660022', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('689', '6', '660037', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('690', '6', '660023', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('691', '6', '660006', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('692', '6', '660003', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('693', '6', '660004', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('694', '6', '660025', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('695', '6', '660026', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('696', '6', '660020', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('697', '6', '660018', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('698', '6', '660016', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('699', '6', '660012', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('700', '6', '660013', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('701', '6', '660014', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('702', '6', '660015', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('703', '6', '660017', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('704', '6', '660030', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('705', '6', '660031', '0.0000', '2026-01-29 15:05:18', '6', NULL);
INSERT INTO `stock_almacen` VALUES ('708', '2', '660001', '0.0000', '2026-01-29 18:33:47', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('710', '2', '756058841453', '0.0000', '2026-01-29 18:33:47', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('722', '2', '660014', '0.0000', '2026-01-29 18:33:47', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('724', '2', '756058841446', '0.0000', '2026-01-29 18:33:47', '2', NULL);
INSERT INTO `stock_almacen` VALUES ('820', '4', '660034', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('821', '4', '660029', '187.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('822', '4', '660035', '12.0000', '2026-02-11 09:26:53', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('823', '4', '660007', '20.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('824', '4', '660033', '1.0000', '2026-02-15 13:52:01', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('825', '4', '660002', '25.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('826', '4', '660019', '53.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('827', '4', '660001', '1.0000', '2026-02-15 13:51:47', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('828', '4', '660028', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('829', '4', '660009', '3.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('830', '4', '660005', '18.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('831', '4', '660036', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('832', '4', '660008', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('833', '4', '660027', '26.0000', '2026-02-11 09:26:53', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('834', '4', '660032', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('835', '4', '660024', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('836', '4', '660011', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('837', '4', '660021', '6.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('838', '4', '660022', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('839', '4', '660037', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('840', '4', '660023', '1.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('841', '4', '660006', '8.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('842', '4', '660003', '7.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('843', '4', '660004', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('844', '4', '660025', '2.0000', '2026-02-15 13:25:02', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('845', '4', '660026', '1.0000', '2026-02-12 13:39:43', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('846', '4', '660020', '1.0000', '2026-02-13 13:53:22', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('847', '4', '660018', '0.0000', '2026-02-13 13:53:22', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('848', '4', '660016', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('849', '4', '660012', '0.0000', '2026-02-15 13:40:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('850', '4', '660013', '2.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('851', '4', '660014', '6.0000', '2026-02-15 13:25:02', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('852', '4', '660015', '9.0000', '2026-02-12 13:39:43', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('853', '4', '660017', '9.0000', '2026-02-12 13:39:43', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('854', '4', '660030', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('855', '4', '660031', '1.0000', '2026-02-15 13:25:02', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('867', '4', '881108', '1.0000', '2026-02-11 09:29:48', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('941', '4', '660099', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('961', '4', '756058841446', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('994', '4', '756058841480', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('995', '4', '660010', '8.0000', '2026-02-13 13:53:22', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('998', '4', '756058841478', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('999', '4', '660098', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1000', '4', '660043', '1.0000', '2026-02-15 13:25:02', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1033', '4', '660097', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1046', '4', '660096', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1049', '4', '660094', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1053', '4', '660095', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1054', '4', '660093', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1058', '4', '990091', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1139', '4', '660090', '1.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1141', '4', '660089', '20.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1142', '4', '660088', '5.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1143', '4', '660087', '0.0000', '2026-02-13 08:48:51', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1145', '4', '660100', '14.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1148', '4', '660102', '2.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1149', '4', '660103', '2.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1150', '4', '660104', '6.0000', '2026-02-13 09:45:36', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1205', '4', '440001', '5.0000', '2026-02-12 13:39:43', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1331', '4', '440002', '10.0000', '2026-02-12 13:12:42', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1355', '1', '440002', '0.0000', '2026-02-13 08:54:54', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('1357', '1', '660020', '0.0000', '2026-02-13 08:54:54', '1', NULL);
INSERT INTO `stock_almacen` VALUES ('1516', '4', '660101', '6.0000', '2026-02-15 12:53:14', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1521', '4', '991118', '1000.0000', '2026-02-13 12:40:11', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1554', '4', '440003', '0.0000', '2026-02-12 13:39:43', '4', NULL);
INSERT INTO `stock_almacen` VALUES ('1564', '4', '440005', '2.0000', '2026-02-12 13:38:34', '4', NULL);

DROP TABLE IF EXISTS `sucursales`;
CREATE TABLE `sucursales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `codigo_externo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sucursales` VALUES ('1', '1', 'marinero', '1');
INSERT INTO `sucursales` VALUES ('2', '1', 'roly', '2');
INSERT INTO `sucursales` VALUES ('4', '1', 'Sucursal 4', NULL);

DROP TABLE IF EXISTS `sync_journal`;
CREATE TABLE `sync_journal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fecha_evento` datetime DEFAULT current_timestamp(),
  `tabla` varchar(50) NOT NULL,
  `accion` varchar(10) NOT NULL,
  `registro_uuid` char(36) NOT NULL,
  `datos_json` longtext NOT NULL,
  `origen_sucursal_id` int(11) NOT NULL,
  `sincronizado` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_sync` (`sincronizado`),
  KEY `idx_fecha` (`fecha_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=876 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sync_journal` VALUES ('1', '2026-02-04 15:28:18', 'productos', 'UPDATE', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660014\", \"nombre\": \"Albondigas pqt\", \"costo\": 220.00, \"precio\": 360.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f60d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('2', '2026-02-04 15:28:19', 'productos', 'UPDATE', '54e261ba-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991145\", \"nombre\": \"Almibar (1:1,5)\", \"costo\": 0.36, \"precio\": 0.46, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e261ba-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('3', '2026-02-04 15:28:20', 'productos', 'UPDATE', '54e261ba-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991145\", \"nombre\": \"Almibar (1:1,5)\", \"costo\": 0.36, \"precio\": 0.46, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e261ba-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('4', '2026-02-04 15:28:26', 'productos', 'UPDATE', '54e1f914-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660020\", \"nombre\": \"Arroz 1kg pqt\", \"costo\": 560.00, \"precio\": 650.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f914-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('5', '2026-02-04 15:28:27', 'productos', 'UPDATE', '54e1f812-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660018\", \"nombre\": \"Azucar 1kg pqt\", \"costo\": 580.00, \"precio\": 680.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f812-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('6', '2026-02-04 15:28:36', 'productos', 'UPDATE', '54e20ca1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660097\", \"nombre\": \"Bolsa de 8 panes\", \"costo\": 160.00, \"precio\": 200.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20ca1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('7', '2026-02-04 15:28:40', 'productos', 'UPDATE', '54e1f589-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660013\", \"nombre\": \"Cabezote\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f589-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('8', '2026-02-04 15:28:43', 'productos', 'UPDATE', '54e20f35-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660101\", \"nombre\": \"Cafe en sobre\", \"costo\": 25.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20f35-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('9', '2026-02-04 15:28:45', 'productos', 'UPDATE', '54e20921-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660088\", \"nombre\": \"Caldo de pollo sobrecito\", \"costo\": 18.00, \"precio\": 30.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20921-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('10', '2026-02-04 15:28:52', 'productos', 'UPDATE', '54e1ffcb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660034\", \"nombre\": \"Caramelos 10\", \"costo\": 6.00, \"precio\": 10.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ffcb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('11', '2026-02-04 15:28:53', 'productos', 'UPDATE', '54e1fd65-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660029\", \"nombre\": \"Caramelos de 15\", \"costo\": 8.00, \"precio\": 15.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1fd65-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('12', '2026-02-04 15:28:54', 'productos', 'UPDATE', '54e1efce-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660002\", \"nombre\": \"Carritos chocolate\", \"costo\": 25.00, \"precio\": 40.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1efce-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('13', '2026-02-04 15:28:56', 'productos', 'UPDATE', '54e201b9-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660038\", \"nombre\": \"Cerveza Beer azul\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e201b9-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('14', '2026-02-04 15:28:57', 'productos', 'UPDATE', '54e1fed4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660032\", \"nombre\": \"Cerveza Esple\", \"costo\": 190.00, \"precio\": 230.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fed4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('15', '2026-02-04 15:28:58', 'productos', 'UPDATE', '54e2013f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660037\", \"nombre\": \"Cerveza La Fria\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e2013f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('16', '2026-02-04 15:28:59', 'productos', 'UPDATE', '54e21ca6-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"990091\", \"nombre\": \"Cerveza Presidente\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e21ca6-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('17', '2026-02-04 15:29:01', 'productos', 'UPDATE', '54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660023\", \"nombre\": \"Cerveza Shekels\", \"costo\": 213.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('18', '2026-02-04 15:29:05', 'productos', 'UPDATE', '54e20047-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660035\", \"nombre\": \"chicle 30\", \"costo\": 15.00, \"precio\": 30.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e20047-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('19', '2026-02-04 15:29:08', 'productos', 'UPDATE', '54e1ff4f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660033\", \"nombre\": \"Chupa chus 40\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ff4f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('20', '2026-02-04 15:29:09', 'productos', 'UPDATE', '54e1ecd1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660001\", \"nombre\": \"Chupa chus grandes\", \"costo\": 35.00, \"precio\": 70.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ecd1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('21', '2026-02-04 15:29:12', 'productos', 'UPDATE', '54e2112e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841446\", \"nombre\": \"COCA COLA GRANDE\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"Bebidas\", \"activo\": 1, \"uuid\": \"54e2112e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('22', '2026-02-04 15:29:14', 'productos', 'UPDATE', '54e2112e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841446\", \"nombre\": \"COCA COLA GRANDE\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"Bebidas\", \"activo\": 1, \"uuid\": \"54e2112e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('23', '2026-02-04 15:29:29', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 72.00, \"precio\": 140.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('24', '2026-02-04 15:29:30', 'productos', 'UPDATE', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660031\", \"nombre\": \"Croquetas Buffet\", \"costo\": 80.00, \"precio\": 160.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fe58-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('25', '2026-02-04 15:29:32', 'productos', 'UPDATE', '54e210ac-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660104\", \"nombre\": \"Donas Donuts\", \"costo\": 120.00, \"precio\": 160.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e210ac-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('26', '2026-02-04 15:29:35', 'productos', 'UPDATE', '54e202b1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660040\", \"nombre\": \"Dulce 3 leches vaso 7oz\", \"costo\": 150.00, \"precio\": 250.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e202b1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('27', '2026-02-04 15:29:39', 'productos', 'UPDATE', '54e1f490-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660011\", \"nombre\": \"Energizante\", \"costo\": 210.00, \"precio\": 280.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f490-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('28', '2026-02-04 15:29:40', 'productos', 'UPDATE', '54e1f211-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660006\", \"nombre\": \"Espagetis 500g\", \"costo\": 230.00, \"precio\": 280.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f211-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('29', '2026-02-04 15:29:41', 'productos', 'UPDATE', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660026\", \"nombre\": \"Fanguito\", \"costo\": 430.00, \"precio\": 580.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('30', '2026-02-04 15:29:44', 'productos', 'UPDATE', '54e20b21-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660094\", \"nombre\": \"Gacenigas mini\", \"costo\": 200.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20b21-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('31', '2026-02-04 15:29:46', 'productos', 'UPDATE', '54e1f310-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660008\", \"nombre\": \"Galleta Biskiato minion\", \"costo\": 150.00, \"precio\": 180.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f310-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('32', '2026-02-04 15:29:46', 'productos', 'UPDATE', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660010\", \"nombre\": \"Galletas Blackout azul\", \"costo\": 130.00, \"precio\": 160.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f412-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('33', '2026-02-04 15:29:47', 'productos', 'UPDATE', '54e1f190-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660005\", \"nombre\": \"Galletas Porleo\", \"costo\": 130.00, \"precio\": 180.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f190-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('34', '2026-02-04 15:29:48', 'productos', 'UPDATE', '54e1f390-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660009\", \"nombre\": \"Galletas Rellenitas\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f390-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('35', '2026-02-04 15:29:49', 'productos', 'UPDATE', '54e208a4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660087\", \"nombre\": \"Galletas Saltitacos\", \"costo\": 62.53, \"precio\": 200.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e208a4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('36', '2026-02-04 15:29:58', 'productos', 'UPDATE', '54e220e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991108\", \"nombre\": \"guayaba en barra\", \"costo\": 0.85, \"precio\": 1.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e220e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('37', '2026-02-04 15:29:58', 'productos', 'UPDATE', '54e220e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991108\", \"nombre\": \"guayaba en barra\", \"costo\": 0.85, \"precio\": 1.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e220e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('38', '2026-02-04 15:30:03', 'productos', 'UPDATE', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660015\", \"nombre\": \"Hamgurgesa 5u pqt\", \"costo\": 300.00, \"precio\": 500.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f697-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('39', '2026-02-04 15:30:03', 'productos', 'UPDATE', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881108\", \"nombre\": \"Hamburguesas pollo\", \"costo\": 292.71, \"precio\": 480.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21b15-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('40', '2026-02-04 15:30:04', 'productos', 'UPDATE', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881108\", \"nombre\": \"Hamburguesas pollo\", \"costo\": 292.71, \"precio\": 480.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21b15-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('41', '2026-02-04 15:30:05', 'productos', 'UPDATE', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881108\", \"nombre\": \"Hamburguesas pollo\", \"costo\": 292.71, \"precio\": 480.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21b15-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('42', '2026-02-04 15:30:11', 'productos', 'UPDATE', '54e20827-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660046\", \"nombre\": \"Harina 1kg\", \"costo\": 500.00, \"precio\": 600.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20827-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('43', '2026-02-04 15:30:16', 'productos', 'UPDATE', '54e20235-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660039\", \"nombre\": \"Helado Mousse 7oz\", \"costo\": 90.00, \"precio\": 150.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20235-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('44', '2026-02-04 15:30:17', 'productos', 'UPDATE', '54e1f717-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660016\", \"nombre\": \"Higado de pollo pqt\", \"costo\": 620.00, \"precio\": 730.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f717-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('45', '2026-02-04 15:30:19', 'productos', 'UPDATE', '54e21032-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660103\", \"nombre\": \"jabon de bano\", \"costo\": 130.00, \"precio\": 150.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e21032-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('46', '2026-02-04 15:30:20', 'productos', 'UPDATE', '54e20fb5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660102\", \"nombre\": \"Jabon de carbon\", \"costo\": 170.00, \"precio\": 200.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20fb5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('47', '2026-02-04 15:30:21', 'productos', 'UPDATE', '54e200c3-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660036\", \"nombre\": \"jugo cajita 200ml\", \"costo\": 135.00, \"precio\": 180.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e200c3-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('48', '2026-02-04 15:30:23', 'productos', 'UPDATE', '54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660025\", \"nombre\": \"Leche condensada\", \"costo\": 430.00, \"precio\": 520.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('49', '2026-02-04 15:30:26', 'productos', 'UPDATE', '54e20a18-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660090\", \"nombre\": \"lomo en bandeja 1lb\", \"costo\": 1150.00, \"precio\": 1300.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e20a18-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('50', '2026-02-04 15:30:29', 'productos', 'UPDATE', '54e20da7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660099\", \"nombre\": \"Marquesita\", \"costo\": 65.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20da7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('51', '2026-02-04 15:30:30', 'productos', 'UPDATE', '54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660027\", \"nombre\": \"Marranetas\", \"costo\": 166.00, \"precio\": 240.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('52', '2026-02-04 15:30:34', 'productos', 'UPDATE', '54e21241-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841477\", \"nombre\": \"melcocha\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"Pruebas\", \"activo\": 1, \"uuid\": \"54e21241-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('53', '2026-02-04 15:30:38', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('54', '2026-02-04 15:30:38', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('55', '2026-02-04 15:30:39', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('56', '2026-02-04 15:30:40', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('57', '2026-02-04 15:30:40', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('58', '2026-02-04 15:30:52', 'productos', 'UPDATE', '54e20721-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660044\", \"nombre\": \"Minicake Fanguito\", \"costo\": 800.00, \"precio\": 1700.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20721-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('59', '2026-02-04 15:30:53', 'productos', 'UPDATE', '54e207ad-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660045\", \"nombre\": \"Minicake Bombom\", \"costo\": 1105.00, \"precio\": 2000.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e207ad-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('60', '2026-02-04 15:30:54', 'productos', 'UPDATE', '54e20629-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660043\", \"nombre\": \"Minicake 18cm\", \"costo\": 700.00, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20629-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('61', '2026-02-04 15:30:55', 'productos', 'UPDATE', '54e215d5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881102\", \"nombre\": \"Minicake fanguito\", \"costo\": 565.04, \"precio\": 1700.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e215d5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('62', '2026-02-04 15:31:05', 'productos', 'UPDATE', '54e20eb0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660100\", \"nombre\": \"ojitos gummy gum\", \"costo\": 40.00, \"precio\": 80.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e20eb0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('63', '2026-02-04 15:31:07', 'productos', 'UPDATE', '54e205ab-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660042\", \"nombre\": \"Pan de Gloria\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e205ab-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('64', '2026-02-04 15:31:10', 'productos', 'UPDATE', '54e20ba2-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660095\", \"nombre\": \"Panque de chocolate\", \"costo\": 70.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20ba2-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('65', '2026-02-04 15:31:13', 'productos', 'UPDATE', '54e2099d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660089\", \"nombre\": \"pastillita pollo con tomate\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e2099d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('66', '2026-02-04 15:31:17', 'productos', 'UPDATE', '54e1f893-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660019\", \"nombre\": \"Pinguinos gelatina\", \"costo\": 33.00, \"precio\": 60.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f893-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('67', '2026-02-04 15:31:19', 'productos', 'UPDATE', '54e20a99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660093\", \"nombre\": \"Pqt de 4 panques\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20a99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('68', '2026-02-04 15:31:22', 'productos', 'UPDATE', '54e20c23-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660096\", \"nombre\": \"pqt torticas 6u\", \"costo\": 120.00, \"precio\": 220.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20c23-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('69', '2026-02-04 15:31:27', 'productos', 'UPDATE', '54e1f07e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660003\", \"nombre\": \"Pure de tomate 400g lata\", \"costo\": 340.00, \"precio\": 360.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f07e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('70', '2026-02-04 15:31:31', 'productos', 'UPDATE', '54e1f98e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660021\", \"nombre\": \"Refresco cola lata 300ml\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f98e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('71', '2026-02-04 15:31:32', 'productos', 'UPDATE', '54e211be-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841453\", \"nombre\": \"Refresco de naranja\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"Bebidas\", \"activo\": 1, \"uuid\": \"54e211be-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('72', '2026-02-04 15:31:36', 'productos', 'UPDATE', '54e1f294-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660007\", \"nombre\": \"Refresco en polvo\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f294-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('73', '2026-02-04 15:31:41', 'productos', 'UPDATE', '54e1fa0e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660022\", \"nombre\": \"Refresco limon lata 300ml\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1fa0e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('74', '2026-02-04 15:31:43', 'productos', 'UPDATE', '54e2b30b-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991188\", \"nombre\": \"Refresco polvo Mayar\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b30b-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('75', '2026-02-04 15:31:44', 'productos', 'UPDATE', '54e2b30b-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991188\", \"nombre\": \"Refresco polvo Mayar\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b30b-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('76', '2026-02-04 15:31:53', 'productos', 'UPDATE', '54e1fddd-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660030\", \"nombre\": \"San jacobo\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fddd-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('77', '2026-02-04 15:31:56', 'productos', 'UPDATE', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660012\", \"nombre\": \"Tartaleta\", \"costo\": 50.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f50f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('78', '2026-02-04 15:32:00', 'productos', 'UPDATE', '54e1fceb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660028\", \"nombre\": \"Tartaletas especiales\", \"costo\": 90.00, \"precio\": 140.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1fceb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('79', '2026-02-05 08:10:45', 'productos', 'UPDATE', '54e1fb03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660024\", \"nombre\": \"Cerveza Sta Isabel\", \"costo\": 205.00, \"precio\": 230.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fb03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('80', '2026-02-05 08:10:50', 'productos', 'UPDATE', '54e20b21-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660094\", \"nombre\": \"Gacenigas mini\", \"costo\": 200.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20b21-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('81', '2026-02-05 08:10:55', 'productos', 'UPDATE', '54e1f10c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660004\", \"nombre\": \"Mini Whiskey 200ml\", \"costo\": 370.00, \"precio\": 400.00, \"categoria\": \"BEBIDAS_A\", \"activo\": 1, \"uuid\": \"54e1f10c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('82', '2026-02-05 08:10:58', 'productos', 'UPDATE', '54e20ba2-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660095\", \"nombre\": \"Panque de chocolate\", \"costo\": 70.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20ba2-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('83', '2026-02-05 08:11:02', 'productos', 'UPDATE', '54e20a99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660093\", \"nombre\": \"Pqt de 4 panques\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20a99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('84', '2026-02-05 08:11:06', 'productos', 'UPDATE', '54e20c23-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660096\", \"nombre\": \"pqt torticas 6u\", \"costo\": 120.00, \"precio\": 220.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20c23-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('85', '2026-02-05 08:11:48', 'productos', 'UPDATE', '54e1f914-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660020\", \"nombre\": \"Arroz 1kg pqt\", \"costo\": 560.00, \"precio\": 650.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f914-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('86', '2026-02-05 08:12:03', 'productos', 'UPDATE', '54e1f812-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660018\", \"nombre\": \"Azucar 1kg pqt\", \"costo\": 580.00, \"precio\": 680.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f812-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('87', '2026-02-05 08:31:43', 'productos', 'UPDATE', '54e20ca1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660097\", \"nombre\": \"Bolsa de 8 panes\", \"costo\": 160.00, \"precio\": 200.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20ca1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('88', '2026-02-05 08:32:28', 'productos', 'UPDATE', '54e1f589-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660013\", \"nombre\": \"Cabezote\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f589-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('89', '2026-02-05 08:33:20', 'productos', 'UPDATE', '54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660023\", \"nombre\": \"Cerveza Shekels\", \"costo\": 213.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('90', '2026-02-05 08:38:07', 'productos', 'UPDATE', '54e20d22-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660098\", \"nombre\": \"Cake 2900\", \"costo\": 2000.00, \"precio\": 2900.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20d22-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('116', '2026-02-06 11:00:24', 'ventas_cabecera', 'INSERT', 'f28d7f06-0374-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-06 11:00:24\", \"total\": 80.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"f28d7f06-0374-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('117', '2026-02-06 11:00:24', 'kardex', 'INSERT', 'f28dccc0-0374-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #70\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 11:00:24\", \"uuid\": \"f28dccc0-0374-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('118', '2026-02-06 12:10:31', 'ventas_cabecera', 'INSERT', 'be0ea5b4-037e-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-06 12:10:31\", \"total\": 560.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"be0ea5b4-037e-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('119', '2026-02-06 12:10:31', 'kardex', 'INSERT', '84d9f676-f7b6-48eb-b31e-48a43588d60b', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #71\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 12:10:31\", \"uuid\": \"84d9f676-f7b6-48eb-b31e-48a43588d60b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('120', '2026-02-06 16:02:51', 'ventas_cabecera', 'INSERT', '32f56a19-039f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-06 16:02:51\", \"total\": 3520.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"32f56a19-039f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('121', '2026-02-06 16:02:51', 'kardex', 'INSERT', 'e912fa71-885b-432a-901d-969b92a37d2a', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #72\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 16:02:51\", \"uuid\": \"e912fa71-885b-432a-901d-969b92a37d2a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('122', '2026-02-06 16:02:51', 'kardex', 'INSERT', '5f37d981-bc9e-40e0-a077-5381bed96cb9', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #72\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 16:02:51\", \"uuid\": \"5f37d981-bc9e-40e0-a077-5381bed96cb9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('123', '2026-02-06 16:02:51', 'kardex', 'INSERT', '0fc10a02-fc41-486e-b129-edf921d6af4e', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #72\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 16:02:51\", \"uuid\": \"0fc10a02-fc41-486e-b129-edf921d6af4e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('124', '2026-02-06 16:02:51', 'kardex', 'INSERT', '621a0de6-a82c-4196-96a4-93a97ac6af22', '{\"id_producto\": \"660037\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -10.0000, \"referencia\": \"VENTA #72\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 16:02:51\", \"uuid\": \"621a0de6-a82c-4196-96a4-93a97ac6af22\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('125', '2026-02-06 16:02:51', 'ventas_cabecera', 'INSERT', '3309cfa9-039f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-06 16:02:51\", \"total\": 1920.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"3309cfa9-039f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('126', '2026-02-06 16:02:51', 'kardex', 'INSERT', 'c04a4f28-3b63-429c-9441-ef8db57e47d3', '{\"id_producto\": \"990091\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -8.0000, \"referencia\": \"VENTA #73\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-06 16:02:51\", \"uuid\": \"c04a4f28-3b63-429c-9441-ef8db57e47d3\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('131', '2026-02-07 09:02:05', 'ventas_cabecera', 'INSERT', '959c2084-042d-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:02:05\", \"total\": -80.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"959c2084-042d-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('132', '2026-02-07 09:02:05', 'kardex', 'INSERT', '959d117f-042d-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 2.0000, \"referencia\": \"REFUND_ITEM_219\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:02:05\", \"uuid\": \"959d117f-042d-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('133', '2026-02-07 09:07:50', 'ventas_cabecera', 'INSERT', '63174dd3-042e-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:07:50\", \"total\": -560.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"63174dd3-042e-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('134', '2026-02-07 09:07:50', 'kardex', 'INSERT', 'kdx_6987473641b1e', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 2.0000, \"referencia\": \"REFUND_ITEM_220\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:07:50\", \"uuid\": \"kdx_6987473641b1e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('141', '2026-02-07 09:45:26', 'ventas_cabecera', 'INSERT', 'a41b0f7f-0433-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:45:26\", \"total\": 3600.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"a41b0f7f-0433-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('142', '2026-02-07 09:45:26', 'kardex', 'INSERT', 'kdx_69875006ca84c', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"VENTA #86\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:45:26\", \"uuid\": \"kdx_69875006ca84c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('143', '2026-02-07 09:45:26', 'kardex', 'INSERT', 'kdx_69875006ccb6e', '{\"id_producto\": \"660036\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -8.0000, \"referencia\": \"VENTA #86\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:45:26\", \"uuid\": \"kdx_69875006ccb6e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('144', '2026-02-07 09:46:06', 'ventas_cabecera', 'INSERT', 'bc079dfa-0433-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:46:06\", \"total\": 1040.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"bc079dfa-0433-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('145', '2026-02-07 09:46:06', 'kardex', 'INSERT', 'kdx_6987502eec81f', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #87\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:46:06\", \"uuid\": \"kdx_6987502eec81f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('146', '2026-02-07 09:47:06', 'ventas_cabecera', 'INSERT', 'dfc2b907-0433-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:47:06\", \"total\": 890.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"dfc2b907-0433-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('147', '2026-02-07 09:47:06', 'kardex', 'INSERT', 'kdx_6987506adf187', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #88\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:47:06\", \"uuid\": \"kdx_6987506adf187\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('148', '2026-02-07 09:47:06', 'kardex', 'INSERT', 'kdx_6987506adfb74', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #88\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:47:06\", \"uuid\": \"kdx_6987506adfb74\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('149', '2026-02-07 09:48:07', 'productos', 'UPDATE', '54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660027\", \"nombre\": \"Marranetas\", \"costo\": 162.57, \"precio\": 240.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('150', '2026-02-07 09:48:07', 'kardex', 'INSERT', 'kdx_698750a756b08', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 24.0000, \"referencia\": \"COMPRA #20\", \"costo_unitario\": 160.00, \"fecha\": \"2026-02-04 09:48:07\", \"uuid\": \"kdx_698750a756b08\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('151', '2026-02-07 09:48:07', 'productos', 'UPDATE', '54e1f211-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660006\", \"nombre\": \"Espagetis 500g\", \"costo\": 212.00, \"precio\": 280.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f211-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('152', '2026-02-07 09:48:07', 'kardex', 'INSERT', 'kdx_698750a7587f9', '{\"id_producto\": \"660006\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 12.0000, \"referencia\": \"COMPRA #20\", \"costo_unitario\": 212.00, \"fecha\": \"2026-02-04 09:48:07\", \"uuid\": \"kdx_698750a7587f9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('153', '2026-02-07 09:49:29', 'ventas_cabecera', 'INSERT', '34aa7e0a-0434-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:49:29\", \"total\": 2670.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"34aa7e0a-0434-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('154', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f958485', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -20.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f958485\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('155', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f958f3b', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f958f3b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('156', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f95989c', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f95989c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('157', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f95a21b', '{\"id_producto\": \"660009\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f95a21b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('158', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f95ab3c', '{\"id_producto\": \"660093\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f95ab3c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('159', '2026-02-07 09:49:29', 'kardex', 'INSERT', 'kdx_698750f95b41d', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #89\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:49:29\", \"uuid\": \"kdx_698750f95b41d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('160', '2026-02-07 09:50:01', 'ventas_cabecera', 'INSERT', '47abbfbb-0434-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:50:01\", \"total\": 1700.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"47abbfbb-0434-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('161', '2026-02-07 09:50:01', 'kardex', 'INSERT', 'kdx_698751193d302', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -17.0000, \"referencia\": \"VENTA #90\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:50:01\", \"uuid\": \"kdx_698751193d302\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('162', '2026-02-07 09:50:14', 'ventas_cabecera', 'INSERT', '4f6b4d44-0434-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:50:14\", \"total\": 1300.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"4f6b4d44-0434-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('163', '2026-02-07 09:50:14', 'kardex', 'INSERT', 'kdx_698751263c094', '{\"id_producto\": \"660090\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #91\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:50:14\", \"uuid\": \"kdx_698751263c094\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('164', '2026-02-07 09:50:38', 'ventas_cabecera', 'INSERT', '5e28fe26-0434-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:50:38\", \"total\": 60.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"5e28fe26-0434-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('165', '2026-02-07 09:50:38', 'kardex', 'INSERT', 'kdx_6987513eefb80', '{\"id_producto\": \"660088\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #92\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:50:38\", \"uuid\": \"kdx_6987513eefb80\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('166', '2026-02-07 09:50:49', 'ventas_cabecera', 'INSERT', '64942fa3-0434-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:50:49\", \"total\": 80.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"64942fa3-0434-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('167', '2026-02-07 09:50:49', 'kardex', 'INSERT', 'kdx_69875149b621c', '{\"id_producto\": \"660089\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #93\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:50:49\", \"uuid\": \"kdx_69875149b621c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('169', '2026-02-07 09:57:23', 'mermas_cabecera', 'INSERT', '4f6f8d21-0435-11f1-b0a7-0affd1a0dee5', '{\"usuario\": \"Admin\", \"motivo_general\": \"General\", \"total_costo_perdida\": 1563.25, \"fecha_registro\": \"2026-02-07 09:57:23\", \"id_sucursal\": 4, \"uuid\": \"4f6f8d21-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('170', '2026-02-07 09:57:23', 'kardex', 'INSERT', 'kdx_698752d3bd385', '{\"id_producto\": \"660087\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"SALIDA\", \"cantidad\": -25.0000, \"referencia\": \"MERMA #14\", \"costo_unitario\": 62.53, \"fecha\": \"2026-02-07 09:57:23\", \"uuid\": \"kdx_698752d3bd385\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('171', '2026-02-07 09:58:21', 'ventas_cabecera', 'INSERT', '721d6f66-0435-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:58:21\", \"total\": 600.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"721d6f66-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('172', '2026-02-07 09:58:21', 'kardex', 'INSERT', 'kdx_6987530de8916', '{\"id_producto\": \"660087\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #94\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:58:21\", \"uuid\": \"kdx_6987530de8916\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('173', '2026-02-07 09:58:59', 'ventas_cabecera', 'INSERT', '885624d6-0435-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:58:59\", \"total\": 240.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"885624d6-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('174', '2026-02-07 09:58:59', 'kardex', 'INSERT', 'kdx_69875333392d5', '{\"id_producto\": \"660100\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #95\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:58:59\", \"uuid\": \"kdx_69875333392d5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('175', '2026-02-07 09:59:05', 'ventas_cabecera', 'INSERT', '8be25d2f-0435-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:59:05\", \"total\": 80.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"8be25d2f-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('176', '2026-02-07 09:59:05', 'kardex', 'INSERT', 'kdx_698753392d796', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #96\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:59:05\", \"uuid\": \"kdx_698753392d796\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('177', '2026-02-07 09:59:26', 'ventas_cabecera', 'INSERT', '984f9989-0435-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:59:26\", \"total\": 350.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"984f9989-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('178', '2026-02-07 09:59:26', 'kardex', 'INSERT', 'kdx_6987534e087f5', '{\"id_producto\": \"660102\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #97\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:59:26\", \"uuid\": \"kdx_6987534e087f5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('179', '2026-02-07 09:59:26', 'kardex', 'INSERT', 'kdx_6987534e092a2', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #97\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:59:26\", \"uuid\": \"kdx_6987534e092a2\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('180', '2026-02-07 09:59:36', 'ventas_cabecera', 'INSERT', '9e7e9738-0435-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 09:59:36\", \"total\": 280.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"9e7e9738-0435-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('181', '2026-02-07 09:59:36', 'kardex', 'INSERT', 'kdx_6987535864d3a', '{\"id_producto\": \"660006\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #98\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 09:59:36\", \"uuid\": \"kdx_6987535864d3a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('182', '2026-02-07 10:18:53', 'ventas_cabecera', 'INSERT', '503a854a-0438-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:18:53\", \"total\": 180.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"503a854a-0438-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('183', '2026-02-07 10:18:53', 'kardex', 'INSERT', 'kdx_698757dd90381', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #99\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:18:53\", \"uuid\": \"kdx_698757dd90381\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('184', '2026-02-07 10:18:53', 'kardex', 'INSERT', 'kdx_698757dd90e2d', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #99\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:18:53\", \"uuid\": \"kdx_698757dd90e2d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('185', '2026-02-07 10:19:40', 'ventas_cabecera', 'INSERT', '6c5cfdca-0438-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:19:40\", \"total\": 1000.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"6c5cfdca-0438-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('186', '2026-02-07 10:19:40', 'kardex', 'INSERT', 'kdx_6987580cc1923', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #100\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:19:40\", \"uuid\": \"kdx_6987580cc1923\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('187', '2026-02-07 10:19:40', 'kardex', 'INSERT', 'kdx_6987580cc2307', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #100\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:19:40\", \"uuid\": \"kdx_6987580cc2307\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('188', '2026-02-07 10:19:40', 'kardex', 'INSERT', 'kdx_6987580cc2bf3', '{\"id_producto\": \"660037\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #100\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:19:40\", \"uuid\": \"kdx_6987580cc2bf3\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('189', '2026-02-07 10:20:45', 'ventas_cabecera', 'INSERT', '930d47d6-0438-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:20:45\", \"total\": 240.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"930d47d6-0438-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('190', '2026-02-07 10:20:45', 'kardex', 'INSERT', 'kdx_6987584daba07', '{\"id_producto\": \"990091\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #101\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:20:45\", \"uuid\": \"kdx_6987584daba07\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('191', '2026-02-07 10:27:03', 'ventas_cabecera', 'INSERT', '742738fc-0439-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:27:03\", \"total\": 2600.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"742738fc-0439-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('192', '2026-02-07 10:27:03', 'kardex', 'INSERT', 'kdx_698759c757a4c', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #102\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:27:03\", \"uuid\": \"kdx_698759c757a4c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('193', '2026-02-07 10:27:03', 'kardex', 'INSERT', 'kdx_698759c7583ac', '{\"id_producto\": \"660036\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -6.0000, \"referencia\": \"VENTA #102\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:27:03\", \"uuid\": \"kdx_698759c7583ac\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('194', '2026-02-07 10:27:03', 'kardex', 'INSERT', 'kdx_698759c758c35', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #102\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:27:03\", \"uuid\": \"kdx_698759c758c35\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('195', '2026-02-07 10:27:03', 'kardex', 'INSERT', 'kdx_698759c7594c0', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #102\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:27:03\", \"uuid\": \"kdx_698759c7594c0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('196', '2026-02-07 10:28:05', 'ventas_cabecera', 'INSERT', '9910c1d3-0439-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:28:05\", \"total\": 1970.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"9910c1d3-0439-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('197', '2026-02-07 10:28:05', 'kardex', 'INSERT', 'kdx_69875a05462e0', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #103\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:28:05\", \"uuid\": \"kdx_69875a05462e0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('198', '2026-02-07 10:28:05', 'kardex', 'INSERT', 'kdx_69875a0547b2e', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #103\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:28:05\", \"uuid\": \"kdx_69875a0547b2e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('199', '2026-02-07 10:28:05', 'kardex', 'INSERT', 'kdx_69875a05483c4', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #103\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:28:05\", \"uuid\": \"kdx_69875a05483c4\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('200', '2026-02-07 10:28:05', 'kardex', 'INSERT', 'kdx_69875a0548c8b', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #103\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:28:05\", \"uuid\": \"kdx_69875a0548c8b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('201', '2026-02-07 10:28:33', 'ventas_cabecera', 'INSERT', 'aa15ba40-0439-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:28:33\", \"total\": 30.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"aa15ba40-0439-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('202', '2026-02-07 10:28:33', 'kardex', 'INSERT', 'kdx_69875a21cd642', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #104\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:28:33\", \"uuid\": \"kdx_69875a21cd642\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('203', '2026-02-07 10:29:06', 'ventas_cabecera', 'INSERT', 'bd82d37b-0439-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:29:06\", \"total\": 1200.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"bd82d37b-0439-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('204', '2026-02-07 10:29:06', 'kardex', 'INSERT', 'kdx_69875a4269b49', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -12.0000, \"referencia\": \"VENTA #105\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:29:06\", \"uuid\": \"kdx_69875a4269b49\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('205', '2026-02-07 10:29:32', 'ventas_cabecera', 'INSERT', 'cd070eae-0439-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 10:29:32\", \"total\": 30.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"cd070eae-0439-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('206', '2026-02-07 10:29:32', 'kardex', 'INSERT', 'kdx_69875a5c71a2a', '{\"id_producto\": \"660088\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #106\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 10:29:32\", \"uuid\": \"kdx_69875a5c71a2a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('207', '2026-02-07 11:06:14', 'productos', 'INSERT', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 130.00, \"categoria\": \"DULCES\", \"activo\": 1, \"es_elaborado\": 1, \"es_servicio\": 0, \"id_empresa\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('208', '2026-02-07 11:06:14', 'kardex', 'INSERT', 'kdx_698762f603f20', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 8.0000, \"referencia\": \"COMPRA #21\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-05 11:06:14\", \"uuid\": \"kdx_698762f603f20\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('209', '2026-02-07 11:06:14', 'productos', 'UPDATE', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660026\", \"nombre\": \"Fanguito\", \"costo\": 430.00, \"precio\": 580.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('210', '2026-02-07 11:06:14', 'kardex', 'INSERT', 'kdx_698762f605862', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 3.0000, \"referencia\": \"COMPRA #21\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-05 11:06:14\", \"uuid\": \"kdx_698762f605862\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('211', '2026-02-07 11:11:53', 'ventas_cabecera', 'INSERT', 'b7541584-043f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 11:11:52\", \"total\": 790.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"b7541584-043f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('212', '2026-02-07 11:11:53', 'kardex', 'INSERT', 'kdx_698764490ac59', '{\"id_producto\": \"660087\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #107\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 11:11:52\", \"uuid\": \"kdx_698764490ac59\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('213', '2026-02-07 11:11:53', 'kardex', 'INSERT', 'kdx_698764490b542', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #107\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 11:11:52\", \"uuid\": \"kdx_698764490b542\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('214', '2026-02-07 11:11:53', 'kardex', 'INSERT', 'kdx_698764490bd9e', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -11.0000, \"referencia\": \"VENTA #107\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 11:11:52\", \"uuid\": \"kdx_698764490bd9e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('215', '2026-02-07 11:12:27', 'ventas_cabecera', 'INSERT', 'cc096d3b-043f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-07 11:12:27\", \"total\": 1040.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"cc096d3b-043f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('216', '2026-02-07 11:12:27', 'kardex', 'INSERT', 'kdx_6987646bbfeed', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -8.0000, \"referencia\": \"VENTA #108\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-07 11:12:27\", \"uuid\": \"kdx_6987646bbfeed\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('217', '2026-02-07 17:42:54', 'productos', 'UPDATE', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991118\", \"nombre\": \"Aceite\", \"costo\": 1.20, \"precio\": 2.00, \"categoria\": \"Bodegon\", \"activo\": 1, \"uuid\": \"54e225f1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('218', '2026-02-07 17:43:11', 'productos', 'UPDATE', '54e21e50-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991103\", \"nombre\": \"Harina trigo\", \"costo\": 0.50, \"precio\": 0.60, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21e50-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('219', '2026-02-08 08:49:19', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 82.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('220', '2026-02-08 08:49:32', 'productos', 'UPDATE', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660031\", \"nombre\": \"Croquetas Buffet\", \"costo\": 82.00, \"precio\": 170.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fe58-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('221', '2026-02-08 08:49:42', 'productos', 'UPDATE', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660031\", \"nombre\": \"Croquetas Buffet\", \"costo\": 82.00, \"precio\": 160.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fe58-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('222', '2026-02-08 09:03:42', 'ventas_cabecera', 'INSERT', 'f9d4d5b0-04f6-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 09:03:42\", \"total\": 6590.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"f9d4d5b0-04f6-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('223', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be7e6f1', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -6.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be7e6f1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('224', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be7ef93', '{\"id_producto\": \"660018\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be7ef93\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('225', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be7f76a', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be7f76a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('226', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be7ff1a', '{\"id_producto\": \"660009\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be7ff1a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('227', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be80772', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be80772\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('228', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be80f3b', '{\"id_producto\": \"660100\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be80f3b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('229', '2026-02-08 09:03:42', 'kardex', 'INSERT', 'kdx_698897be816f1', '{\"id_producto\": \"660090\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #109\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:03:42\", \"uuid\": \"kdx_698897be816f1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('230', '2026-02-08 09:06:29', 'productos', 'UPDATE', '54e1f07e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660003\", \"nombre\": \"Pure de tomate 400g lata\", \"costo\": 360.00, \"precio\": 440.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f07e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('231', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f589-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660013\", \"nombre\": \"Cabezote\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f589-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('232', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab1d392', '{\"id_producto\": \"660013\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 16.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 35.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab1d392\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('233', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f914-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660020\", \"nombre\": \"Arroz 1kg pqt\", \"costo\": 570.00, \"precio\": 650.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f914-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('234', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab1e093', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 5.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 570.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab1e093\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('235', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f812-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660018\", \"nombre\": \"Azucar 1kg pqt\", \"costo\": 580.00, \"precio\": 680.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f812-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('236', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab1fd81', '{\"id_producto\": \"660018\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 2.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 580.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab1fd81\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('237', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e20c23-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660096\", \"nombre\": \"pqt torticas 6u\", \"costo\": 120.00, \"precio\": 220.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20c23-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('238', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab20b0a', '{\"id_producto\": \"660096\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 120.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab20b0a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('239', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f07e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660003\", \"nombre\": \"Pure de tomate 400g lata\", \"costo\": 360.00, \"precio\": 440.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f07e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('240', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab225cf', '{\"id_producto\": \"660003\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 8.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 360.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab225cf\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('241', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e2013f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660037\", \"nombre\": \"Cerveza La Fria\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e2013f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('242', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab2372e', '{\"id_producto\": \"660037\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 24.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 210.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab2372e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('243', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660012\", \"nombre\": \"Tartaleta\", \"costo\": 50.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f50f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('244', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab243f9', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 17.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 50.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab243f9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('245', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('246', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab25053', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 11.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab25053\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('247', '2026-02-08 09:07:39', 'productos', 'UPDATE', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660014\", \"nombre\": \"Albondigas pqt\", \"costo\": 220.00, \"precio\": 360.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f60d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('248', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab25d2f', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 5.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 220.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab25d2f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('249', '2026-02-08 09:07:39', 'productos', 'UPDATE', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 130.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('250', '2026-02-08 09:07:39', 'kardex', 'INSERT', 'kdx_698898ab26b01', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #22\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-06 09:07:39\", \"uuid\": \"kdx_698898ab26b01\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('251', '2026-02-08 09:08:19', 'ventas_cabecera', 'INSERT', '9efb1281-04f7-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 09:08:19\", \"total\": 1470.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"9efb1281-04f7-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('252', '2026-02-08 09:08:19', 'kardex', 'INSERT', 'kdx_698898d390333', '{\"id_producto\": \"660013\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #110\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:08:19\", \"uuid\": \"kdx_698898d390333\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('253', '2026-02-08 09:08:19', 'kardex', 'INSERT', 'kdx_698898d390cb1', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -10.0000, \"referencia\": \"VENTA #110\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:08:19\", \"uuid\": \"kdx_698898d390cb1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('254', '2026-02-08 09:08:19', 'kardex', 'INSERT', 'kdx_698898d391527', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #110\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:08:19\", \"uuid\": \"kdx_698898d391527\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('255', '2026-02-08 09:17:55', 'ventas_cabecera', 'INSERT', 'f655d864-04f8-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 09:17:55\", \"total\": 680.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"f655d864-04f8-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('256', '2026-02-08 09:17:55', 'kardex', 'INSERT', 'kdx_69889b139d1ef', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -16.0000, \"referencia\": \"VENTA #111\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:17:55\", \"uuid\": \"kdx_69889b139d1ef\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('257', '2026-02-08 09:17:55', 'kardex', 'INSERT', 'kdx_69889b139e11a', '{\"id_producto\": \"660003\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #111\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 09:17:55\", \"uuid\": \"kdx_69889b139e11a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('258', '2026-02-08 10:10:46', 'ventas_cabecera', 'INSERT', '58301406-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:10:46\", \"total\": 270.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"58301406-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('259', '2026-02-08 10:10:46', 'kardex', 'INSERT', 'kdx_6988a77647586', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #112\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:10:46\", \"uuid\": \"kdx_6988a77647586\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('260', '2026-02-08 10:10:46', 'kardex', 'INSERT', 'kdx_6988a77647ef1', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #112\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:10:46\", \"uuid\": \"kdx_6988a77647ef1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('261', '2026-02-08 10:11:16', 'ventas_cabecera', 'INSERT', '6a2e171c-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:11:16\", \"total\": 740.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"6a2e171c-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('262', '2026-02-08 10:11:16', 'kardex', 'INSERT', 'kdx_6988a794742c1', '{\"id_producto\": \"660008\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #113\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:11:16\", \"uuid\": \"kdx_6988a794742c1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('263', '2026-02-08 10:11:16', 'kardex', 'INSERT', 'kdx_6988a79474b77', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #113\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:11:16\", \"uuid\": \"kdx_6988a79474b77\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('264', '2026-02-08 10:11:53', 'ventas_cabecera', 'INSERT', '804b921e-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:11:53\", \"total\": 960.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"804b921e-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('265', '2026-02-08 10:11:53', 'kardex', 'INSERT', 'kdx_6988a7b98d5bb', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #114\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:11:53\", \"uuid\": \"kdx_6988a7b98d5bb\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('266', '2026-02-08 10:12:44', 'ventas_cabecera', 'INSERT', '9e5d55ac-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:12:44\", \"total\": 60.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"9e5d55ac-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('267', '2026-02-08 10:12:44', 'kardex', 'INSERT', 'kdx_6988a7ec06b9b', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #115\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:12:44\", \"uuid\": \"kdx_6988a7ec06b9b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('268', '2026-02-08 10:12:55', 'ventas_cabecera', 'INSERT', 'a5793897-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:12:55\", \"total\": 1680.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"a5793897-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('269', '2026-02-08 10:12:55', 'kardex', 'INSERT', 'kdx_6988a7f7e9e40', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"VENTA #116\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:12:55\", \"uuid\": \"kdx_6988a7f7e9e40\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('270', '2026-02-08 10:13:22', 'ventas_cabecera', 'INSERT', 'b5386000-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:13:22\", \"total\": 70.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"b5386000-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('271', '2026-02-08 10:13:22', 'kardex', 'INSERT', 'kdx_6988a8125aeb0', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"VENTA #117\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:13:22\", \"uuid\": \"kdx_6988a8125aeb0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('272', '2026-02-08 10:13:53', 'ventas_cabecera', 'INSERT', 'c7e00b4b-0500-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:13:53\", \"total\": 600.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"c7e00b4b-0500-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('273', '2026-02-08 10:13:53', 'kardex', 'INSERT', 'kdx_6988a831a42f3', '{\"id_producto\": \"660087\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #118\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:13:53\", \"uuid\": \"kdx_6988a831a42f3\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('274', '2026-02-08 10:15:45', 'ventas_cabecera', 'INSERT', '0a5f6757-0501-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 10:15:45\", \"total\": 2610.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"0a5f6757-0501-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('275', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a13952e', '{\"id_producto\": \"660104\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a13952e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('276', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a139e19', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a139e19\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('277', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a13a5ed', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a13a5ed\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('278', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a13adbf', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a13adbf\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('279', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a13c5d5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a13c5d5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('280', '2026-02-08 10:15:45', 'kardex', 'INSERT', 'kdx_6988a8a13ceb5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"VENTA #119\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 10:15:45\", \"uuid\": \"kdx_6988a8a13ceb5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('281', '2026-02-08 14:33:49', 'productos', 'UPDATE', '54e20047-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660035\", \"nombre\": \"chicle 30\", \"costo\": 15.00, \"precio\": 30.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e20047-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('282', '2026-02-08 14:33:49', 'kardex', 'INSERT', 'kdx_6988e51d55efe', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 3.0000, \"referencia\": \"COMPRA #23\", \"costo_unitario\": 15.00, \"fecha\": \"2026-02-06 14:33:49\", \"uuid\": \"kdx_6988e51d55efe\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('283', '2026-02-08 14:44:34', 'ventas_cabecera', 'INSERT', '98681c67-0526-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 14:44:34\", \"total\": -750.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"98681c67-0526-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('284', '2026-02-08 14:44:34', 'kardex', 'INSERT', 'kdx_6988e7a2dd628', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 5.0000, \"referencia\": \"REFUND_ITEM_305\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 14:44:34\", \"uuid\": \"kdx_6988e7a2dd628\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('285', '2026-02-08 14:45:06', 'ventas_cabecera', 'INSERT', 'ab8871cc-0526-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 14:45:06\", \"total\": 600.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"ab8871cc-0526-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('286', '2026-02-08 14:45:06', 'kardex', 'INSERT', 'kdx_6988e7c2f314d', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #121\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 14:45:06\", \"uuid\": \"kdx_6988e7c2f314d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('287', '2026-02-08 14:50:34', 'ventas_cabecera', 'INSERT', '6e7ba845-0527-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 14:50:34\", \"total\": 300.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"6e7ba845-0527-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('288', '2026-02-08 14:50:34', 'kardex', 'INSERT', 'kdx_6988e90a10839', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #122\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 14:50:34\", \"uuid\": \"kdx_6988e90a10839\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('289', '2026-02-08 14:50:34', 'kardex', 'INSERT', 'kdx_6988e90a1111f', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #122\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 14:50:34\", \"uuid\": \"kdx_6988e90a1111f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('290', '2026-02-08 15:04:07', 'productos', 'UPDATE', '54e26b9a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991151\", \"nombre\": \"Azucar de Vainilla\", \"costo\": 0.80, \"precio\": 0.90, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e26b9a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('291', '2026-02-08 19:25:31', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('292', '2026-02-08 19:25:31', 'kardex', 'INSERT', 'kdx_6989297b287df', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #24\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-07 19:25:31\", \"uuid\": \"kdx_6989297b287df\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('293', '2026-02-08 19:25:31', 'productos', 'UPDATE', '54e1fddd-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660030\", \"nombre\": \"San jacobo\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fddd-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('294', '2026-02-08 19:25:31', 'kardex', 'INSERT', 'kdx_6989297b2aa48', '{\"id_producto\": \"660030\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #24\", \"costo_unitario\": 180.00, \"fecha\": \"2026-02-07 19:25:31\", \"uuid\": \"kdx_6989297b2aa48\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('295', '2026-02-08 19:25:31', 'productos', 'UPDATE', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881108\", \"nombre\": \"Hamburguesas pollo\", \"costo\": 292.71, \"precio\": 480.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21b15-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('296', '2026-02-08 19:25:31', 'kardex', 'INSERT', 'kdx_6989297b2b906', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 3.0000, \"referencia\": \"COMPRA #24\", \"costo_unitario\": 292.71, \"fecha\": \"2026-02-07 19:25:31\", \"uuid\": \"kdx_6989297b2b906\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('297', '2026-02-08 20:01:26', 'ventas_cabecera', 'INSERT', 'dc247b42-0552-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 20:01:26\", \"total\": 4560.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"dc247b42-0552-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('298', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e662e06', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e662e06\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('299', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e66379d', '{\"id_producto\": \"660032\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e66379d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('300', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e66407e', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e66407e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('301', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e664867', '{\"id_producto\": \"660013\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -10.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e664867\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('302', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e6662af', '{\"id_producto\": \"660096\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e6662af\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('303', '2026-02-08 20:01:26', 'kardex', 'INSERT', 'kdx_698931e666bb7', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #123\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:01:26\", \"uuid\": \"kdx_698931e666bb7\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('304', '2026-02-08 20:02:33', 'ventas_cabecera', 'INSERT', '043a1c1a-0553-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-08 20:02:33\", \"total\": 160.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"043a1c1a-0553-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('305', '2026-02-08 20:02:33', 'kardex', 'INSERT', 'kdx_69893229a0162', '{\"id_producto\": \"660031\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #124\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-08 20:02:33\", \"uuid\": \"kdx_69893229a0162\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('306', '2026-02-08 21:06:06', 'productos', 'UPDATE', '54e26ed8-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991153\", \"nombre\": \"jugo de limon\", \"costo\": 0.25, \"precio\": 0.30, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e26ed8-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('307', '2026-02-08 21:27:26', 'productos', 'UPDATE', '54e299c5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991176\", \"nombre\": \"Saborizante ENCO 120 ml\", \"costo\": 21.00, \"precio\": 22.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e299c5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('308', '2026-02-10 10:58:42', 'ventas_cabecera', 'INSERT', '5f8aeed1-0699-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 10:58:42\", \"total\": 280.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"5f8aeed1-0699-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('309', '2026-02-10 10:58:42', 'kardex', 'INSERT', 'kdx_698b55b2c15b9', '{\"id_producto\": \"660006\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #125\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 10:58:42\", \"uuid\": \"kdx_698b55b2c15b9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('310', '2026-02-10 11:00:46', 'ventas_cabecera', 'INSERT', 'a9287be4-0699-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:00:46\", \"total\": 360.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"a9287be4-0699-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('311', '2026-02-10 11:00:46', 'kardex', 'INSERT', 'kdx_698b562e48c3e', '{\"id_producto\": \"660005\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #126\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:00:46\", \"uuid\": \"kdx_698b562e48c3e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('312', '2026-02-10 11:01:05', 'ventas_cabecera', 'INSERT', 'b4c69bc8-0699-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:01:05\", \"total\": 560.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"b4c69bc8-0699-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('313', '2026-02-10 11:01:05', 'kardex', 'INSERT', 'kdx_698b5641c1c46', '{\"id_producto\": \"660011\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #127\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:01:05\", \"uuid\": \"kdx_698b5641c1c46\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('314', '2026-02-10 11:02:38', 'ventas_cabecera', 'INSERT', 'ec2549ae-0699-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:02:38\", \"total\": 9070.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"ec2549ae-0699-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('315', '2026-02-10 11:02:38', 'kardex', 'INSERT', 'kdx_698b569ea782d', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"VENTA #128\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:02:38\", \"uuid\": \"kdx_698b569ea782d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('316', '2026-02-10 11:02:38', 'kardex', 'INSERT', 'kdx_698b569ea88f3', '{\"id_producto\": \"660032\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #128\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:02:38\", \"uuid\": \"kdx_698b569ea88f3\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('317', '2026-02-10 11:02:38', 'kardex', 'INSERT', 'kdx_698b569ea91cb', '{\"id_producto\": \"660037\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -24.0000, \"referencia\": \"VENTA #128\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:02:38\", \"uuid\": \"kdx_698b569ea91cb\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('318', '2026-02-10 11:03:12', 'ventas_cabecera', 'INSERT', '0053e1c9-069a-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:03:12\", \"total\": 650.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"0053e1c9-069a-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('319', '2026-02-10 11:03:12', 'kardex', 'INSERT', 'kdx_698b56c084e18', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #129\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:03:12\", \"uuid\": \"kdx_698b56c084e18\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('320', '2026-02-10 11:43:15', 'ventas_cabecera', 'INSERT', '98ba87f2-069f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:43:15\", \"total\": 2470.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"98ba87f2-069f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('321', '2026-02-10 11:43:15', 'kardex', 'INSERT', 'kdx_698b6023af80c', '{\"id_producto\": \"660018\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #130\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:43:15\", \"uuid\": \"kdx_698b6023af80c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('322', '2026-02-10 11:43:15', 'kardex', 'INSERT', 'kdx_698b6023b02e0', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #130\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:43:15\", \"uuid\": \"kdx_698b6023b02e0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('323', '2026-02-10 11:43:15', 'kardex', 'INSERT', 'kdx_698b6023b15e6', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -6.0000, \"referencia\": \"VENTA #130\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:43:15\", \"uuid\": \"kdx_698b6023b15e6\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('324', '2026-02-10 11:43:15', 'kardex', 'INSERT', 'kdx_698b6023b1f5d', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -29.0000, \"referencia\": \"VENTA #130\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:43:15\", \"uuid\": \"kdx_698b6023b1f5d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('325', '2026-02-10 11:47:51', 'ventas_cabecera', 'INSERT', '3d4a53de-06a0-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:47:51\", \"total\": 2550.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"3d4a53de-06a0-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('326', '2026-02-10 11:47:51', 'kardex', 'INSERT', 'kdx_698b6137c40d6', '{\"id_producto\": \"660096\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #131\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:47:51\", \"uuid\": \"kdx_698b6137c40d6\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('327', '2026-02-10 11:47:51', 'kardex', 'INSERT', 'kdx_698b6137c54bf', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -14.0000, \"referencia\": \"VENTA #131\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:47:51\", \"uuid\": \"kdx_698b6137c54bf\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('328', '2026-02-10 11:47:51', 'kardex', 'INSERT', 'kdx_698b6137c5db7', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #131\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:47:51\", \"uuid\": \"kdx_698b6137c5db7\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('329', '2026-02-10 11:47:51', 'kardex', 'INSERT', 'kdx_698b6137c65ce', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"VENTA #131\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:47:51\", \"uuid\": \"kdx_698b6137c65ce\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('330', '2026-02-10 11:53:18', 'ventas_cabecera', 'INSERT', '0047a973-06a1-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 11:53:18\", \"total\": 160.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"0047a973-06a1-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('331', '2026-02-10 11:53:18', 'kardex', 'INSERT', 'kdx_698b627ee5d73', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #132\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 11:53:18\", \"uuid\": \"kdx_698b627ee5d73\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('332', '2026-02-10 11:55:36', 'productos', 'UPDATE', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660014\", \"nombre\": \"Albondigas pqt\", \"costo\": 220.00, \"precio\": 370.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f60d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('333', '2026-02-10 12:12:38', 'ventas_cabecera', 'INSERT', 'b3a0dac9-06a3-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 12:12:38\", \"total\": 1220.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"b3a0dac9-06a3-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('334', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706caff8', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706caff8\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('335', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706cba23', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706cba23\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('336', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706cc380', '{\"id_producto\": \"660005\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706cc380\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('337', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706ccc6f', '{\"id_producto\": \"660013\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706ccc6f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('338', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706cd520', '{\"id_producto\": \"660034\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -23.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706cd520\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('339', '2026-02-10 12:12:38', 'kardex', 'INSERT', 'kdx_698b6706cdd82', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -14.0000, \"referencia\": \"VENTA #133\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:12:38\", \"uuid\": \"kdx_698b6706cdd82\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('340', '2026-02-10 12:14:14', 'ventas_cabecera', 'INSERT', 'ecc74ac6-06a3-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 12:14:14\", \"total\": 1890.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"ecc74ac6-06a3-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('341', '2026-02-10 12:14:14', 'kardex', 'INSERT', 'kdx_698b6766ae318', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #134\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:14:14\", \"uuid\": \"kdx_698b6766ae318\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('342', '2026-02-10 12:14:14', 'kardex', 'INSERT', 'kdx_698b6766aec22', '{\"id_producto\": \"660096\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #134\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:14:14\", \"uuid\": \"kdx_698b6766aec22\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('343', '2026-02-10 12:14:14', 'kardex', 'INSERT', 'kdx_698b6766af49a', '{\"id_producto\": \"660016\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #134\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:14:14\", \"uuid\": \"kdx_698b6766af49a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('344', '2026-02-10 12:14:14', 'kardex', 'INSERT', 'kdx_698b6766b0c14', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #134\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:14:14\", \"uuid\": \"kdx_698b6766b0c14\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('345', '2026-02-10 12:15:38', 'ventas_cabecera', 'INSERT', '1ec85b39-06a4-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 12:15:38\", \"total\": 850.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"1ec85b39-06a4-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('346', '2026-02-10 12:15:38', 'kardex', 'INSERT', 'kdx_698b67ba9412b', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #135\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:15:38\", \"uuid\": \"kdx_698b67ba9412b\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('347', '2026-02-10 12:15:38', 'kardex', 'INSERT', 'kdx_698b67ba94a14', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #135\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:15:38\", \"uuid\": \"kdx_698b67ba94a14\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('348', '2026-02-10 12:21:55', 'productos', 'UPDATE', '54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660023\", \"nombre\": \"Cerveza Shekels\", \"costo\": 213.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('349', '2026-02-10 12:21:55', 'kardex', 'INSERT', 'kdx_698b6933a699c', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 24.0000, \"referencia\": \"COMPRA #25\", \"costo_unitario\": 213.00, \"fecha\": \"2026-02-08 12:21:55\", \"uuid\": \"kdx_698b6933a699c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('350', '2026-02-10 12:21:55', 'productos', 'UPDATE', '54e1f98e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660021\", \"nombre\": \"Refresco cola lata 300ml\", \"costo\": 217.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f98e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('351', '2026-02-10 12:21:55', 'kardex', 'INSERT', 'kdx_698b6933a7eba', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 24.0000, \"referencia\": \"COMPRA #25\", \"costo_unitario\": 217.00, \"fecha\": \"2026-02-08 12:21:55\", \"uuid\": \"kdx_698b6933a7eba\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('352', '2026-02-10 12:22:41', 'productos', 'UPDATE', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660010\", \"nombre\": \"Galletas Blackout azul\", \"costo\": 130.00, \"precio\": 160.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f412-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('353', '2026-02-10 12:22:41', 'kardex', 'INSERT', 'kdx_698b6961418cc', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #26\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-08 12:22:41\", \"uuid\": \"kdx_698b6961418cc\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('354', '2026-02-10 12:22:41', 'productos', 'UPDATE', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660015\", \"nombre\": \"Hamgurgesa 5u pqt\", \"costo\": 300.00, \"precio\": 500.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f697-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('355', '2026-02-10 12:22:41', 'kardex', 'INSERT', 'kdx_698b6961434bf', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #26\", \"costo_unitario\": 300.00, \"fecha\": \"2026-02-08 12:22:41\", \"uuid\": \"kdx_698b6961434bf\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('356', '2026-02-10 12:24:30', 'ventas_cabecera', 'INSERT', '5bdd9c36-06a5-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 12:24:30\", \"total\": 5680.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"5bdd9c36-06a5-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('357', '2026-02-10 12:24:30', 'kardex', 'INSERT', 'kdx_698b69ce8e75a', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #136\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:24:30\", \"uuid\": \"kdx_698b69ce8e75a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('358', '2026-02-10 12:24:30', 'kardex', 'INSERT', 'kdx_698b69ce8f059', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -23.0000, \"referencia\": \"VENTA #136\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:24:30\", \"uuid\": \"kdx_698b69ce8f059\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('359', '2026-02-10 12:25:05', 'ventas_cabecera', 'INSERT', '7098527c-06a5-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-10 12:25:05\", \"total\": 1440.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"7098527c-06a5-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('360', '2026-02-10 12:25:05', 'kardex', 'INSERT', 'kdx_698b69f158500', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #137\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:25:05\", \"uuid\": \"kdx_698b69f158500\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('361', '2026-02-10 12:25:05', 'kardex', 'INSERT', 'kdx_698b69f158dd5', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #137\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-10 12:25:05\", \"uuid\": \"kdx_698b69f158dd5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('362', '2026-02-11 14:34:10', 'ventas_cabecera', 'INSERT', '96d99b6f-67a3-433c-8c29-fedd0e50cddc', '{\"fecha\": \"2026-02-11 09:34:10\", \"total\": 300.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"96d99b6f-67a3-433c-8c29-fedd0e50cddc\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('363', '2026-02-11 14:34:10', 'kardex', 'INSERT', 'kdx_0ZKlBBzYbN3Mc', '{\"id_producto\": \"756058841446\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #138\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-11 09:34:10\", \"uuid\": \"kdx_0ZKlBBzYbN3Mc\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('364', '2026-02-11 17:50:57', 'productos', 'UPDATE', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991118\", \"nombre\": \"Aceite\", \"costo\": 1.20, \"precio\": 2.00, \"categoria\": \"Bodegon\", \"activo\": 1, \"uuid\": \"54e225f1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('365', '2026-02-11 17:51:11', 'productos', 'UPDATE', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991118\", \"nombre\": \"Aceite\", \"costo\": 1.20, \"precio\": 2.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e225f1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('366', '2026-02-11 19:26:29', 'ventas_cabecera', 'INSERT', 'd4441ca4-ac7c-4838-8edd-44686746e38a', '{\"fecha\": \"2026-02-11 14:26:29\", \"total\": 150.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"d4441ca4-ac7c-4838-8edd-44686746e38a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('367', '2026-02-11 19:26:29', 'kardex', 'INSERT', 'kdx_vGQaVqGkonwql', '{\"id_producto\": \"756058841446\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #139\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-11 14:26:29\", \"uuid\": \"kdx_vGQaVqGkonwql\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('368', '2026-02-11 22:57:10', 'ventas_cabecera', 'INSERT', '4b61b3b3-f5ce-41cd-8db8-e886bd708d7a', '{\"fecha\": \"2026-02-11 17:57:10\", \"total\": 150.00, \"metodo_pago\": \"Mixto\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"sureima chales\", \"uuid\": \"4b61b3b3-f5ce-41cd-8db8-e886bd708d7a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('369', '2026-02-11 22:57:10', 'kardex', 'INSERT', 'kdx_wpfjZo1KvZMyR', '{\"id_producto\": \"756058841446\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #140\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-11 17:57:10\", \"uuid\": \"kdx_wpfjZo1KvZMyR\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('370', '2026-02-12 00:20:42', 'productos', 'UPDATE', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 130.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('371', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1ecd1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660001\", \"nombre\": \"Chupa chus grandes\", \"costo\": 35.00, \"precio\": 70.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ecd1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('372', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1efce-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660002\", \"nombre\": \"Carritos chocolate\", \"costo\": 25.00, \"precio\": 40.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1efce-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('373', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f07e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660003\", \"nombre\": \"Pure de tomate 400g lata\", \"costo\": 360.00, \"precio\": 440.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f07e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('374', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f10c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660004\", \"nombre\": \"Mini Whiskey 200ml\", \"costo\": 370.00, \"precio\": 400.00, \"categoria\": \"BEBIDAS_A\", \"activo\": 1, \"uuid\": \"54e1f10c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('375', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f190-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660005\", \"nombre\": \"Galletas Porleo\", \"costo\": 130.00, \"precio\": 180.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f190-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('376', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f211-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660006\", \"nombre\": \"Espagetis 500g\", \"costo\": 212.00, \"precio\": 280.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f211-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('377', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f294-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660007\", \"nombre\": \"Refresco en polvo\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f294-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('378', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f310-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660008\", \"nombre\": \"Galleta Biskiato minion\", \"costo\": 150.00, \"precio\": 180.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f310-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('379', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f390-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660009\", \"nombre\": \"Galletas Rellenitas\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f390-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('380', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660010\", \"nombre\": \"Galletas Blackout azul\", \"costo\": 130.00, \"precio\": 160.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f412-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('381', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f490-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660011\", \"nombre\": \"Energizante\", \"costo\": 210.00, \"precio\": 280.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f490-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('382', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660012\", \"nombre\": \"Tartaleta\", \"costo\": 50.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f50f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('383', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f589-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660013\", \"nombre\": \"Cabezote\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f589-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('384', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660014\", \"nombre\": \"Albondigas pqt\", \"costo\": 220.00, \"precio\": 370.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f60d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('385', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660015\", \"nombre\": \"Hamgurgesa 5u pqt\", \"costo\": 300.00, \"precio\": 500.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f697-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('386', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f717-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660016\", \"nombre\": \"Higado de pollo pqt\", \"costo\": 620.00, \"precio\": 730.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f717-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('387', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('388', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f812-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660018\", \"nombre\": \"Azucar 1kg pqt\", \"costo\": 580.00, \"precio\": 680.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f812-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('389', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f893-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660019\", \"nombre\": \"Pinguinos gelatina\", \"costo\": 33.00, \"precio\": 60.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f893-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('390', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f914-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660020\", \"nombre\": \"Arroz 1kg pqt\", \"costo\": 570.00, \"precio\": 650.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1f914-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('391', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1f98e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660021\", \"nombre\": \"Refresco cola lata 300ml\", \"costo\": 217.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f98e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('392', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fa0e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660022\", \"nombre\": \"Refresco limon lata 300ml\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1fa0e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('393', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660023\", \"nombre\": \"Cerveza Shekels\", \"costo\": 213.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fa8a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('394', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fb03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660024\", \"nombre\": \"Cerveza Sta Isabel\", \"costo\": 205.00, \"precio\": 230.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fb03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('395', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660025\", \"nombre\": \"Leche condensada\", \"costo\": 430.00, \"precio\": 520.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('396', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660026\", \"nombre\": \"Fanguito\", \"costo\": 430.00, \"precio\": 580.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('397', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660027\", \"nombre\": \"Marranetas\", \"costo\": 162.57, \"precio\": 240.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1fc6f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('398', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fceb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660028\", \"nombre\": \"Tartaletas especiales\", \"costo\": 90.00, \"precio\": 140.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1fceb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('399', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fd65-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660029\", \"nombre\": \"Caramelos de 15\", \"costo\": 8.00, \"precio\": 15.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1fd65-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('400', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fddd-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660030\", \"nombre\": \"San jacobo\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fddd-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('401', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660031\", \"nombre\": \"Croquetas Buffet\", \"costo\": 82.00, \"precio\": 160.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fe58-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('402', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1fed4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660032\", \"nombre\": \"Cerveza Esple\", \"costo\": 190.00, \"precio\": 230.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e1fed4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('403', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1ff4f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660033\", \"nombre\": \"Chupa chus 40\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ff4f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('404', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e1ffcb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660034\", \"nombre\": \"Caramelos 10\", \"costo\": 6.00, \"precio\": 10.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1ffcb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('405', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20047-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660035\", \"nombre\": \"chicle 30\", \"costo\": 15.00, \"precio\": 30.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e20047-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('406', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e200c3-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660036\", \"nombre\": \"jugo cajita 200ml\", \"costo\": 135.00, \"precio\": 180.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e200c3-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('407', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2013f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660037\", \"nombre\": \"Cerveza La Fria\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e2013f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('408', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e201b9-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660038\", \"nombre\": \"Cerveza Beer azul\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e201b9-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('409', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20235-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660039\", \"nombre\": \"Helado Mousse 7oz\", \"costo\": 90.00, \"precio\": 150.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20235-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('410', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e202b1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660040\", \"nombre\": \"Dulce 3 leches vaso 7oz\", \"costo\": 150.00, \"precio\": 250.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e202b1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('411', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2032c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660041\", \"nombre\": \"Torticas\", \"costo\": 35.00, \"precio\": 70.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e2032c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('412', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e205ab-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660042\", \"nombre\": \"Pan de Gloria\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e205ab-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('413', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20629-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660043\", \"nombre\": \"Minicake 18cm\", \"costo\": 700.00, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20629-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('414', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20721-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660044\", \"nombre\": \"Minicake Fanguito\", \"costo\": 800.00, \"precio\": 1700.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20721-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('415', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e207ad-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660045\", \"nombre\": \"Minicake Bombom\", \"costo\": 1105.00, \"precio\": 2000.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e207ad-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('416', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20827-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660046\", \"nombre\": \"Harina 1kg\", \"costo\": 500.00, \"precio\": 600.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20827-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('417', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e208a4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660087\", \"nombre\": \"Galletas Saltitacos\", \"costo\": 62.53, \"precio\": 200.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e208a4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('418', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20921-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660088\", \"nombre\": \"Caldo de pollo sobrecito\", \"costo\": 18.00, \"precio\": 30.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20921-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('419', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2099d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660089\", \"nombre\": \"pastillita pollo con tomate\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e2099d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('420', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20a18-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660090\", \"nombre\": \"lomo en bandeja 1lb\", \"costo\": 1150.00, \"precio\": 1300.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e20a18-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('421', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20a99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660093\", \"nombre\": \"Pqt de 4 panques\", \"costo\": 180.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20a99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('422', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20b21-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660094\", \"nombre\": \"Gacenigas mini\", \"costo\": 200.00, \"precio\": 280.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20b21-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('423', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20ba2-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660095\", \"nombre\": \"Panque de chocolate\", \"costo\": 70.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20ba2-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('424', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20c23-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660096\", \"nombre\": \"pqt torticas 6u\", \"costo\": 120.00, \"precio\": 220.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20c23-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('425', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20ca1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660097\", \"nombre\": \"Bolsa de 8 panes\", \"costo\": 160.00, \"precio\": 200.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20ca1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('426', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20d22-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660098\", \"nombre\": \"Cake 2900\", \"costo\": 2000.00, \"precio\": 2900.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20d22-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('427', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20da7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660099\", \"nombre\": \"Marquesita\", \"costo\": 65.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20da7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('428', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20eb0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660100\", \"nombre\": \"ojitos gummy gum\", \"costo\": 40.00, \"precio\": 80.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e20eb0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('429', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20f35-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660101\", \"nombre\": \"Cafe en sobre\", \"costo\": 25.00, \"precio\": 40.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20f35-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('430', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e20fb5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660102\", \"nombre\": \"Jabon de carbon\", \"costo\": 170.00, \"precio\": 200.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e20fb5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('431', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21032-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660103\", \"nombre\": \"jabon de bano\", \"costo\": 130.00, \"precio\": 150.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e21032-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('432', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e210ac-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660104\", \"nombre\": \"Donas Donuts\", \"costo\": 120.00, \"precio\": 160.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e210ac-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('433', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2112e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841446\", \"nombre\": \"COCA COLA GRANDE\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"Bebidas\", \"activo\": 1, \"uuid\": \"54e2112e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('434', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e211be-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841453\", \"nombre\": \"Refresco de naranja\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"Bebidas\", \"activo\": 1, \"uuid\": \"54e211be-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('435', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21241-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841477\", \"nombre\": \"melcocha\", \"costo\": 20.00, \"precio\": 40.00, \"categoria\": \"Pruebas\", \"activo\": 1, \"uuid\": \"54e21241-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('436', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e212c4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841478\", \"nombre\": \"Cupcakes\", \"costo\": 40.00, \"precio\": 120.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e212c4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('437', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21347-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841479\", \"nombre\": \"Capacillo de papel\", \"costo\": 1.00, \"precio\": 2.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21347-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('438', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e213cb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841480\", \"nombre\": \"Yuca en Pure\", \"costo\": 100.00, \"precio\": 120.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e213cb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('439', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21447-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"88011\", \"nombre\": \"Producto de Prueba\", \"costo\": 20.00, \"precio\": 50.00, \"categoria\": \"Pruebas\", \"activo\": 1, \"uuid\": \"54e21447-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('440', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e214cb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"88012\", \"nombre\": \"Producto de Prueba2\", \"costo\": 20.00, \"precio\": 50.00, \"categoria\": \"Pruebas\", \"activo\": 1, \"uuid\": \"54e214cb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('441', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2154d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881101\", \"nombre\": \"Minicake 1500\", \"costo\": 1041.35, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e2154d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('442', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e215d5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881102\", \"nombre\": \"Minicake fanguito\", \"costo\": 565.04, \"precio\": 1700.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e215d5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('443', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21884-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881103\", \"nombre\": \"Tortica grande\", \"costo\": 45.00, \"precio\": 70.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21884-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('444', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2190d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881104\", \"nombre\": \"Torticas chiquita\", \"costo\": 35.00, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e2190d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('445', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2198e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881105\", \"nombre\": \"Tartaletas\", \"costo\": 50.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e2198e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('446', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21a14-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881106\", \"nombre\": \"Minicake 1500 choco\", \"costo\": 1041.35, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a14-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('447', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21a94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881107\", \"nombre\": \"Mini Cake\", \"costo\": 567.90, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21a94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('448', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21b15-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881108\", \"nombre\": \"Hamburguesas pollo\", \"costo\": 292.71, \"precio\": 480.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21b15-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('449', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21ba0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881109\", \"nombre\": \"Cabezotes\", \"costo\": 33.55, \"precio\": 80.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e21ba0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('450', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21c24-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"881110\", \"nombre\": \"PQT Picadillo 1lb\", \"costo\": 289.80, \"precio\": 330.00, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e21c24-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('451', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21ca6-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"990091\", \"nombre\": \"Cerveza Presidente\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"54e21ca6-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('452', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21d30-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991101\", \"nombre\": \"Azucar Blanca\", \"costo\": 0.58, \"precio\": 0.65, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21d30-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('453', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21dbe-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991102\", \"nombre\": \"azucar prieta\", \"costo\": 0.61, \"precio\": 0.65, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21dbe-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('454', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21e50-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991103\", \"nombre\": \"Harina trigo\", \"costo\": 0.50, \"precio\": 0.60, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21e50-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('455', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21ed8-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991104\", \"nombre\": \"leche en polvo\", \"costo\": 1.50, \"precio\": 1.65, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21ed8-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('456', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21f5d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991105\", \"nombre\": \"maicena\", \"costo\": 1.20, \"precio\": 1.20, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21f5d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('457', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e21fe2-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991106\", \"nombre\": \"polvo hornear\", \"costo\": 1.80, \"precio\": 2.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e21fe2-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('458', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22064-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991107\", \"nombre\": \"levadura\", \"costo\": 2.40, \"precio\": 2.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22064-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('459', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e220e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991108\", \"nombre\": \"guayaba en barra\", \"costo\": 0.85, \"precio\": 1.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e220e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('460', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22169-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991109\", \"nombre\": \"canela en polvo\", \"costo\": 2.50, \"precio\": 3.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22169-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('461', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e221eb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991110\", \"nombre\": \"Bicarbonato\", \"costo\": 3.60, \"precio\": 4.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e221eb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('462', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2226d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991111\", \"nombre\": \"mejorador de pan\", \"costo\": 1.80, \"precio\": 2.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2226d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('463', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e222ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991112\", \"nombre\": \"CMC\", \"costo\": 5.00, \"precio\": 8.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e222ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('464', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2236e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991113\", \"nombre\": \"Emulsionante redolmy\", \"costo\": 4.15, \"precio\": 4.50, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2236e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('465', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e223ef-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991114\", \"nombre\": \"sazon en sobre\", \"costo\": 45.00, \"precio\": 70.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e223ef-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('466', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2246c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991115\", \"nombre\": \"pastillita de sabor\", \"costo\": 25.00, \"precio\": 50.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2246c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('467', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e224ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991116\", \"nombre\": \"yema huevo\", \"costo\": 50.00, \"precio\": 55.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e224ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('468', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2256c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991117\", \"nombre\": \"clara huevo\", \"costo\": 50.00, \"precio\": 55.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2256c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('469', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991118\", \"nombre\": \"Aceite\", \"costo\": 1.20, \"precio\": 2.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e225f1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('470', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22672-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991119\", \"nombre\": \"Sal comun\", \"costo\": 0.12, \"precio\": 0.15, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22672-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('471', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e226ef-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991120\", \"nombre\": \"Vainilla liquida\", \"costo\": 2.00, \"precio\": 2.20, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e226ef-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('472', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22770-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991121\", \"nombre\": \"Pan Rayado\", \"costo\": 0.43, \"precio\": 0.60, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22770-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('473', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e227ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991122\", \"nombre\": \"chapilla chocolate oscuro\", \"costo\": 3.50, \"precio\": 3.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e227ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('474', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2286c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991123\", \"nombre\": \"Gelatina fresa\", \"costo\": 5.00, \"precio\": 6.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2286c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('475', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e228eb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991124\", \"nombre\": \"pasta de ajo\", \"costo\": 0.40, \"precio\": 0.50, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e228eb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('476', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22968-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991125\", \"nombre\": \"Pasta verde cebollino\", \"costo\": 0.27, \"precio\": 0.29, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22968-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('477', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e229e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991126\", \"nombre\": \"mostaza\", \"costo\": 2.50, \"precio\": 2.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e229e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('478', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22a63-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991127\", \"nombre\": \"mostaza agranel\", \"costo\": 2.50, \"precio\": 2.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22a63-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('479', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22ae3-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991128\", \"nombre\": \"semifrio de kiwi\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22ae3-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('480', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22b67-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991129\", \"nombre\": \"Mousse limon\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22b67-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('481', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e22d84-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991130\", \"nombre\": \"Mouse Chocolate\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e22d84-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('482', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2481e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991131\", \"nombre\": \"semifrio choco\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2481e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('483', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e24ac1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991132\", \"nombre\": \"Mouse de fresa\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e24ac1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('484', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e24c94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991133\", \"nombre\": \"Crema Pastelera\", \"costo\": 2.00, \"precio\": 2.20, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e24c94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('485', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e24e33-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991134\", \"nombre\": \"Grenatina\", \"costo\": 4.60, \"precio\": 5.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e24e33-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('486', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e24fcc-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991135\", \"nombre\": \"cocoa pura\", \"costo\": 1.00, \"precio\": 1.20, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e24fcc-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('487', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e25137-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991136\", \"nombre\": \"gragea de colores\", \"costo\": 2.90, \"precio\": 3.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e25137-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('488', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e252d4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991137\", \"nombre\": \"grageas de chocolate\", \"costo\": 2.90, \"precio\": 3.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e252d4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('489', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e25472-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991138\", \"nombre\": \"Natilla de coco\", \"costo\": 0.50, \"precio\": 1.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e25472-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('490', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2573d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991139\", \"nombre\": \"margarina\", \"costo\": 2.60, \"precio\": 3.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2573d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('491', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2590f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991140\", \"nombre\": \"Natilla de Chocolate\", \"costo\": 0.64, \"precio\": 0.80, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2590f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('492', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e25aad-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991141\", \"nombre\": \"Natilla de Fresa\", \"costo\": 0.43, \"precio\": 0.50, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e25aad-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('493', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e25c4d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991142\", \"nombre\": \"Natilla de Limon\", \"costo\": 0.43, \"precio\": 0.50, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e25c4d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('494', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e25dea-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991143\", \"nombre\": \"Natilla de Fanguito\", \"costo\": 0.50, \"precio\": 0.60, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e25dea-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('495', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2601e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991144\", \"nombre\": \"Fanguito\", \"costo\": 1.25, \"precio\": 1.20, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e2601e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('496', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e261ba-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991145\", \"nombre\": \"Almibar (1:1,5)\", \"costo\": 0.36, \"precio\": 0.46, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e261ba-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('497', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26357-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991146\", \"nombre\": \"Pesto\", \"costo\": 0.27, \"precio\": 0.30, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e26357-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('498', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26529-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991147\", \"nombre\": \"Queso\", \"costo\": 0.50, \"precio\": 0.55, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e26529-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('499', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e266c7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991148\", \"nombre\": \"Panetelas Redolmy minicake\", \"costo\": 253.00, \"precio\": 253.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e266c7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('500', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26863-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991149\", \"nombre\": \"merengue emul\", \"costo\": 129.00, \"precio\": 150.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e26863-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('501', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26a00-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991150\", \"nombre\": \"merengue italiano\", \"costo\": 159.19, \"precio\": 200.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e26a00-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('502', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26b9a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991151\", \"nombre\": \"Azucar de Vainilla\", \"costo\": 0.80, \"precio\": 0.90, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e26b9a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('503', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26d35-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991152\", \"nombre\": \"Picadillo pollo mdm\", \"costo\": 0.63, \"precio\": 0.68, \"categoria\": \"CONGELADOS\", \"activo\": 1, \"uuid\": \"54e26d35-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('504', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e26ed8-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991153\", \"nombre\": \"jugo de limon\", \"costo\": 0.25, \"precio\": 0.30, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e26ed8-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('505', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e27073-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991154\", \"nombre\": \"Ron o alcohol\", \"costo\": 0.20, \"precio\": 0.25, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e27073-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('506', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e27209-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991155\", \"nombre\": \"vinagre\", \"costo\": 0.35, \"precio\": 0.50, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e27209-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('507', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e273a0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991156\", \"nombre\": \"natilla guayaba\", \"costo\": 0.37, \"precio\": 0.40, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e273a0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('508', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e27b5f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991157\", \"nombre\": \"Colorante amarillo polvo\", \"costo\": 35.00, \"precio\": 38.00, \"categoria\": \"B. Alcoholicas\", \"activo\": 1, \"uuid\": \"54e27b5f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('509', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e27d5f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991158\", \"nombre\": \"Almibar (1:1)\", \"costo\": 0.41, \"precio\": 0.50, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e27d5f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('510', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e27f03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991159\", \"nombre\": \"Colorante ENCO 40g\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e27f03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('511', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e280a1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991160\", \"nombre\": \"Colorante ENCO 20g\", \"costo\": 55.00, \"precio\": 60.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e280a1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('512', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2823c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991161\", \"nombre\": \"Colorante Cheffmaster 20g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2823c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('513', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2840a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991162\", \"nombre\": \"Colorante Tinta negra\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2840a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('514', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2856f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991163\", \"nombre\": \"Colorante Tinta rosada\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2856f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('515', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e28706-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991164\", \"nombre\": \"Colorante Tinta namarilla\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e28706-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('516', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2889d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991165\", \"nombre\": \"Colorante Soft Gel (MIX) 25g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2889d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('517', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e28a03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991166\", \"nombre\": \"Colorante OTELSA azul\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e28a03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('518', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e28b99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991167\", \"nombre\": \"Colorante OTELSA rojo\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e28b99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('519', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e28d2e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991168\", \"nombre\": \"Colorante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e28d2e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('520', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e28ecb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991169\", \"nombre\": \"Colorante agranel\", \"costo\": 30.00, \"precio\": 35.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e28ecb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('521', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e29067-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991170\", \"nombre\": \"Chips horneables de chocolate\", \"costo\": 4.50, \"precio\": 5.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e29067-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('522', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e291ff-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991171\", \"nombre\": \"Emulsionante supernortemul\", \"costo\": 7.00, \"precio\": 8.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e291ff-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('523', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e29367-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991172\", \"nombre\": \"Saborizante Carolesen 60 ml\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e29367-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('524', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e29502-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991173\", \"nombre\": \"Saborizante Carolesen Tutifruti 510 ml\", \"costo\": 35.00, \"precio\": 38.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e29502-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('525', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2969d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991174\", \"nombre\": \"Saborizante Loran 118 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2969d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('526', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e29833-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991175\", \"nombre\": \"Saborizante La Anita 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e29833-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('527', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e299c5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991176\", \"nombre\": \"Saborizante ENCO 120 ml\", \"costo\": 21.00, \"precio\": 22.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e299c5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('528', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e29b28-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991177\", \"nombre\": \"Saborizante ENCO 60 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e29b28-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('529', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2a346-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991178\", \"nombre\": \"Saborizante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2a346-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('530', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2a521-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991179\", \"nombre\": \"Saborizante Flor d Arancio\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2a521-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('531', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991180\", \"nombre\": \"Saborizante Lorsnn Tutifruti\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('532', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2a816-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991181\", \"nombre\": \"Saborizante DUCHE mangp 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2a816-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('533', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991182\", \"nombre\": \"Saborizante DEIMPIN guanabana 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('534', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2ab49-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991183\", \"nombre\": \"Saborizante Esencia 3,7ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2ab49-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('535', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2acdc-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991184\", \"nombre\": \"Saborizantes agranel\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2acdc-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('536', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2ae75-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991185\", \"nombre\": \"Tartaletas (base)\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2ae75-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('537', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2afde-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991186\", \"nombre\": \"Nata\", \"costo\": 2.20, \"precio\": 2.60, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2afde-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('538', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2b175-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991187\", \"nombre\": \"Leche condensada\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b175-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('539', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2b30b-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991188\", \"nombre\": \"Refresco polvo Mayar\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b30b-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('540', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2b49f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991189\", \"nombre\": \"Mantequilla de mani\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b49f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('541', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2b604-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991190\", \"nombre\": \"Coco deshidratado\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"\", \"activo\": 1, \"uuid\": \"54e2b604-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('542', '2026-02-12 00:20:42', 'productos', 'UPDATE', '54e2b7d7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"TEST-999\", \"nombre\": \"Producto de Prueba\", \"costo\": 20.00, \"precio\": 50.00, \"categoria\": \"Pruebas\", \"activo\": 1, \"uuid\": \"54e2b7d7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('543', '2026-02-12 13:02:40', 'productos', 'UPDATE', '54e1f390-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660009\", \"nombre\": \"Galletas Rellenitas\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f390-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('544', '2026-02-12 13:02:40', 'kardex', 'INSERT', 'kdx_698e15c07daae', '{\"id_producto\": \"660009\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 4.0000, \"referencia\": \"COMPRA #27\", \"costo_unitario\": 120.00, \"fecha\": \"2026-02-08 13:02:40\", \"uuid\": \"kdx_698e15c07daae\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('545', '2026-02-12 13:03:48', 'mermas_cabecera', 'INSERT', '2e3b9565-083d-11f1-b0a7-0affd1a0dee5', '{\"usuario\": \"Admin\", \"motivo_general\": \"General\", \"total_costo_perdida\": 292.71, \"fecha_registro\": \"2026-02-12 13:03:48\", \"id_sucursal\": 4, \"uuid\": \"2e3b9565-083d-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('546', '2026-02-12 13:03:48', 'kardex', 'INSERT', 'kdx_698e1604a87d9', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"SALIDA\", \"cantidad\": -1.0000, \"referencia\": \"MERMA #15\", \"costo_unitario\": 292.71, \"fecha\": \"2026-02-12 13:03:48\", \"uuid\": \"kdx_698e1604a87d9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('547', '2026-02-12 13:06:53', 'productos', 'UPDATE', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660015\", \"nombre\": \"Hamgurgesa 5u pqt\", \"costo\": 300.00, \"precio\": 500.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f697-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('548', '2026-02-12 13:06:53', 'kardex', 'INSERT', 'kdx_698e16bde6c25', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 3.0000, \"referencia\": \"COMPRA #28\", \"costo_unitario\": 300.00, \"fecha\": \"2026-02-08 13:06:53\", \"uuid\": \"kdx_698e16bde6c25\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('553', '2026-02-12 13:09:57', 'ventas_cabecera', 'INSERT', '0a36ba47-083e-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:07:59\", \"total\": 500.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"0a36ba47-083e-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('554', '2026-02-12 13:09:57', 'kardex', 'INSERT', 'kdx_698e1775b8c9f', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #145\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:07:59\", \"uuid\": \"kdx_698e1775b8c9f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('555', '2026-02-12 13:12:27', 'ventas_cabecera', 'INSERT', '637be7ec-083e-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:12:27\", \"total\": -500.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"637be7ec-083e-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('556', '2026-02-12 13:12:27', 'kardex', 'INSERT', 'kdx_698e180b80aee', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"REFUND_ITEM_357\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:12:27\", \"uuid\": \"kdx_698e180b80aee\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('557', '2026-02-12 13:13:46', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('558', '2026-02-12 13:13:46', 'kardex', 'INSERT', 'kdx_698e185a6a78d', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 5.0000, \"referencia\": \"COMPRA #29\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-08 13:13:46\", \"uuid\": \"kdx_698e185a6a78d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('559', '2026-02-12 13:14:20', 'ventas_cabecera', 'INSERT', 'a6b525d5-083e-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:13:59\", \"total\": 750.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"a6b525d5-083e-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('560', '2026-02-12 13:14:20', 'kardex', 'INSERT', 'kdx_698e187c4baf0', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #147\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:13:59\", \"uuid\": \"kdx_698e187c4baf0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('561', '2026-02-12 13:19:31', 'productos', 'UPDATE', '54e1f98e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660021\", \"nombre\": \"Refresco cola lata 300ml\", \"costo\": 217.00, \"precio\": 250.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e1f98e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('563', '2026-02-12 13:21:04', 'ventas_cabecera', 'INSERT', '97baa055-083f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:21:04\", \"total\": -960.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"97baa055-083f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('564', '2026-02-12 13:21:04', 'kardex', 'INSERT', 'kdx_698e1a10a5179', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 4.0000, \"referencia\": \"REFUND_ITEM_348\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:21:04\", \"uuid\": \"kdx_698e1a10a5179\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('565', '2026-02-12 13:21:36', 'ventas_cabecera', 'INSERT', 'aacbc675-083f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:21:15\", \"total\": 1000.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"aacbc675-083f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('566', '2026-02-12 13:21:36', 'kardex', 'INSERT', 'kdx_698e1a30a251f', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #150\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:21:15\", \"uuid\": \"kdx_698e1a30a251f\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('567', '2026-02-12 13:23:16', 'ventas_cabecera', 'INSERT', 'e613a976-083f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:23:16\", \"total\": -480.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"e613a976-083f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('568', '2026-02-12 13:23:16', 'kardex', 'INSERT', 'kdx_698e1a941dd46', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"REFUND_ITEM_345\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:23:16\", \"uuid\": \"kdx_698e1a941dd46\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('569', '2026-02-12 13:23:48', 'ventas_cabecera', 'INSERT', 'f9a2e288-083f-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:23:48\", \"total\": -480.00, \"metodo_pago\": \"Devolución\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"DEVOLUCIÓN\", \"uuid\": \"f9a2e288-083f-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('570', '2026-02-12 13:23:48', 'kardex', 'INSERT', 'kdx_698e1ab4e4f63', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"REFUND_ITEM_349\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:23:48\", \"uuid\": \"kdx_698e1ab4e4f63\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('571', '2026-02-12 13:24:30', 'ventas_cabecera', 'INSERT', '1250f415-0840-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:24:09\", \"total\": 500.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"1250f415-0840-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('572', '2026-02-12 13:24:30', 'kardex', 'INSERT', 'kdx_698e1ade53fd4', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #153\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:24:09\", \"uuid\": \"kdx_698e1ade53fd4\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('573', '2026-02-12 13:26:28', 'ventas_cabecera', 'INSERT', '58780d35-0840-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:26:07\", \"total\": 40.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"58780d35-0840-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('574', '2026-02-12 13:26:28', 'kardex', 'INSERT', 'kdx_698e1b5409f56', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #154\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:26:07\", \"uuid\": \"kdx_698e1b5409f56\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('575', '2026-02-12 13:33:57', 'productos', 'UPDATE', '54e1f190-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660005\", \"nombre\": \"Galletas Porleo\", \"costo\": 130.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f190-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('576', '2026-02-12 13:54:01', 'ventas_cabecera', 'INSERT', '31c12861-0844-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:53:40\", \"total\": 2800.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"31c12861-0844-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('577', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c91283d', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c91283d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('578', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c91337e', '{\"id_producto\": \"660005\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c91337e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('579', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c914982', '{\"id_producto\": \"660032\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c914982\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('580', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c91545a', '{\"id_producto\": \"660023\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c91545a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('581', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c915e34', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c915e34\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('582', '2026-02-12 13:54:01', 'kardex', 'INSERT', 'kdx_698e21c9167be', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #155\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:53:40\", \"uuid\": \"kdx_698e21c9167be\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('583', '2026-02-12 13:55:26', 'ventas_cabecera', 'INSERT', '649681f7-0844-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:55:05\", \"total\": 1775.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"649681f7-0844-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('584', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e57d25', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e57d25\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('585', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e586bb', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e586bb\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('586', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e59006', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e59006\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('587', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e5986a', '{\"id_producto\": \"660096\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e5986a\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('588', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e5a0a9', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e5a0a9\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('589', '2026-02-12 13:55:26', 'kardex', 'INSERT', 'kdx_698e221e5a8fd', '{\"id_producto\": \"660104\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #156\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:05\", \"uuid\": \"kdx_698e221e5a8fd\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('590', '2026-02-12 13:55:59', 'ventas_cabecera', 'INSERT', '785942f7-0844-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:55:38\", \"total\": 240.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"785942f7-0844-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('591', '2026-02-12 13:55:59', 'kardex', 'INSERT', 'kdx_698e223f7d3e7', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -6.0000, \"referencia\": \"VENTA #157\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:55:38\", \"uuid\": \"kdx_698e223f7d3e7\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('592', '2026-02-12 13:56:36', 'ventas_cabecera', 'INSERT', '8e5d4143-0844-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:56:15\", \"total\": 1450.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"8e5d4143-0844-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('593', '2026-02-12 13:56:36', 'kardex', 'INSERT', 'kdx_698e22646da62', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #158\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:56:15\", \"uuid\": \"kdx_698e22646da62\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('594', '2026-02-12 13:56:36', 'kardex', 'INSERT', 'kdx_698e22646f428', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #158\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:56:15\", \"uuid\": \"kdx_698e22646f428\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('595', '2026-02-12 13:56:36', 'kardex', 'INSERT', 'kdx_698e226470ea6', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #158\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:56:15\", \"uuid\": \"kdx_698e226470ea6\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('596', '2026-02-12 13:57:22', 'productos', 'UPDATE', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660010\", \"nombre\": \"Galletas Blackout azul\", \"costo\": 130.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f412-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('597', '2026-02-12 13:59:16', 'ventas_cabecera', 'INSERT', 'ed77856b-0844-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:58:55\", \"total\": 580.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"ed77856b-0844-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('598', '2026-02-12 13:59:16', 'kardex', 'INSERT', 'kdx_698e2304017d0', '{\"id_producto\": \"660030\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #159\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:58:55\", \"uuid\": \"kdx_698e2304017d0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('599', '2026-02-12 13:59:16', 'kardex', 'INSERT', 'kdx_698e230402ae8', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #159\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 13:58:55\", \"uuid\": \"kdx_698e230402ae8\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('600', '2026-02-12 14:09:11', 'productos', 'INSERT', '507bf900-0846-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440002\", \"nombre\": \"Cerveza star\", \"costo\": 200.00, \"precio\": 240.00, \"categoria\": \"General\", \"activo\": 1, \"es_elaborado\": 1, \"es_servicio\": 0, \"id_empresa\": 1, \"uuid\": \"507bf900-0846-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('601', '2026-02-12 14:09:11', 'kardex', 'INSERT', 'kdx_698e2557999b6', '{\"id_producto\": \"440002\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 24.0000, \"referencia\": \"COMPRA #30\", \"costo_unitario\": 200.00, \"fecha\": \"2026-02-10 14:09:11\", \"uuid\": \"kdx_698e2557999b6\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('602', '2026-02-12 14:09:11', 'productos', 'UPDATE', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 130.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('603', '2026-02-12 14:09:11', 'kardex', 'INSERT', 'kdx_698e25579aa34', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 15.0000, \"referencia\": \"COMPRA #30\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-10 14:09:11\", \"uuid\": \"kdx_698e25579aa34\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('604', '2026-02-12 14:09:11', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('605', '2026-02-12 14:09:11', 'kardex', 'INSERT', 'kdx_698e25579ba12', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 10.0000, \"referencia\": \"COMPRA #30\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-10 14:09:11\", \"uuid\": \"kdx_698e25579ba12\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('606', '2026-02-12 14:09:11', 'productos', 'UPDATE', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660026\", \"nombre\": \"Fanguito\", \"costo\": 430.00, \"precio\": 580.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('607', '2026-02-12 14:09:11', 'kardex', 'INSERT', 'kdx_698e25579c9bf', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 2.0000, \"referencia\": \"COMPRA #30\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-10 14:09:11\", \"uuid\": \"kdx_698e25579c9bf\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('608', '2026-02-12 14:09:11', 'productos', 'UPDATE', '54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660025\", \"nombre\": \"Leche condensada\", \"costo\": 430.00, \"precio\": 520.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('609', '2026-02-12 14:09:11', 'kardex', 'INSERT', 'kdx_698e25579dbda', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 2.0000, \"referencia\": \"COMPRA #30\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-10 14:09:11\", \"uuid\": \"kdx_698e25579dbda\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('610', '2026-02-12 14:11:22', 'productos', 'UPDATE', '507bf900-0846-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440002\", \"nombre\": \"Cerveza star lager\", \"costo\": 200.00, \"precio\": 240.00, \"categoria\": \"CERVEZAS\", \"activo\": 1, \"uuid\": \"507bf900-0846-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('611', '2026-02-12 14:12:32', 'productos', 'UPDATE', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 140.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('612', '2026-02-12 14:13:10', 'ventas_cabecera', 'INSERT', 'df097089-0846-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 14:12:49\", \"total\": 1750.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"df097089-0846-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('613', '2026-02-12 14:13:10', 'kardex', 'INSERT', 'kdx_698e2646c086e', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #160\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:12:49\", \"uuid\": \"kdx_698e2646c086e\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('614', '2026-02-12 14:13:10', 'kardex', 'INSERT', 'kdx_698e2646c11e7', '{\"id_producto\": \"660089\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #160\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:12:49\", \"uuid\": \"kdx_698e2646c11e7\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('615', '2026-02-12 14:13:10', 'kardex', 'INSERT', 'kdx_698e2646c19f0', '{\"id_producto\": \"660032\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #160\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:12:49\", \"uuid\": \"kdx_698e2646c19f0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('616', '2026-02-12 14:13:10', 'kardex', 'INSERT', 'kdx_698e2646c2249', '{\"id_producto\": \"440002\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #160\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:12:49\", \"uuid\": \"kdx_698e2646c2249\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('617', '2026-02-12 14:13:10', 'kardex', 'INSERT', 'kdx_698e2646c2a89', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #160\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:12:49\", \"uuid\": \"kdx_698e2646c2a89\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('618', '2026-02-12 14:14:16', 'ventas_cabecera', 'INSERT', '05f9d146-0847-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 14:13:55\", \"total\": 3130.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"05f9d146-0847-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('619', '2026-02-12 14:14:16', 'kardex', 'INSERT', 'kdx_698e26881cb92', '{\"id_producto\": \"660032\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #161\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:13:55\", \"uuid\": \"kdx_698e26881cb92\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('620', '2026-02-12 14:14:16', 'kardex', 'INSERT', 'kdx_698e26881d610', '{\"id_producto\": \"440002\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #161\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:13:55\", \"uuid\": \"kdx_698e26881d610\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('621', '2026-02-12 14:14:16', 'kardex', 'INSERT', 'kdx_698e26881e010', '{\"id_producto\": \"660019\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"VENTA #161\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:13:55\", \"uuid\": \"kdx_698e26881e010\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('622', '2026-02-12 14:14:16', 'kardex', 'INSERT', 'kdx_698e26881e9be', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #161\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:13:55\", \"uuid\": \"kdx_698e26881e9be\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('623', '2026-02-12 14:15:44', 'ventas_cabecera', 'INSERT', '3ae27612-0847-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 14:15:23\", \"total\": 1610.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"3ae27612-0847-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('624', '2026-02-12 14:15:44', 'kardex', 'INSERT', 'kdx_698e26e0d8a8d', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -4.0000, \"referencia\": \"VENTA #162\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:15:23\", \"uuid\": \"kdx_698e26e0d8a8d\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('625', '2026-02-12 14:15:44', 'kardex', 'INSERT', 'kdx_698e26e0d95b8', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #162\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:15:23\", \"uuid\": \"kdx_698e26e0d95b8\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('626', '2026-02-12 14:15:44', 'kardex', 'INSERT', 'kdx_698e26e0da0c1', '{\"id_producto\": \"660009\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #162\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:15:23\", \"uuid\": \"kdx_698e26e0da0c1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('627', '2026-02-12 14:15:44', 'kardex', 'INSERT', 'kdx_698e26e0dabc1', '{\"id_producto\": \"660090\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #162\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:15:23\", \"uuid\": \"kdx_698e26e0dabc1\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('628', '2026-02-12 14:15:44', 'kardex', 'INSERT', 'kdx_698e26e0db5e0', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #162\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:15:23\", \"uuid\": \"kdx_698e26e0db5e0\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('629', '2026-02-12 14:17:23', 'ventas_cabecera', 'INSERT', '75756e33-0847-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 14:17:02\", \"total\": 1890.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"75756e33-0847-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('630', '2026-02-12 14:17:23', 'kardex', 'INSERT', 'kdx_698e274325bbe', '{\"id_producto\": \"660030\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"VENTA #163\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:17:02\", \"uuid\": \"kdx_698e274325bbe\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('631', '2026-02-12 14:17:23', 'kardex', 'INSERT', 'kdx_698e274326543', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #163\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:17:02\", \"uuid\": \"kdx_698e274326543\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('632', '2026-02-12 14:17:23', 'kardex', 'INSERT', 'kdx_698e274326d9c', '{\"id_producto\": \"660002\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"VENTA #163\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:17:02\", \"uuid\": \"kdx_698e274326d9c\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('633', '2026-02-12 14:17:23', 'kardex', 'INSERT', 'kdx_698e274327607', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #163\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:17:02\", \"uuid\": \"kdx_698e274327607\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('634', '2026-02-12 14:17:23', 'kardex', 'INSERT', 'kdx_698e274327e83', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"VENTA #163\", \"costo_unitario\": 0.00, \"fecha\": \"2026-02-12 14:17:02\", \"uuid\": \"kdx_698e274327e83\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('651', '2026-02-12 20:27:11', 'ventas_cabecera', 'INSERT', '1eaf8e29-087b-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 20:06:16\", \"total\": 2160.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"1eaf8e29-087b-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('652', '2026-02-12 20:27:11', 'kardex', 'INSERT', '1eb00e51-087b-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"440002\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"Venta #180 (Sistema)\", \"costo_unitario\": 200.00, \"fecha\": \"2026-02-12 20:27:11\", \"uuid\": \"1eb00e51-087b-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('653', '2026-02-12 20:27:11', 'ventas_cabecera', 'INSERT', '1ec893e1-087b-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 20:10:52\", \"total\": 240.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"1ec893e1-087b-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('654', '2026-02-12 20:27:11', 'kardex', 'INSERT', '1ec962b8-087b-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"440002\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #181 (Sistema)\", \"costo_unitario\": 200.00, \"fecha\": \"2026-02-12 20:27:11\", \"uuid\": \"1ec962b8-087b-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('655', '2026-02-12 20:27:11', 'ventas_cabecera', 'INSERT', '1edb8ef1-087b-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-12 20:15:52\", \"total\": 650.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Consumidor Final\", \"uuid\": \"1edb8ef1-087b-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('656', '2026-02-12 20:27:11', 'kardex', 'INSERT', '1edc243c-087b-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660020\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #182 (Sistema)\", \"costo_unitario\": 570.00, \"fecha\": \"2026-02-12 20:27:11\", \"uuid\": \"1edc243c-087b-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('657', '2026-02-13 00:28:11', 'ventas_cabecera', 'INSERT', 'c990808e-089c-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-13 00:28:11\", \"total\": 40.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"c990808e-089c-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('658', '2026-02-13 00:28:11', 'kardex', 'INSERT', 'c9911611-089c-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #183 (Sistema)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-13 00:28:11\", \"uuid\": \"c9911611-089c-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('660', '2026-02-13 02:00:37', 'ventas_cabecera', 'INSERT', 'b3077dd2-08a9-11f1-b0a7-0affd1a0dee5', '{\"fecha\": \"2026-02-13 02:00:36\", \"total\": 40.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"b3077dd2-08a9-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('661', '2026-02-13 02:00:37', 'kardex', 'INSERT', 'b30814fb-08a9-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #185 (Sistema)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-13 02:00:37\", \"uuid\": \"b30814fb-08a9-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('663', '2026-02-13 02:17:33', 'kardex', 'INSERT', '109006c7-08ac-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"Anulación Venta #185\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-13 02:17:33\", \"uuid\": \"109006c7-08ac-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('664', '2026-02-13 02:17:41', 'kardex', 'INSERT', '156dce58-08ac-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"Devolución Venta #183\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-13 02:17:41\", \"uuid\": \"156dce58-08ac-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('665', '2026-02-13 08:54:54', 'kardex', 'INSERT', '92ebb6bf-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"440002\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"AJUSTE_POSITIVO\", \"cantidad\": 10.0000, \"referencia\": \"Corrección de stock negativo (a 0) - Ajuste Sistema (Corrección Saldos Negativos)\", \"costo_unitario\": 200.00, \"fecha\": \"2026-02-13 08:54:54\", \"uuid\": \"92ebb6bf-08e3-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('666', '2026-02-13 08:54:54', 'kardex', 'INSERT', '92ec0e8c-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660020\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"AJUSTE_POSITIVO\", \"cantidad\": 1.0000, \"referencia\": \"Corrección de stock negativo (a 0) - Ajuste Sistema (Corrección Saldos Negativos)\", \"costo_unitario\": 570.00, \"fecha\": \"2026-02-13 08:54:54\", \"uuid\": \"92ec0e8c-08e3-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('667', '2026-02-13 08:54:54', 'kardex', 'INSERT', '92eda544-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 1, \"id_sucursal\": 1, \"tipo_movimiento\": \"AJUSTE_POSITIVO\", \"cantidad\": 2.0000, \"referencia\": \"Corrección de stock negativo (a 0) - Ajuste Sistema (Corrección Saldos Negativos)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-13 08:54:54\", \"uuid\": \"92eda544-08e3-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('668', '2026-02-13 08:57:47', 'kardex', 'INSERT', 'fa696955-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #154 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-08 13:26:07\", \"uuid\": \"fa696955-08e3-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('669', '2026-02-13 08:57:47', 'kardex', 'INSERT', 'fa6a319b-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #183 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-11 00:28:11\", \"uuid\": \"fa6a319b-08e3-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('670', '2026-02-13 08:57:47', 'kardex', 'INSERT', 'fa6aed33-08e3-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #185 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-11 02:00:36\", \"uuid\": \"fa6aed33-08e3-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('671', '2026-02-13 08:58:10', 'kardex', 'INSERT', '07fab79d-08e4-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #154 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-08 13:26:07\", \"uuid\": \"07fab79d-08e4-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('672', '2026-02-13 08:58:10', 'kardex', 'INSERT', '07fb88f5-08e4-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"Venta #183 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-11 00:28:11\", \"uuid\": \"07fb88f5-08e4-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('673', '2026-02-13 08:58:10', 'kardex', 'INSERT', '07fc5f7a-08e4-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"DEVOLUCION\", \"cantidad\": 1.0000, \"referencia\": \"Venta #185 (Efectivo)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-11 02:00:36\", \"uuid\": \"07fc5f7a-08e4-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('675', '2026-02-13 12:37:38', 'productos', 'UPDATE', '54e225f1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991118\", \"nombre\": \"Aceite\", \"costo\": 1.20, \"precio\": 1.80, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e225f1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('676', '2026-02-13 12:40:11', 'kardex', 'INSERT', '0c15af0d-0903-11f1-b0a7-0affd1a0dee5', '{\"id_producto\": \"991118\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": 1000.0000, \"referencia\": \"ajuste manual\", \"costo_unitario\": 1.20, \"fecha\": \"2026-02-13 12:40:11\", \"uuid\": \"0c15af0d-0903-11f1-b0a7-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('677', '2026-02-14 19:27:35', 'productos', 'UPDATE', '54e2112e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841446\", \"nombre\": \"COCA COLA GRANDE\", \"costo\": 120.00, \"precio\": 150.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e2112e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('678', '2026-02-14 19:27:36', 'productos', 'UPDATE', '54e211be-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"756058841453\", \"nombre\": \"Refresco de naranja\", \"costo\": 210.00, \"precio\": 240.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e211be-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('679', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21d30-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991101\", \"nombre\": \"Azucar Blanca\", \"costo\": 0.58, \"precio\": 0.65, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21d30-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('680', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21dbe-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991102\", \"nombre\": \"azucar prieta\", \"costo\": 0.61, \"precio\": 0.65, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21dbe-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('681', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21e50-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991103\", \"nombre\": \"Harina trigo\", \"costo\": 0.50, \"precio\": 0.60, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21e50-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('682', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21ed8-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991104\", \"nombre\": \"leche en polvo\", \"costo\": 1.50, \"precio\": 1.65, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21ed8-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('683', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21f5d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991105\", \"nombre\": \"maicena\", \"costo\": 1.20, \"precio\": 1.20, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21f5d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('684', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e21fe2-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991106\", \"nombre\": \"polvo hornear\", \"costo\": 1.80, \"precio\": 2.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e21fe2-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('685', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22064-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991107\", \"nombre\": \"levadura\", \"costo\": 2.40, \"precio\": 2.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22064-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('686', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e220e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991108\", \"nombre\": \"guayaba en barra\", \"costo\": 0.85, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e220e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('687', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22169-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991109\", \"nombre\": \"canela en polvo\", \"costo\": 2.50, \"precio\": 3.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22169-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('688', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e221eb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991110\", \"nombre\": \"Bicarbonato\", \"costo\": 3.60, \"precio\": 4.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e221eb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('689', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2226d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991111\", \"nombre\": \"mejorador de pan\", \"costo\": 1.80, \"precio\": 2.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2226d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('690', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e222ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991112\", \"nombre\": \"CMC\", \"costo\": 5.00, \"precio\": 8.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e222ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('691', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2236e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991113\", \"nombre\": \"Emulsionante redolmy\", \"costo\": 4.15, \"precio\": 4.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2236e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('692', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e223ef-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991114\", \"nombre\": \"sazon en sobre\", \"costo\": 45.00, \"precio\": 70.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e223ef-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('693', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2246c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991115\", \"nombre\": \"pastillita de sabor\", \"costo\": 25.00, \"precio\": 50.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2246c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('694', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e224ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991116\", \"nombre\": \"yema huevo\", \"costo\": 50.00, \"precio\": 55.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e224ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('695', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2256c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991117\", \"nombre\": \"clara huevo\", \"costo\": 50.00, \"precio\": 55.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2256c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('696', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22672-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991119\", \"nombre\": \"Sal comun\", \"costo\": 0.12, \"precio\": 0.15, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22672-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('697', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e226ef-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991120\", \"nombre\": \"Vainilla liquida\", \"costo\": 2.00, \"precio\": 2.20, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e226ef-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('698', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22770-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991121\", \"nombre\": \"Pan Rayado\", \"costo\": 0.43, \"precio\": 0.60, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22770-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('699', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e227ec-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991122\", \"nombre\": \"chapilla chocolate oscuro\", \"costo\": 3.50, \"precio\": 3.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e227ec-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('700', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2286c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991123\", \"nombre\": \"Gelatina fresa\", \"costo\": 5.00, \"precio\": 6.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2286c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('701', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e228eb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991124\", \"nombre\": \"pasta de ajo\", \"costo\": 0.40, \"precio\": 0.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e228eb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('702', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22968-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991125\", \"nombre\": \"Pasta verde cebollino\", \"costo\": 0.27, \"precio\": 0.29, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22968-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('703', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e229e5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991126\", \"nombre\": \"mostaza\", \"costo\": 2.50, \"precio\": 2.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e229e5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('704', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22a63-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991127\", \"nombre\": \"mostaza agranel\", \"costo\": 2.50, \"precio\": 2.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22a63-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('705', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22ae3-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991128\", \"nombre\": \"semifrio de kiwi\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22ae3-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('706', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22b67-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991129\", \"nombre\": \"Mousse limon\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22b67-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('707', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e22d84-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991130\", \"nombre\": \"Mouse Chocolate\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e22d84-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('708', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2481e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991131\", \"nombre\": \"semifrio choco\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2481e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('709', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e24ac1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991132\", \"nombre\": \"Mouse de fresa\", \"costo\": 1.50, \"precio\": 1.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e24ac1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('710', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e24c94-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991133\", \"nombre\": \"Crema Pastelera\", \"costo\": 2.00, \"precio\": 2.20, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e24c94-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('711', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e24e33-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991134\", \"nombre\": \"Grenatina\", \"costo\": 4.60, \"precio\": 5.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e24e33-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('712', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e24fcc-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991135\", \"nombre\": \"cocoa pura\", \"costo\": 1.00, \"precio\": 1.20, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e24fcc-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('713', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e25137-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991136\", \"nombre\": \"gragea de colores\", \"costo\": 2.90, \"precio\": 3.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e25137-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('714', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e252d4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991137\", \"nombre\": \"grageas de chocolate\", \"costo\": 2.90, \"precio\": 3.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e252d4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('715', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e25472-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991138\", \"nombre\": \"Natilla de coco\", \"costo\": 0.50, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e25472-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('716', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2573d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991139\", \"nombre\": \"margarina\", \"costo\": 2.60, \"precio\": 3.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2573d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('717', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2590f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991140\", \"nombre\": \"Natilla de Chocolate\", \"costo\": 0.64, \"precio\": 0.80, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2590f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('718', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e25aad-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991141\", \"nombre\": \"Natilla de Fresa\", \"costo\": 0.43, \"precio\": 0.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e25aad-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('719', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e25c4d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991142\", \"nombre\": \"Natilla de Limon\", \"costo\": 0.43, \"precio\": 0.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e25c4d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('720', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e25dea-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991143\", \"nombre\": \"Natilla de Fanguito\", \"costo\": 0.50, \"precio\": 0.60, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e25dea-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('721', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e2601e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991144\", \"nombre\": \"Fanguito\", \"costo\": 1.25, \"precio\": 1.20, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2601e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('722', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e26b9a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991151\", \"nombre\": \"Azucar de Vainilla\", \"costo\": 0.80, \"precio\": 0.90, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e26b9a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('723', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e26ed8-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991153\", \"nombre\": \"jugo de limon\", \"costo\": 0.25, \"precio\": 0.30, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e26ed8-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('724', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e27073-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991154\", \"nombre\": \"Ron o alcohol\", \"costo\": 0.20, \"precio\": 0.25, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e27073-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('725', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e27209-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991155\", \"nombre\": \"vinagre\", \"costo\": 0.35, \"precio\": 0.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e27209-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('726', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e273a0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991156\", \"nombre\": \"natilla guayaba\", \"costo\": 0.37, \"precio\": 0.40, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e273a0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('727', '2026-02-14 19:28:39', 'productos', 'UPDATE', '54e27b5f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991157\", \"nombre\": \"Colorante amarillo polvo\", \"costo\": 35.00, \"precio\": 38.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e27b5f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('728', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e27d5f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991158\", \"nombre\": \"Almibar (1:1)\", \"costo\": 0.41, \"precio\": 0.50, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e27d5f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('729', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e27f03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991159\", \"nombre\": \"Colorante ENCO 40g\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e27f03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('730', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e280a1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991160\", \"nombre\": \"Colorante ENCO 20g\", \"costo\": 55.00, \"precio\": 60.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e280a1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('731', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2823c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991161\", \"nombre\": \"Colorante Cheffmaster 20g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2823c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('732', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2840a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991162\", \"nombre\": \"Colorante Tinta negra\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2840a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('733', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2856f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991163\", \"nombre\": \"Colorante Tinta rosada\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2856f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('734', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e28706-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991164\", \"nombre\": \"Colorante Tinta namarilla\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e28706-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('735', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2889d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991165\", \"nombre\": \"Colorante Soft Gel (MIX) 25g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2889d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('736', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e28a03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991166\", \"nombre\": \"Colorante OTELSA azul\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e28a03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('737', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e28b99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991167\", \"nombre\": \"Colorante OTELSA rojo\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e28b99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('738', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e28d2e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991168\", \"nombre\": \"Colorante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e28d2e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('739', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e28ecb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991169\", \"nombre\": \"Colorante agranel\", \"costo\": 30.00, \"precio\": 35.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e28ecb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('740', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e291ff-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991171\", \"nombre\": \"Emulsionante supernortemul\", \"costo\": 7.00, \"precio\": 8.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e291ff-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('741', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e29367-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991172\", \"nombre\": \"Saborizante Carolesen 60 ml\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e29367-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('742', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e29502-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991173\", \"nombre\": \"Saborizante Carolesen Tutifruti 510 ml\", \"costo\": 35.00, \"precio\": 38.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e29502-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('743', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2969d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991174\", \"nombre\": \"Saborizante Loran 118 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2969d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('744', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e29833-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991175\", \"nombre\": \"Saborizante La Anita 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e29833-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('745', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e299c5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991176\", \"nombre\": \"Saborizante ENCO 120 ml\", \"costo\": 21.00, \"precio\": 22.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e299c5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('746', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e29b28-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991177\", \"nombre\": \"Saborizante ENCO 60 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e29b28-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('747', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2a346-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991178\", \"nombre\": \"Saborizante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2a346-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('748', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2a521-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991179\", \"nombre\": \"Saborizante Flor d Arancio\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2a521-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('749', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991180\", \"nombre\": \"Saborizante Lorsnn Tutifruti\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('750', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2a816-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991181\", \"nombre\": \"Saborizante DUCHE mangp 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2a816-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('751', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991182\", \"nombre\": \"Saborizante DEIMPIN guanabana 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('752', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2ab49-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991183\", \"nombre\": \"Saborizante Esencia 3,7ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2ab49-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('753', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2acdc-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991184\", \"nombre\": \"Saborizantes agranel\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2acdc-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('754', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2ae75-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991185\", \"nombre\": \"Tartaletas (base)\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2ae75-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('755', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2afde-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991186\", \"nombre\": \"Nata\", \"costo\": 2.20, \"precio\": 2.60, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2afde-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('756', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2b175-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991187\", \"nombre\": \"Leche condensada\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2b175-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('757', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2b30b-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991188\", \"nombre\": \"Refresco polvo Mayar\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"BEBIDAS\", \"activo\": 1, \"uuid\": \"54e2b30b-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('758', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2b49f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991189\", \"nombre\": \"Mantequilla de mani\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2b49f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('759', '2026-02-14 19:32:49', 'productos', 'UPDATE', '54e2b604-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991190\", \"nombre\": \"Coco deshidratado\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"VARIOS\", \"activo\": 1, \"uuid\": \"54e2b604-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('760', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e27d5f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991158\", \"nombre\": \"Almibar (1:1)\", \"costo\": 0.41, \"precio\": 0.50, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e27d5f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('761', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e27f03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991159\", \"nombre\": \"Colorante ENCO 40g\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e27f03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('762', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e280a1-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991160\", \"nombre\": \"Colorante ENCO 20g\", \"costo\": 55.00, \"precio\": 60.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e280a1-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('763', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2823c-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991161\", \"nombre\": \"Colorante Cheffmaster 20g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2823c-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('764', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2840a-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991162\", \"nombre\": \"Colorante Tinta negra\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2840a-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('765', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2856f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991163\", \"nombre\": \"Colorante Tinta rosada\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2856f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('766', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e28706-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991164\", \"nombre\": \"Colorante Tinta namarilla\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e28706-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('767', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2889d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991165\", \"nombre\": \"Colorante Soft Gel (MIX) 25g\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2889d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('768', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e28a03-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991166\", \"nombre\": \"Colorante OTELSA azul\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e28a03-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('769', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e28b99-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991167\", \"nombre\": \"Colorante OTELSA rojo\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e28b99-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('770', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e28d2e-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991168\", \"nombre\": \"Colorante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e28d2e-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('771', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e28ecb-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991169\", \"nombre\": \"Colorante agranel\", \"costo\": 30.00, \"precio\": 35.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e28ecb-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('772', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e291ff-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991171\", \"nombre\": \"Emulsionante supernortemul\", \"costo\": 7.00, \"precio\": 8.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e291ff-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('773', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e29367-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991172\", \"nombre\": \"Saborizante Carolesen 60 ml\", \"costo\": 37.00, \"precio\": 40.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e29367-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('774', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e29502-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991173\", \"nombre\": \"Saborizante Carolesen Tutifruti 510 ml\", \"costo\": 35.00, \"precio\": 38.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e29502-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('775', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2969d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991174\", \"nombre\": \"Saborizante Loran 118 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2969d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('776', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e29833-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991175\", \"nombre\": \"Saborizante La Anita 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e29833-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('777', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e299c5-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991176\", \"nombre\": \"Saborizante ENCO 120 ml\", \"costo\": 21.00, \"precio\": 22.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e299c5-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('778', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e29b28-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991177\", \"nombre\": \"Saborizante ENCO 60 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e29b28-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('779', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2a346-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991178\", \"nombre\": \"Saborizante Star Chemical\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2a346-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('780', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2a521-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991179\", \"nombre\": \"Saborizante Flor d Arancio\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2a521-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('781', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991180\", \"nombre\": \"Saborizante Lorsnn Tutifruti\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2a6b4-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('782', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2a816-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991181\", \"nombre\": \"Saborizante DUCHE mangp 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2a816-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('783', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991182\", \"nombre\": \"Saborizante DEIMPIN guanabana 120 ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2a9b0-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('784', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2ab49-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991183\", \"nombre\": \"Saborizante Esencia 3,7ml\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2ab49-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('785', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2acdc-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991184\", \"nombre\": \"Saborizantes agranel\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2acdc-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('786', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2ae75-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991185\", \"nombre\": \"Tartaletas (base)\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2ae75-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('787', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2afde-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991186\", \"nombre\": \"Nata\", \"costo\": 2.20, \"precio\": 2.60, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2afde-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('788', '2026-02-14 19:33:39', 'productos', 'UPDATE', '54e2b604-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"991190\", \"nombre\": \"Coco deshidratado\", \"costo\": 2.00, \"precio\": 1.00, \"categoria\": \"INSUMOS\", \"activo\": 1, \"uuid\": \"54e2b604-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('789', '2026-02-15 09:26:53', 'ventas_cabecera', 'INSERT', '5f8d5eeb-0a7a-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 09:26:53\", \"total\": 835.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"5f8d5eeb-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('790', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8dc616-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660027\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 162.57, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8dc616-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('791', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8e3364-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 8.00, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8e3364-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('792', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8e8a26-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660035\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 15.00, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8e8a26-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('793', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8ed792-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8ed792-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('794', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8f2922-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660100\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 40.00, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8f2922-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('795', '2026-02-15 09:26:53', 'kardex', 'INSERT', '5f8f72e1-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #187 (Eddy)\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-11 09:26:53\", \"uuid\": \"5f8f72e1-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('796', '2026-02-15 09:29:48', 'ventas_cabecera', 'INSERT', 'c821f989-0a7a-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 09:29:48\", \"total\": 760.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"c821f989-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('797', '2026-02-15 09:29:48', 'kardex', 'INSERT', 'c82246c7-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -7.0000, \"referencia\": \"Venta #188 (Eddy)\", \"costo_unitario\": 20.00, \"fecha\": \"2026-02-11 09:29:48\", \"uuid\": \"c82246c7-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('798', '2026-02-15 09:29:48', 'kardex', 'INSERT', 'c82298d4-0a7a-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"881108\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #188 (Eddy)\", \"costo_unitario\": 292.71, \"fecha\": \"2026-02-11 09:29:48\", \"uuid\": \"c82298d4-0a7a-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('799', '2026-02-15 09:31:38', 'ventas_cabecera', 'INSERT', '097395bd-0a7b-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 09:31:38\", \"total\": 1050.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"097395bd-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('800', '2026-02-15 09:31:38', 'kardex', 'INSERT', '0973e2bd-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"Venta #189 (Eddy)\", \"costo_unitario\": 217.00, \"fecha\": \"2026-02-11 09:31:38\", \"uuid\": \"0973e2bd-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('801', '2026-02-15 09:31:38', 'kardex', 'INSERT', '09743142-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #189 (Eddy)\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-11 09:31:38\", \"uuid\": \"09743142-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('802', '2026-02-15 09:32:11', 'ventas_cabecera', 'INSERT', '1d6bb75e-0a7b-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 09:32:11\", \"total\": 250.00, \"metodo_pago\": \"Transferencia\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"1d6bb75e-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('803', '2026-02-15 09:32:11', 'kardex', 'INSERT', '1d6c1697-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #190 (Eddy)\", \"costo_unitario\": 217.00, \"fecha\": \"2026-02-11 09:32:11\", \"uuid\": \"1d6c1697-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('804', '2026-02-15 09:35:34', 'ventas_cabecera', 'INSERT', '9622dd11-0a7b-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 09:35:34\", \"total\": 2660.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"9622dd11-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('805', '2026-02-15 09:35:34', 'kardex', 'INSERT', '962333ac-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"Venta #191 (Eddy)\", \"costo_unitario\": 217.00, \"fecha\": \"2026-02-11 09:35:34\", \"uuid\": \"962333ac-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('806', '2026-02-15 09:35:34', 'kardex', 'INSERT', '96238492-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #191 (Eddy)\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-11 09:35:34\", \"uuid\": \"96238492-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('807', '2026-02-15 09:35:34', 'kardex', 'INSERT', '9623d6bd-0a7b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"Venta #191 (Eddy)\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-11 09:35:34\", \"uuid\": \"9623d6bd-0a7b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('808', '2026-02-15 09:40:12', 'productos', 'UPDATE', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660012\", \"nombre\": \"Tartaleta\", \"costo\": 60.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f50f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('809', '2026-02-15 09:40:12', 'kardex', 'INSERT', '3c4914cf-0a7c-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 20.0000, \"referencia\": \"COMPRA #31 (f122)\", \"costo_unitario\": 60.00, \"fecha\": \"2026-02-11 09:40:12\", \"uuid\": \"3c4914cf-0a7c-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('810', '2026-02-15 09:40:12', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('811', '2026-02-15 09:40:12', 'kardex', 'INSERT', '3c498fbf-0a7c-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 10.0000, \"referencia\": \"COMPRA #31 (f122)\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-11 09:40:12\", \"uuid\": \"3c498fbf-0a7c-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('812', '2026-02-15 12:01:22', 'ventas_cabecera', 'INSERT', 'f4696375-0a8f-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 12:01:22\", \"total\": 1200.00, \"metodo_pago\": \"Mixto\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"f4696375-0a8f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('813', '2026-02-15 12:01:22', 'kardex', 'INSERT', 'f469c3a4-0a8f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -8.0000, \"referencia\": \"Venta #192 (Eddy)\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-11 12:01:22\", \"uuid\": \"f469c3a4-0a8f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('814', '2026-02-15 12:25:44', 'ventas_cabecera', 'INSERT', '5c3b8eeb-0a93-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 12:25:44\", \"total\": 520.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"5c3b8eeb-0a93-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('815', '2026-02-15 12:25:44', 'kardex', 'INSERT', '5c3bead2-0a93-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #193 (Eddy)\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-11 12:25:44\", \"uuid\": \"5c3bead2-0a93-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('816', '2026-02-15 12:46:49', 'ventas_cabecera', 'INSERT', '4e106448-0a96-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-11 12:46:49\", \"total\": 1800.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"4e106448-0a96-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('817', '2026-02-15 12:46:49', 'kardex', 'INSERT', '4e10b188-0a96-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -18.0000, \"referencia\": \"Venta #194 (Eddy)\", \"costo_unitario\": 60.00, \"fecha\": \"2026-02-11 12:46:49\", \"uuid\": \"4e10b188-0a96-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('818', '2026-02-15 12:53:14', 'kardex', 'INSERT', '33b3005a-0a97-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660101\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": 6.0000, \"referencia\": \"error anterior\\r\\n\", \"costo_unitario\": 25.00, \"fecha\": \"2026-02-15 12:53:14\", \"uuid\": \"33b3005a-0a97-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('819', '2026-02-15 13:12:42', 'ventas_cabecera', 'INSERT', 'ebb98b48-0a99-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:12:42\", \"total\": 4035.00, \"metodo_pago\": \"Mixto\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"ebb98b48-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('820', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebb9f247-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 35.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebb9f247-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('821', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebba4224-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440002\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -8.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 200.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebba4224-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('822', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbb3c43-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660029\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -3.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 8.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbb3c43-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('823', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbc3530-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660009\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 120.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbc3530-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('824', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbc9842-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660088\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 18.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbc9842-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('825', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbd052c-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660100\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 40.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbd052c-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('826', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbe3f75-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660103\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbe3f75-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('827', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbe8d7a-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660006\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 212.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbe8d7a-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('828', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbf90a1-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660007\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -5.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 20.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbf90a1-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('829', '2026-02-15 13:12:42', 'kardex', 'INSERT', 'ebbfdf79-0a99-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660021\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #195 (Eddy)\", \"costo_unitario\": 217.00, \"fecha\": \"2026-02-12 13:12:42\", \"uuid\": \"ebbfdf79-0a99-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('830', '2026-02-15 13:25:02', 'productos', 'UPDATE', '54e1f697-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660015\", \"nombre\": \"Hamgurgesa 5u pqt\", \"costo\": 300.00, \"precio\": 500.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f697-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('831', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a5064206-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 11.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 300.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a5064206-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('832', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e20629-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660043\", \"nombre\": \"Minicake 18cm\", \"costo\": 700.00, \"precio\": 1500.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e20629-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('833', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a50784ab-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660043\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 700.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a50784ab-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('834', '2026-02-15 13:25:03', 'productos', 'INSERT', 'a5080f58-0a9b-11f1-9614-0affd1a0dee5', '{\"codigo\": \"440003\", \"nombre\": \"minicake 2000\", \"costo\": 1100.00, \"precio\": 2000.00, \"categoria\": \"DULCES\", \"activo\": 1, \"es_elaborado\": 1, \"es_servicio\": 0, \"id_empresa\": 1, \"uuid\": \"a5080f58-0a9b-11f1-9614-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('835', '2026-02-15 13:25:03', 'productos', 'UPDATE', 'a5080f58-0a9b-11f1-9614-0affd1a0dee5', '{\"codigo\": \"440003\", \"nombre\": \"minicake 2000\", \"costo\": 1100.00, \"precio\": 2000.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"a5080f58-0a9b-11f1-9614-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('836', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a509baa4-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440003\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 1100.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a509baa4-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('837', '2026-02-15 13:25:03', 'productos', 'UPDATE', 'ed40cff0-043e-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"440001\", \"nombre\": \"Donas Grandes\", \"costo\": 90.00, \"precio\": 140.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"ed40cff0-043e-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('838', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a50afabe-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 6.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a50afabe-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('839', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1f796-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660017\", \"nombre\": \"Croquetas pollo pqt\", \"costo\": 88.00, \"precio\": 150.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f796-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('840', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a50c1706-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 8.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a50c1706-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('841', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1fe58-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660031\", \"nombre\": \"Croquetas Buffet\", \"costo\": 82.00, \"precio\": 160.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1fe58-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('842', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a50e07b7-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660031\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 82.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a50e07b7-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('843', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1f60d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660014\", \"nombre\": \"Albondigas pqt\", \"costo\": 220.00, \"precio\": 370.00, \"categoria\": \"CARNICOS\", \"activo\": 1, \"uuid\": \"54e1f60d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('844', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a50fe993-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660014\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 6.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 220.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a50fe993-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('845', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660026\", \"nombre\": \"Fanguito\", \"costo\": 430.00, \"precio\": 580.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fbf7-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('846', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a511478e-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a511478e-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('847', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660025\", \"nombre\": \"Leche condensada\", \"costo\": 430.00, \"precio\": 520.00, \"categoria\": \"BODEGON\", \"activo\": 1, \"uuid\": \"54e1fb7d-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('848', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a511ad2e-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660025\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 1.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a511ad2e-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('849', '2026-02-15 13:25:03', 'productos', 'UPDATE', '54e1f50f-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660012\", \"nombre\": \"Tartaleta\", \"costo\": 60.00, \"precio\": 100.00, \"categoria\": \"DULCES\", \"activo\": 1, \"uuid\": \"54e1f50f-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('850', '2026-02-15 13:25:03', 'kardex', 'INSERT', 'a512389c-0a9b-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 2.0000, \"referencia\": \"COMPRA #32\", \"costo_unitario\": 60.00, \"fecha\": \"2026-02-15 13:25:02\", \"uuid\": \"a512389c-0a9b-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('851', '2026-02-15 13:27:54', 'productos', 'INSERT', '0b866fed-0a9c-11f1-9614-0affd1a0dee5', '{\"codigo\": \"440004\", \"nombre\": \"Whiskey\", \"costo\": 1250.00, \"precio\": 1600.00, \"categoria\": \"BEBIDAS_A\", \"activo\": 1, \"es_elaborado\": 1, \"es_servicio\": 0, \"id_empresa\": 1, \"uuid\": \"0b866fed-0a9c-11f1-9614-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('852', '2026-02-15 13:34:54', 'kardex', 'INSERT', '05c60eb4-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": -1.0000, \"referencia\": \"error\", \"costo_unitario\": 300.00, \"fecha\": \"2026-02-15 13:34:54\", \"uuid\": \"05c60eb4-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('853', '2026-02-15 13:36:27', 'kardex', 'INSERT', '3ccc3ed7-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": -8.0000, \"referencia\": \"error\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-15 13:36:27\", \"uuid\": \"3ccc3ed7-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('854', '2026-02-15 13:38:34', 'productos', 'INSERT', '8898456b-0a9d-11f1-9614-0affd1a0dee5', '{\"codigo\": \"440005\", \"nombre\": \"shaka\", \"costo\": 500.00, \"precio\": 600.00, \"categoria\": \"BEBIDAS_A\", \"activo\": 1, \"es_elaborado\": 1, \"es_servicio\": 0, \"id_empresa\": 1, \"uuid\": \"8898456b-0a9d-11f1-9614-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('855', '2026-02-15 13:38:34', 'productos', 'UPDATE', '8898456b-0a9d-11f1-9614-0affd1a0dee5', '{\"codigo\": \"440005\", \"nombre\": \"shaka\", \"costo\": 500.00, \"precio\": 600.00, \"categoria\": \"BEBIDAS_A\", \"activo\": 1, \"uuid\": \"8898456b-0a9d-11f1-9614-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('856', '2026-02-15 13:38:34', 'kardex', 'INSERT', '88989cf7-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440005\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 2.0000, \"referencia\": \"COMPRA #34\", \"costo_unitario\": 500.00, \"fecha\": \"2026-02-12 13:38:34\", \"uuid\": \"88989cf7-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('857', '2026-02-15 13:38:34', 'productos', 'UPDATE', '54e1f412-01f4-11f1-b0a7-0affd1a0dee5', '{\"codigo\": \"660010\", \"nombre\": \"Galletas Blackout azul\", \"costo\": 130.00, \"precio\": 150.00, \"categoria\": \"CONFITURAS\", \"activo\": 1, \"uuid\": \"54e1f412-01f4-11f1-b0a7-0affd1a0dee5\"}', '1', '0');
INSERT INTO `sync_journal` VALUES ('858', '2026-02-15 13:38:34', 'kardex', 'INSERT', '88990c5d-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"ENTRADA\", \"cantidad\": 10.0000, \"referencia\": \"COMPRA #34\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-12 13:38:34\", \"uuid\": \"88990c5d-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('859', '2026-02-15 13:39:43', 'ventas_cabecera', 'INSERT', 'b1d9198f-0a9d-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-12 13:39:43\", \"total\": 5270.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"b1d9198f-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('860', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1d96c63-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660015\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 300.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1d96c63-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('861', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1d9b403-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440003\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 1100.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1d9b403-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('862', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1da02e9-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"440001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 90.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1da02e9-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('863', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1da48aa-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660017\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -9.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 88.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1da48aa-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('864', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1da9539-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660026\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 430.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1da9539-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('865', '2026-02-15 13:39:43', 'kardex', 'INSERT', 'b1dad96b-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #196 (Eddy)\", \"costo_unitario\": 60.00, \"fecha\": \"2026-02-12 13:39:43\", \"uuid\": \"b1dad96b-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('866', '2026-02-15 13:40:51', 'kardex', 'INSERT', 'da4d302d-0a9d-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660012\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": -2.0000, \"referencia\": \"por error de entrada\", \"costo_unitario\": 60.00, \"fecha\": \"2026-02-15 13:40:51\", \"uuid\": \"da4d302d-0a9d-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('867', '2026-02-15 13:51:21', 'ventas_cabecera', 'INSERT', '51af3353-0a9f-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-13 13:51:21\", \"total\": 70.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"51af3353-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('868', '2026-02-15 13:51:21', 'kardex', 'INSERT', '51b00b17-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #197 (Eddy)\", \"costo_unitario\": 35.00, \"fecha\": \"2026-02-13 13:51:21\", \"uuid\": \"51b00b17-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('869', '2026-02-15 13:51:47', 'kardex', 'INSERT', '611f57c6-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660001\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": 1.0000, \"referencia\": \"entarda\\r\\n\", \"costo_unitario\": 35.00, \"fecha\": \"2026-02-15 13:51:47\", \"uuid\": \"611f57c6-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('870', '2026-02-15 13:52:01', 'kardex', 'INSERT', '69ddd740-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660033\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": -1.0000, \"referencia\": \"me lo pago extra.por error\", \"costo_unitario\": 20.00, \"fecha\": \"2026-02-15 13:52:01\", \"uuid\": \"69ddd740-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('871', '2026-02-15 13:53:05', 'kardex', 'INSERT', '8fef1a48-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660018\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"AJUSTE_INTERNO\", \"cantidad\": -1.0000, \"referencia\": \"la pago extra\", \"costo_unitario\": 580.00, \"fecha\": \"2026-02-15 13:53:05\", \"uuid\": \"8fef1a48-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('872', '2026-02-15 13:53:22', 'ventas_cabecera', 'INSERT', '99efa1ad-0a9f-11f1-9614-0affd1a0dee5', '{\"fecha\": \"2026-02-13 13:53:22\", \"total\": 1630.00, \"metodo_pago\": \"Efectivo\", \"id_cliente\": 0, \"id_sucursal\": 4, \"cliente_nombre\": \"Mostrador\", \"uuid\": \"99efa1ad-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('873', '2026-02-15 13:53:22', 'kardex', 'INSERT', '99eff495-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660010\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -2.0000, \"referencia\": \"Venta #198 (Eddy)\", \"costo_unitario\": 130.00, \"fecha\": \"2026-02-13 13:53:22\", \"uuid\": \"99eff495-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('874', '2026-02-15 13:53:22', 'kardex', 'INSERT', '99f0d732-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660020\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #198 (Eddy)\", \"costo_unitario\": 570.00, \"fecha\": \"2026-02-13 13:53:22\", \"uuid\": \"99f0d732-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');
INSERT INTO `sync_journal` VALUES ('875', '2026-02-15 13:53:22', 'kardex', 'INSERT', '99f12895-0a9f-11f1-9614-0affd1a0dee5', '{\"id_producto\": \"660018\", \"id_almacen\": 4, \"id_sucursal\": 4, \"tipo_movimiento\": \"VENTA\", \"cantidad\": -1.0000, \"referencia\": \"Venta #198 (Eddy)\", \"costo_unitario\": 580.00, \"fecha\": \"2026-02-13 13:53:22\", \"uuid\": \"99f12895-0a9f-11f1-9614-0affd1a0dee5\"}', '4', '0');

DROP TABLE IF EXISTS `transferencias_cabecera`;
CREATE TABLE `transferencias_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid_transf` varchar(64) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_almacen_origen` int(11) NOT NULL,
  `id_almacen_destino` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` varchar(20) DEFAULT 'COMPLETADO',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uuid_transf` (`uuid_transf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `transferencias_detalle`;
CREATE TABLE `transferencias_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_transf_cabecera` int(11) NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `id_producto` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_transf_cabecera` (`id_transf_cabecera`),
  CONSTRAINT `fk_transf_cabecera` FOREIGN KEY (`id_transf_cabecera`) REFERENCES `transferencias_cabecera` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pin` varchar(10) NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'cajero',
  `id_sucursal` int(10) unsigned NOT NULL DEFAULT 1,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1', 'Eddy', NULL, '$2y$10$s1ouoXt52nGLvMkkOlFzse73g4wweySnnbWLg0flYV6hkyqLMmTfi', '4321', 'cajero', '4', '1', NULL, '2026-02-10 14:13:19', '2026-02-10 14:13:19');
INSERT INTO `users` VALUES ('2', 'roly', NULL, '$2y$10$s1ouoXt52nGLvMkkOlFzse73g4wweySnnbWLg0flYV6hkyqLMmTfi', '2233', 'cajero', '2', '1', NULL, '2026-02-10 14:13:19', '2026-02-10 14:13:19');
INSERT INTO `users` VALUES ('3', 'yoel', NULL, '$2y$10$s1ouoXt52nGLvMkkOlFzse73g4wweySnnbWLg0flYV6hkyqLMmTfi', '0000', 'admin', '2', '1', NULL, '2026-02-10 14:13:19', '2026-02-10 14:13:19');
INSERT INTO `users` VALUES ('4', 'admin', NULL, '$2y$10$s1ouoXt52nGLvMkkOlFzse73g4wweySnnbWLg0flYV6hkyqLMmTfi', '0000', 'admin', '4', '1', NULL, '2026-02-10 14:13:19', '2026-02-10 14:13:19');

DROP TABLE IF EXISTS `usuarios_clientes`;
CREATE TABLE `usuarios_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT current_timestamp(),
  `activo` tinyint(4) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telefono` (`telefono`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `ventas_cabecera`;
CREATE TABLE `ventas_cabecera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid_venta` varchar(64) NOT NULL,
  `fecha` datetime NOT NULL,
  `total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `metodo_pago` varchar(50) DEFAULT 'Efectivo',
  `precio_tipo` varchar(20) DEFAULT 'normal',
  `descuento_orden` decimal(5,2) DEFAULT 0.00,
  `id_sucursal` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `id_empresa` int(11) NOT NULL DEFAULT 1,
  `id_almacen` int(11) DEFAULT NULL,
  `id_caja` int(11) DEFAULT 1,
  `tipo_servicio` varchar(50) DEFAULT 'consumir_aqui',
  `fecha_reserva` datetime DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `cliente_nombre` varchar(100) DEFAULT 'Mostrador',
  `cliente_direccion` varchar(255) DEFAULT NULL,
  `cliente_telefono` varchar(50) DEFAULT NULL,
  `mensajero_nombre` varchar(100) DEFAULT NULL,
  `abono_reserva` decimal(10,2) DEFAULT 0.00,
  `id_sesion_caja` int(11) DEFAULT 0,
  `abono` decimal(10,2) DEFAULT 0.00,
  `estado_reserva` varchar(20) DEFAULT 'PENDIENTE',
  `uuid` char(36) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT 0,
  `sincronizado` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uuid_venta` (`uuid_venta`),
  UNIQUE KEY `idx_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ventas_cabecera` VALUES ('1', 'd15204da-77f2-4b3c-bb77-ec8a3548ca4b', '2026-01-23 22:57:36', '2280.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-29 22:57:36', '1', '4', '1', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '1', '0.00', 'PENDIENTE', '54ea96ad-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('2', '8713ae35-461f-48dc-b4b0-f759cd0affc2', '2026-01-23 22:59:43', '5010.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 22:59:43', '1', '4', '1', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '1', '0.00', 'PENDIENTE', '54ea9a3b-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('3', '1e42bbc3-780b-42f4-be8c-7b0868f8fdd9', '2026-01-24 23:04:03', '3160.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:04:03', '1', '4', '2', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '2', '0.00', 'PENDIENTE', '54ea9af2-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('4', '33bffd61-2650-4981-8afe-62738333af5d', '2026-01-24 23:04:11', '70.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-29 23:04:11', '1', '4', '2', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '2', '0.00', 'PENDIENTE', '54ea9b81-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('5', '0f2ecc02-3038-4a1b-a046-e116d113d415', '2026-01-24 23:06:02', '4475.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:06:02', '1', '4', '2', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '2', '0.00', 'PENDIENTE', '54ea9c0d-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('6', 'ref_697c2e8df35fb', '2026-01-24 23:07:41', '-600.00', 'Devolución', 'normal', '0.00', '4', '2026-01-29 23:07:41', '1', '4', '2', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '2', '0.00', 'PENDIENTE', '54ea9c96-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('7', '88c54cd5-8a86-4622-adf2-4dd9233c9d99', '2026-01-24 23:07:59', '840.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:07:59', '1', '4', '2', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '2', '0.00', 'PENDIENTE', '54ea9d33-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('8', 'c10dd738-8ed7-4626-b582-daaff5b71070', '2026-01-24 23:08:54', '800.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:08:54', '1', '4', '2', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '2', '0.00', 'PENDIENTE', '54ea9dbd-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('9', 'a3d0b2ba-84cc-48ea-a393-c50db170ec9b', '2026-01-25 23:16:39', '4090.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-29 23:16:39', '1', '4', '3', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '3', '0.00', 'PENDIENTE', '54ea9e41-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('10', '559adfe7-00f9-469e-a25d-2a28f9e95e17', '2026-01-25 23:22:47', '10225.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:22:47', '1', '4', '3', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '3', '0.00', 'PENDIENTE', '54ea9ec8-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('11', 'ref_697c32b5d6868', '2026-01-25 23:25:25', '-80.00', 'Devolución', 'normal', '0.00', '4', '2026-01-29 23:25:25', '1', '4', '3', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '3', '0.00', 'PENDIENTE', '54ea9f4a-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('12', '848e21fd-4e14-4549-a85b-f4b811a59eb0', '2026-01-26 23:30:43', '4210.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:30:43', '1', '4', '4', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '4', '0.00', 'PENDIENTE', '54ea9fd8-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('13', 'ba690b11-a9d3-49ef-9253-2d2ecdb34c6a', '2026-01-26 23:31:15', '1100.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:31:15', '1', '4', '4', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '4', '0.00', 'PENDIENTE', '54eaa060-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('14', '36342fe8-dc7d-4a95-94d7-75e457bf8a19', '2026-01-27 23:38:36', '1260.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-29 23:38:36', '1', '4', '5', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '5', '0.00', 'PENDIENTE', '54eaa0e2-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('15', '3b5ed7c9-4299-47c9-ac9d-4f335245ace1', '2026-01-27 23:43:34', '4855.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:43:34', '1', '4', '5', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '5', '0.00', 'PENDIENTE', '54eaa166-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('16', '8857aeb4-6d23-402c-a694-f805a6375f8a', '2026-01-28 23:50:41', '1000.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-29 23:50:41', '1', '4', '6', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '6', '0.00', 'PENDIENTE', '54eaa1ec-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('17', 'd9847b64-713e-4b29-9822-2233650e1603', '2026-01-28 23:51:49', '2020.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:51:49', '1', '4', '6', 'llevar', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '6', '0.00', 'PENDIENTE', '54eaa26c-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('18', 'cc834b53-292c-4923-9099-775e6d38b79e', '2026-01-28 23:53:01', '3235.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:53:01', '1', '4', '6', 'llevar', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '6', '0.00', 'PENDIENTE', '54eaa2f0-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('19', 'c790b30a-aad6-415b-8e48-9dd64d886853', '2026-01-28 23:53:25', '400.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-29 23:53:25', '1', '4', '6', 'llevar', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '6', '0.00', 'PENDIENTE', '54eaa376-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('20', '3350a593-3a66-420d-a204-f81943e4bead', '2026-01-12 10:23:36', '360.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-30 10:23:36', '1', '4', '9', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '9', '0.00', 'PENDIENTE', '54eaa3fd-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('21', 'c43d9e87-34f6-474d-a415-96c75781585f', '2026-01-12 10:24:26', '650.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-30 10:24:26', '1', '4', '9', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '9', '0.00', 'PENDIENTE', '54eaa47e-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('22', 'ref_697cd52827ea6', '2026-01-12 10:58:32', '-360.00', 'Devolución', 'normal', '0.00', '4', '2026-01-30 10:58:32', '1', '4', '9', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '9', '0.00', 'PENDIENTE', '54eaa4ff-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('23', 'ref_697cd52dc681a', '2026-01-12 10:58:37', '-650.00', 'Devolución', 'normal', '0.00', '4', '2026-01-30 10:58:37', '1', '4', '9', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '9', '0.00', 'PENDIENTE', '54eaa581-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('24', 'aa47e786-1ecc-4a49-b874-b1d0b992f10d', '2026-01-29 08:24:46', '2030.00', 'Transferencia', 'normal', '0.00', '4', '2026-01-31 08:24:46', '1', '4', '11', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '11', '0.00', 'PENDIENTE', '54eaa604-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('25', '21eb7668-3a07-4ebe-a80d-466608d9c4de', '2026-01-29 08:26:41', '3850.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-31 08:26:41', '1', '4', '11', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '11', '0.00', 'PENDIENTE', '54eaa685-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('26', '96a4d1ec-5fe9-4ea4-8060-ef1303ade089', '2026-01-29 09:02:12', '2980.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-31 09:02:12', '1', '4', '11', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '11', '0.00', 'PENDIENTE', '54eaa708-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('27', '81bb0a8f-7371-47c1-a1ac-e7a9b5de7325', '2026-01-29 09:05:09', '4080.00', 'Efectivo', 'normal', '0.00', '4', '2026-01-31 09:05:09', '1', '4', '11', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '11', '0.00', 'PENDIENTE', '54eaa78b-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('28', '3415c097-3477-455d-9060-cca6ea944420', '2026-01-30 20:41:34', '1830.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-01 20:41:34', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaa810-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('29', '77acc414-0fea-4b8a-8cb7-2a1c646eae54', '2026-01-30 20:54:53', '4400.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-01 20:54:53', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaa891-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('30', '14336593-fa54-416a-86cb-01385639480b', '2026-01-30 20:56:11', '240.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-01 20:56:11', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaa911-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('31', '1ca9cbfb-2668-42f2-b3f2-8150b6a49f97', '2026-01-30 21:33:07', '3550.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-01 21:33:07', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaa995-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('32', 'b73a02c7-e8bd-43bf-bbc8-f31d463d91f0', '2026-01-30 21:35:17', '3230.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-01 21:35:17', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaaa18-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('33', 'a9d484a1-6685-4d3c-8931-5f774567d861', '2026-01-30 21:38:39', '4440.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-01 21:38:39', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaaa82-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('34', 'e785d5bf-9c36-44b6-8d90-a732114bfc92', '2026-01-30 21:41:00', '15.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-01 21:41:00', '1', '4', '12', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '12', '0.00', 'PENDIENTE', '54eaaae7-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('35', '0cc7080b-202a-4662-a10b-70a05198de28', '2026-01-31 19:12:03', '2800.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-02 19:12:03', '1', '4', '13', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '13', '0.00', 'PENDIENTE', '54eaab4b-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('36', '8913d46b-9762-4eb1-a95f-948b6929614d', '2026-01-31 19:12:19', '400.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-02 19:12:19', '1', '4', '13', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '13', '0.00', 'PENDIENTE', '54eaabb2-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('37', '90abcc35-da66-4404-8395-b226b3b15131', '2026-01-31 19:25:31', '12250.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-02 19:25:31', '1', '4', '13', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '13', '0.00', 'PENDIENTE', '54eaac17-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('38', '17512f1c-6367-4db3-9483-e1398a2cf6ea', '2026-01-31 19:25:54', '320.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-02 19:25:54', '1', '4', '13', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '13', '0.00', 'PENDIENTE', '54eaac7a-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('39', 'f52f8800-8b33-49d1-bffc-77f8d6900b30', '2026-02-01 08:26:07', '3340.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 08:26:07', '1', '4', '14', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '14', '0.00', 'PENDIENTE', '54eaacdd-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('40', '15a08e2c-2ffc-4556-b45a-f8a9304a1612', '2026-02-01 08:40:54', '7840.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 08:40:54', '1', '4', '14', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '14', '0.00', 'PENDIENTE', '54eaad43-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('41', '891ff1cb-d641-4565-bdbc-35094ad958e0', '2026-02-02 09:40:34', '5440.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 09:40:34', '1', '4', '15', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '15', '0.00', 'PENDIENTE', '54eaada6-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('42', 'e0588d1a-d9d4-4d64-9feb-87093f7d6cab', '2026-02-03 10:40:12', '2180.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 10:40:12', '1', '4', '16', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '16', '0.00', 'PENDIENTE', '54eaae08-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('43', 'f33624f3-ecbb-42eb-bf12-0145f77d2c30', '2026-02-03 11:08:00', '1660.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 11:08:00', '1', '4', '16', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '16', '0.00', 'PENDIENTE', '54eaae6b-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('44', '6151bc0b-bf79-4bd5-9e34-70ff455e32a3', '2026-02-03 11:21:13', '140.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-04 11:21:13', '1', '4', '16', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '16', '0.00', 'PENDIENTE', '54eaaed4-01f4-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('70', '8bcb0cd7-814f-4e0e-8fa0-05c6843e3f8e', '2026-02-04 11:00:24', '80.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-06 11:00:24', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', 'f28d7f06-0374-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('71', '28a46d23-02bb-4760-be7c-57edb8525b4e', '2026-02-04 12:10:31', '560.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-06 12:10:31', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', 'be0ea5b4-037e-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('72', '3c53d996-439d-47f1-8945-cf4acc8012c2', '2026-02-04 16:02:51', '3520.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-06 16:02:51', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '32f56a19-039f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('73', 'f69bd680-8538-49d5-90d2-bbd03cd5fae5', '2026-02-04 16:02:51', '1920.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-06 16:02:51', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '3309cfa9-039f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('78', 'ref_698745dd80993', '2026-02-04 09:02:05', '-80.00', 'Devolución', 'normal', '0.00', '4', '2026-02-07 09:02:05', '1', '4', '17', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '17', '0.00', 'PENDIENTE', '959c2084-042d-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('79', 'ref_6987473641257', '2026-02-04 09:07:50', '-560.00', 'Devolución', 'normal', '0.00', '4', '2026-02-07 09:07:50', '1', '4', '17', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '17', '0.00', 'PENDIENTE', '63174dd3-042e-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('86', '15e90eba-ce45-42e4-83cf-6b0b6c191464', '2026-02-04 09:45:26', '3600.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:45:26', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', 'a41b0f7f-0433-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('87', 'c6d7cb6d-5236-4dbd-80bd-e9462dd19b78', '2026-02-04 09:46:06', '1040.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:46:06', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', 'bc079dfa-0433-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('88', 'c0987f91-af27-4c54-9917-9fb1e1ea94c2', '2026-02-04 09:47:06', '890.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:47:06', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', 'dfc2b907-0433-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('89', 'c698c1ad-44d2-421c-9eb1-03df4ff8ac84', '2026-02-04 09:49:29', '2670.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:49:29', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '34aa7e0a-0434-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('90', 'd819ca41-2dd6-4714-add5-2008b180b1c5', '2026-02-04 09:50:01', '1700.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:50:01', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '47abbfbb-0434-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('91', '7626f5d4-fcba-4f48-a080-b508d4c0e5a2', '2026-02-04 09:50:14', '1300.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:50:14', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '4f6b4d44-0434-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('92', '805cd0e7-db2d-4219-a39e-e75135a4d157', '2026-02-04 09:50:38', '60.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:50:38', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '5e28fe26-0434-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('93', '18f644b8-b5ab-4fad-91d8-210ff84a7adc', '2026-02-04 09:50:49', '80.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-07 09:50:49', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '64942fa3-0434-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('94', '99365e78-f149-4491-b51f-a13c078b253b', '2026-02-04 09:58:21', '600.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:58:21', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '721d6f66-0435-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('95', '2706a30a-c686-4065-b6c8-22ce4b5e02cf', '2026-02-04 09:58:59', '240.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:58:59', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '885624d6-0435-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('96', '5ac081a6-9bc3-4a3f-9018-8b6e7e8dc327', '2026-02-04 09:59:05', '80.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-07 09:59:05', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '8be25d2f-0435-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('97', 'c2f04d08-bd70-4e1c-9f4d-e047d3bd4d0a', '2026-02-04 09:59:26', '350.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:59:26', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '984f9989-0435-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('98', 'c33124a9-60b1-46e0-8670-264b250add96', '2026-02-04 09:59:36', '280.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 09:59:36', '1', '4', '17', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '17', '0.00', 'PENDIENTE', '9e7e9738-0435-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('99', '11c0bf2e-f5e7-41ef-adf0-c8cd28e514f5', '2026-02-05 10:18:53', '180.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:18:53', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', '503a854a-0438-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('100', 'c2494d1d-2efc-4379-98dd-2506fb26528e', '2026-02-05 10:19:40', '1000.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-07 10:19:40', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', '6c5cfdca-0438-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('101', '6abec1b5-cf30-4f8b-9903-364afbefa4ee', '2026-02-05 10:20:45', '240.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:20:45', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', '930d47d6-0438-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('102', 'a9c57b44-d9c2-49f8-a862-ff62ffd85b5e', '2026-02-05 10:27:03', '2600.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:27:03', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', '742738fc-0439-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('103', 'ebbcb79c-007a-4520-a256-2175715a1bb9', '2026-02-05 10:28:05', '1970.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:28:05', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', '9910c1d3-0439-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('104', 'd259a362-5e94-4379-b2cf-9cee8c58d466', '2026-02-05 10:28:33', '30.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:28:33', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', 'aa15ba40-0439-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('105', '63baa656-ee0e-446a-a405-c9fdbbaced83', '2026-02-05 10:29:06', '1200.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 10:29:06', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', 'bd82d37b-0439-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('106', 'fd7ce5be-1efb-4893-a2a2-d75b7cae9be6', '2026-02-05 10:29:32', '30.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-07 10:29:32', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', 'cd070eae-0439-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('107', '103ec75b-9f0e-4cca-ab06-3b9491371aaa', '2026-02-05 11:11:52', '790.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 11:11:53', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', 'b7541584-043f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('108', 'dc72d799-44dc-4f50-9162-7e84009f20bc', '2026-02-05 11:12:27', '1040.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-07 11:12:27', '1', '4', '18', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '18', '0.00', 'PENDIENTE', 'cc096d3b-043f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('109', 'ec1df56a-1d1c-47ee-a578-a4f5699ae35b', '2026-02-06 09:03:42', '6590.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-08 09:03:42', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'f9d4d5b0-04f6-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('110', '52b195d7-ae82-44f8-8da6-cfc395cbfeee', '2026-02-06 09:08:19', '1470.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-08 09:08:19', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '9efb1281-04f7-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('111', 'c85ccbd1-2f1e-49e1-82d1-6bb551dc35cd', '2026-02-06 09:17:55', '680.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-08 09:17:55', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'f655d864-04f8-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('112', '0ccc5afc-f83a-4209-89f8-3cffcb45af6a', '2026-02-06 10:10:46', '270.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:10:46', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '58301406-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('113', '502b085c-face-47af-8a30-b8bbc221485d', '2026-02-06 10:11:16', '740.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:11:16', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '6a2e171c-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('114', 'd2bf011d-b768-4303-993d-80e00a5e9127', '2026-02-06 10:11:53', '960.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:11:53', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '804b921e-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('115', '2a8e2760-4468-4678-bb29-22cbfea7d5a7', '2026-02-06 10:12:44', '60.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:12:44', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '9e5d55ac-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('116', '2c5281a8-1401-46bd-8ac7-a07a38e85246', '2026-02-06 10:12:55', '1680.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:12:55', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'a5793897-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('117', '86e9a541-eb52-4620-bf9d-e5597c90d41a', '2026-02-06 10:13:22', '70.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:13:22', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'b5386000-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('118', '85ef2575-9a37-4637-8103-db649dfc23c2', '2026-02-06 10:13:53', '600.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:13:53', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'c7e00b4b-0500-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('119', 'eee7548b-c659-44b8-88c6-fef5c1e7691e', '2026-02-06 10:15:45', '2610.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 10:15:45', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', '0a5f6757-0501-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('120', 'ref_6988e7a2dcdbb', '2026-02-06 14:44:34', '-750.00', 'Devolución', 'normal', '0.00', '4', '2026-02-08 14:44:34', '1', '4', '19', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '19', '0.00', 'PENDIENTE', '98681c67-0526-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('121', '845fa625-9bb8-4d5b-8dfc-a8a5da3b3ee8', '2026-02-06 14:45:06', '600.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 14:45:06', '1', '4', '19', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '19', '0.00', 'PENDIENTE', 'ab8871cc-0526-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('122', 'ee085fb1-e7d0-4d3f-a13c-061dd9693ac2', '2026-02-07 14:50:34', '300.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-08 14:50:34', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '6e7ba845-0527-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('123', '7a32f0a0-32ab-4946-b06a-fd03a5328dc4', '2026-02-07 20:01:26', '4560.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-08 20:01:26', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', 'dc247b42-0552-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('124', '48acbb12-4c25-4301-9cef-c2f129b62f5b', '2026-02-07 20:02:33', '160.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-08 20:02:33', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '043a1c1a-0553-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('125', '5790bdc8-7379-49dc-a613-afa6c92346e8', '2026-02-07 10:58:42', '280.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-10 10:58:42', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '5f8aeed1-0699-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('126', 'a6b34837-ebba-45e9-b687-80cea2a1d1d7', '2026-02-07 11:00:46', '360.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:00:46', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', 'a9287be4-0699-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('127', '8557b1ab-b883-43f9-867b-bc053910ab2c', '2026-02-07 11:01:05', '560.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:01:05', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', 'b4c69bc8-0699-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('128', '70849d47-dea6-48ac-b791-4804d9c52999', '2026-02-07 11:02:38', '9070.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:02:38', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', 'ec2549ae-0699-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('129', '23a1532f-e410-4255-91d6-0385d78c9190', '2026-02-07 11:03:12', '650.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:03:12', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '0053e1c9-069a-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('130', 'ab583eae-b468-4164-b54b-c84c9f98f967', '2026-02-07 11:43:15', '2470.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:43:15', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '98ba87f2-069f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('131', 'a24869d5-252e-407c-8319-2cd6759745b9', '2026-02-07 11:47:51', '2550.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:47:51', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '3d4a53de-06a0-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('132', '6c183c47-5444-4ac6-86d7-9d2ff6879cb2', '2026-02-07 11:53:18', '160.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 11:53:18', '1', '4', '20', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '20', '0.00', 'PENDIENTE', '0047a973-06a1-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('133', '6320458c-2a74-467f-a3e4-208ddef03f71', '2026-02-08 12:12:38', '1220.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 12:12:38', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', 'b3a0dac9-06a3-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('134', 'f45f66f0-9e77-46b2-96cb-bf00c1478b95', '2026-02-08 12:14:14', '1890.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 12:14:14', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', 'ecc74ac6-06a3-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('135', '653d5d6c-521a-489c-b3cd-f5fb30db139f', '2026-02-08 12:15:38', '850.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 12:15:38', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '1ec85b39-06a4-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('136', 'cc1fa1ab-4ddc-4679-9d82-cea8500dcc8f', '2026-02-08 12:24:30', '5680.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 12:24:30', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '5bdd9c36-06a5-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('137', '41fbd60f-2b8b-40d5-b26f-3e243686045c', '2026-02-08 12:25:05', '1440.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-10 12:25:05', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '7098527c-06a5-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('138', 'V-698c936254e846.69134372', '2026-02-11 09:34:10', '0.00', 'prueba', 'normal', '0.00', '1', '2026-02-11 04:34:10', '1', '1', '22', 'Mesa', NULL, NULL, 'Mostrador', NULL, NULL, NULL, '0.00', '22', '0.00', 'PENDIENTE', '96d99b6f-67a3-433c-8c29-fedd0e50cddc', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('139', 'V-698cd7e5efd535.86715175', '2026-02-11 14:26:29', '150.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-11 09:26:29', '1', '4', '23', 'Delivery', NULL, NULL, 'Mostrador', NULL, NULL, NULL, '0.00', '23', '0.00', 'PENDIENTE', 'd4441ca4-ac7c-4838-8edd-44686746e38a', '1', '0');
INSERT INTO `ventas_cabecera` VALUES ('140', 'V-698d094611ffc5.48684973', '2026-02-11 17:57:10', '150.00', 'Mixto', 'normal', '0.00', '4', '2026-02-11 12:57:10', '1', '4', '23', 'Reserva', '2026-02-21 17:57:00', NULL, 'sureima chales', '522 East 12th Street', '7868082963', NULL, '0.00', '23', '25.00', 'PENDIENTE', '4b61b3b3-f5ce-41cd-8db8-e886bd708d7a', '1', '0');
INSERT INTO `ventas_cabecera` VALUES ('145', '50788b45-0ef0-4145-861f-69d033a30108', '2026-02-08 13:07:59', '500.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:09:57', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '0a36ba47-083e-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('146', 'ref_698e180b802e9', '2026-02-08 13:12:27', '-500.00', 'Devolución', 'normal', '0.00', '4', '2026-02-12 13:12:27', '1', '4', '21', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '0', '0.00', 'PENDIENTE', '637be7ec-083e-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('147', '6c690a02-dc88-482b-a4aa-2668e7013d37', '2026-02-08 13:13:59', '750.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:14:20', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', 'a6b525d5-083e-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('149', 'ref_698e1a10a4999', '2026-02-08 13:21:04', '-960.00', 'Devolución', 'normal', '0.00', '4', '2026-02-12 13:21:04', '1', '4', '21', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '0', '0.00', 'PENDIENTE', '97baa055-083f-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('150', '80eababc-a525-44c1-a65b-852820c38da3', '2026-02-08 13:21:15', '1000.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:21:36', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', 'aacbc675-083f-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('151', 'ref_698e1a941d4ab', '2026-02-08 13:23:16', '-480.00', 'Devolución', 'normal', '0.00', '4', '2026-02-12 13:23:16', '1', '4', '21', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '0', '0.00', 'PENDIENTE', 'e613a976-083f-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('152', 'ref_698e1ab4e45eb', '2026-02-08 13:23:48', '-480.00', 'Devolución', 'normal', '0.00', '4', '2026-02-12 13:23:48', '1', '4', '21', 'mostrador', NULL, NULL, 'DEVOLUCIÓN', NULL, NULL, NULL, '0.00', '0', '0.00', 'PENDIENTE', 'f9a2e288-083f-11f1-b0a7-0affd1a0dee5', '0', '0');
INSERT INTO `ventas_cabecera` VALUES ('153', 'c03bb52d-12bb-42bd-9023-0b14a77621aa', '2026-02-08 13:24:09', '500.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:24:30', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '1250f415-0840-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('154', 'fef90c55-4d14-4a3e-a425-022e74d2f200', '2026-02-08 13:26:07', '40.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:26:28', '1', '4', '21', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '21', '0.00', 'PENDIENTE', '58780d35-0840-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('155', 'd4ebd7c6-1d10-49cb-bb21-a966c1582ba4', '2026-02-09 13:53:40', '2800.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:54:01', '1', '4', '24', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '24', '0.00', 'PENDIENTE', '31c12861-0844-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('156', '7e2aca80-5e52-455a-8965-44b84e7357e5', '2026-02-09 13:55:05', '1775.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:55:26', '1', '4', '24', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '24', '0.00', 'PENDIENTE', '649681f7-0844-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('157', '9fd19fe7-bd7e-475a-9fb9-60373a5dc198', '2026-02-09 13:55:38', '240.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:55:59', '1', '4', '24', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '24', '0.00', 'PENDIENTE', '785942f7-0844-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('158', '68cc2dbb-cbfb-404f-a295-ec9f2d9333d3', '2026-02-09 13:56:15', '1450.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-12 13:56:36', '1', '4', '24', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '24', '0.00', 'PENDIENTE', '8e5d4143-0844-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('159', 'b63cc98e-0adb-4101-ac3d-dfb44db74b8b', '2026-02-09 13:58:55', '580.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 13:59:16', '1', '4', '24', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '24', '0.00', 'PENDIENTE', 'ed77856b-0844-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('160', '3db2fd88-7a8e-467b-a048-aa8a490739ee', '2026-02-10 14:12:49', '1750.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-12 14:13:10', '1', '4', '25', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '25', '0.00', 'PENDIENTE', 'df097089-0846-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('161', '791e7429-090d-40f3-a588-9f48eab62aa0', '2026-02-10 14:13:55', '3130.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 14:14:16', '1', '4', '25', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '25', '0.00', 'PENDIENTE', '05f9d146-0847-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('162', '1a5f7f66-b6bd-4b78-9ed1-fb5a4146469f', '2026-02-10 14:15:23', '1610.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 14:15:44', '1', '4', '25', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '25', '0.00', 'PENDIENTE', '3ae27612-0847-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('163', '857e1990-e1da-4c12-9b55-59a9139933c6', '2026-02-10 14:17:02', '1890.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 14:17:23', '1', '4', '25', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '25', '0.00', 'PENDIENTE', '75756e33-0847-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('180', 'bfb83a90-41c0-4e6f-831d-0bebfa60459f', '2026-02-11 20:06:16', '2160.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-12 20:27:11', '1', '4', '26', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '1eaf8e29-087b-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('181', '54fc1b4e-65f9-48b9-88d3-ba16835c68df', '2026-02-11 20:10:52', '240.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-12 20:27:11', '1', '4', '26', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '1ec893e1-087b-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('182', '0314ff64-4e30-4416-bc69-a4433693d01c', '2026-02-11 20:15:52', '650.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-12 20:27:11', '1', '4', '26', 'consumir_aqui', NULL, NULL, 'Consumidor Final', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '1edb8ef1-087b-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('183', 'd7a0cb42-b316-4e02-bfdb-ffdf8cc825f3', '2026-02-11 00:28:11', '0.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-13 00:28:11', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', 'c990808e-089c-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('185', '0126977b-bee5-4971-8199-f90baa0ce3ae', '2026-02-11 02:00:36', '40.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-13 02:00:37', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', 'b3077dd2-08a9-11f1-b0a7-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('187', 'aa0d6f90-2886-468e-8d06-641dc7ee40ce', '2026-02-11 09:26:53', '835.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 09:26:53', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '5f8d5eeb-0a7a-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('188', '810bf17f-3741-4931-a267-4a8d8fde7910', '2026-02-11 09:29:48', '760.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 09:29:48', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', 'c821f989-0a7a-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('189', '707bf108-602e-42ba-967c-86e2ca82d48a', '2026-02-11 09:31:38', '1050.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-15 09:31:38', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '097395bd-0a7b-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('190', '437cf392-3891-4d04-909b-0452628c02fd', '2026-02-11 09:32:11', '250.00', 'Transferencia', 'normal', '0.00', '4', '2026-02-15 09:32:11', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '1d6bb75e-0a7b-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('191', '69e4f91c-6620-4158-b3a9-e735c4d67b24', '2026-02-11 09:35:34', '2660.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 09:35:34', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '9622dd11-0a7b-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('192', 'ba49e914-9ade-4101-a3e5-f12e91c9d06e', '2026-02-11 12:01:22', '1200.00', 'Mixto', 'normal', '0.00', '4', '2026-02-15 12:01:22', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', 'f4696375-0a8f-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('193', 'fa8f572f-30fe-4381-a790-c6e2bec6b9bc', '2026-02-11 12:25:44', '520.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 12:25:44', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '5c3b8eeb-0a93-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('194', '666357c7-27d1-4259-93cd-6e9217a173e8', '2026-02-11 12:46:49', '1800.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 12:46:49', '1', '4', '26', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '26', '0.00', 'PENDIENTE', '4e106448-0a96-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('195', '2024cb2b-0317-434e-ad9f-945a72e97851', '2026-02-12 13:12:42', '4035.00', 'Mixto', 'normal', '0.00', '4', '2026-02-15 13:12:42', '1', '4', '28', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '28', '0.00', 'PENDIENTE', 'ebb98b48-0a99-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('196', '483f411c-ae3e-45d8-b366-d506bea0433e', '2026-02-12 13:39:43', '5270.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 13:39:43', '1', '4', '28', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '28', '0.00', 'PENDIENTE', 'b1d9198f-0a9d-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('197', '81286c01-fb25-4a38-afcc-162bcd6b3184', '2026-02-13 13:51:21', '70.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 13:51:21', '1', '4', '29', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '29', '0.00', 'PENDIENTE', '51af3353-0a9f-11f1-9614-0affd1a0dee5', '0', '1');
INSERT INTO `ventas_cabecera` VALUES ('198', 'cc0d5c78-6656-4c28-943d-a43b4dbddfce', '2026-02-13 13:53:22', '1630.00', 'Efectivo', 'normal', '0.00', '4', '2026-02-15 13:53:22', '1', '4', '29', 'mostrador', NULL, NULL, 'Mostrador', '', '', '', '0.00', '29', '0.00', 'PENDIENTE', '99efa1ad-0a9f-11f1-9614-0affd1a0dee5', '0', '1');

DROP TABLE IF EXISTS `ventas_detalle`;
CREATE TABLE `ventas_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_venta_cabecera` int(11) NOT NULL,
  `cantidad` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `precio` decimal(15,2) NOT NULL DEFAULT 0.00,
  `nombre_producto` text DEFAULT NULL,
  `codigo_producto` text DEFAULT NULL,
  `categoria_producto` text DEFAULT NULL,
  `descuento_pct` decimal(5,2) DEFAULT 0.00,
  `descuento_monto` decimal(10,2) DEFAULT 0.00,
  `reembolsado` tinyint(4) DEFAULT 0,
  `id_producto` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_detalle_cabecera` (`id_venta_cabecera`),
  KEY `idx_vta_prod` (`id_producto`),
  CONSTRAINT `fk_detalle_cabecera` FOREIGN KEY (`id_venta_cabecera`) REFERENCES `ventas_cabecera` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=464 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ventas_detalle` VALUES ('1', '1', '2.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('2', '1', '1.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('3', '1', '1.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('4', '1', '1.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660008');
INSERT INTO `ventas_detalle` VALUES ('5', '1', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('6', '1', '4.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('7', '1', '7.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('8', '1', '2.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('9', '2', '1.0000', '500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('10', '2', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('11', '2', '13.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('12', '2', '5.0000', '230.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660024');
INSERT INTO `ventas_detalle` VALUES ('13', '3', '2.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660003');
INSERT INTO `ventas_detalle` VALUES ('14', '3', '1.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('15', '3', '4.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('16', '3', '2.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('17', '3', '2.0000', '680.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660018');
INSERT INTO `ventas_detalle` VALUES ('18', '4', '1.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('19', '5', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('20', '5', '11.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('21', '5', '4.0000', '230.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660024');
INSERT INTO `ventas_detalle` VALUES ('22', '5', '6.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('23', '5', '5.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('24', '6', '-6.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('25', '7', '6.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660028');
INSERT INTO `ventas_detalle` VALUES ('26', '8', '8.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('27', '9', '3.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('28', '9', '1.0000', '150.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('29', '9', '4.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('30', '9', '1.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('31', '9', '2.0000', '680.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660018');
INSERT INTO `ventas_detalle` VALUES ('32', '9', '3.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('33', '10', '2.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('34', '10', '1.0000', '650.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('35', '10', '4.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('36', '10', '4.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('37', '10', '15.0000', '230.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660024');
INSERT INTO `ventas_detalle` VALUES ('38', '10', '1.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('39', '10', '2.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('40', '10', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('41', '10', '16.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('42', '10', '3.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('43', '11', '-1.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('44', '12', '2.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660008');
INSERT INTO `ventas_detalle` VALUES ('45', '12', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('46', '12', '2.0000', '80.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('47', '12', '2.0000', '720.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660016');
INSERT INTO `ventas_detalle` VALUES ('48', '12', '6.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('49', '12', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('50', '12', '6.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('51', '12', '4.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('52', '12', '2.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660030');
INSERT INTO `ventas_detalle` VALUES ('53', '12', '1.0000', '160.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660031');
INSERT INTO `ventas_detalle` VALUES ('54', '13', '11.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('55', '14', '2.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('56', '14', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660006');
INSERT INTO `ventas_detalle` VALUES ('57', '14', '1.0000', '160.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660031');
INSERT INTO `ventas_detalle` VALUES ('58', '14', '2.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('59', '15', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('60', '15', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('61', '15', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('62', '15', '1.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('63', '15', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('64', '15', '41.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('65', '15', '2.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('66', '15', '13.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('67', '15', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('68', '15', '2.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('69', '16', '10.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('70', '17', '3.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('71', '17', '1.0000', '150.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('72', '17', '2.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('73', '17', '2.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('74', '17', '2.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('75', '17', '1.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('76', '18', '5.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('77', '18', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660030');
INSERT INTO `ventas_detalle` VALUES ('78', '18', '12.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('79', '19', '2.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('80', '19', '4.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('81', '20', '1.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('82', '21', '1.0000', '650.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('83', '22', '-1.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('84', '23', '-1.0000', '650.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('85', '24', '1.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('86', '24', '4.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('87', '24', '1.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('88', '24', '5.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('89', '25', '1.0000', '650.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('90', '25', '6.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('91', '25', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('92', '25', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('93', '25', '1.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('94', '25', '1.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('95', '25', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('96', '25', '4.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('97', '26', '17.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('98', '26', '10.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660099');
INSERT INTO `ventas_detalle` VALUES ('99', '26', '1.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('100', '26', '1.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('101', '26', '3.0000', '30.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('102', '27', '9.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('103', '27', '8.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('104', '28', '1.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('105', '28', '2.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('106', '28', '4.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660002');
INSERT INTO `ventas_detalle` VALUES ('107', '28', '1.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('108', '28', '4.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('109', '29', '1.0000', '2900.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660098');
INSERT INTO `ventas_detalle` VALUES ('110', '29', '1.0000', '1500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660043');
INSERT INTO `ventas_detalle` VALUES ('111', '30', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('112', '31', '2.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('113', '31', '2.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('114', '31', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('115', '31', '1.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('116', '31', '41.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('117', '31', '10.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('118', '31', '3.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660099');
INSERT INTO `ventas_detalle` VALUES ('119', '32', '1.0000', '500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('120', '32', '7.0000', '230.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('121', '32', '1.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('122', '32', '10.0000', '30.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('123', '32', '2.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('124', '32', '3.0000', '120.00', NULL, NULL, NULL, '0.00', '0.00', '0', '756058841478');
INSERT INTO `ventas_detalle` VALUES ('125', '33', '1.0000', '400.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660004');
INSERT INTO `ventas_detalle` VALUES ('126', '33', '16.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('127', '33', '1.0000', '200.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660097');
INSERT INTO `ventas_detalle` VALUES ('128', '34', '1.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('129', '35', '1.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660002');
INSERT INTO `ventas_detalle` VALUES ('130', '35', '6.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('131', '35', '2.0000', '500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('132', '35', '3.0000', '200.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660097');
INSERT INTO `ventas_detalle` VALUES ('133', '35', '2.0000', '150.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('134', '35', '5.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('135', '36', '4.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660095');
INSERT INTO `ventas_detalle` VALUES ('136', '37', '2.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('137', '37', '1.0000', '70.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('138', '37', '2.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('139', '37', '10.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660022');
INSERT INTO `ventas_detalle` VALUES ('140', '37', '1.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('141', '37', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('142', '37', '5.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('143', '37', '2.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660099');
INSERT INTO `ventas_detalle` VALUES ('144', '37', '1.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('145', '37', '7.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('146', '37', '11.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('147', '37', '11.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '990091');
INSERT INTO `ventas_detalle` VALUES ('148', '37', '7.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('149', '37', '1.0000', '30.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('150', '37', '2.0000', '120.00', NULL, NULL, NULL, '0.00', '0.00', '0', '756058841478');
INSERT INTO `ventas_detalle` VALUES ('151', '38', '2.0000', '160.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660031');
INSERT INTO `ventas_detalle` VALUES ('152', '39', '2.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('153', '39', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('154', '39', '4.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '990091');
INSERT INTO `ventas_detalle` VALUES ('155', '39', '3.0000', '180.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('156', '39', '2.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('157', '40', '4.0000', '60.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('158', '40', '2.0000', '580.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('159', '40', '6.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('160', '40', '4.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('161', '40', '1.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660099');
INSERT INTO `ventas_detalle` VALUES ('162', '40', '1.0000', '500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('163', '40', '1.0000', '360.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('164', '40', '6.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('165', '40', '2.0000', '120.00', NULL, NULL, NULL, '0.00', '0.00', '0', '756058841478');
INSERT INTO `ventas_detalle` VALUES ('166', '40', '2.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660094');
INSERT INTO `ventas_detalle` VALUES ('167', '40', '7.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('168', '40', '1.0000', '1500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660043');
INSERT INTO `ventas_detalle` VALUES ('169', '40', '1.0000', '160.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('170', '41', '3.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('171', '41', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('172', '41', '2.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('173', '41', '1.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('174', '41', '6.0000', '15.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('175', '41', '29.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('176', '41', '3.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('177', '41', '1.0000', '280.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660093');
INSERT INTO `ventas_detalle` VALUES ('178', '41', '10.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('179', '41', '1.0000', '220.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660096');
INSERT INTO `ventas_detalle` VALUES ('180', '41', '1.0000', '1500.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660043');
INSERT INTO `ventas_detalle` VALUES ('181', '41', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('182', '42', '1.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('183', '42', '3.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('184', '42', '1.0000', '520.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('185', '42', '1.0000', '240.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('186', '42', '8.0000', '10.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('187', '42', '1.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('188', '42', '2.0000', '160.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660031');
INSERT INTO `ventas_detalle` VALUES ('189', '42', '4.0000', '30.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('190', '43', '9.0000', '100.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('191', '43', '1.0000', '720.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660016');
INSERT INTO `ventas_detalle` VALUES ('192', '43', '1.0000', '40.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('193', '44', '1.0000', '140.00', NULL, NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('219', '70', '2.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('220', '71', '2.0000', '280.00', 'Energizante', '660011', NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('221', '72', '2.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('222', '72', '2.0000', '280.00', 'Energizante', '660011', NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('223', '72', '2.0000', '240.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('224', '72', '10.0000', '240.00', 'Cerveza La Fria', '660037', NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('225', '73', '8.0000', '240.00', 'Cerveza Presidente', '990091', NULL, '0.00', '0.00', '0', '990091');
INSERT INTO `ventas_detalle` VALUES ('230', '78', '-2.0000', '40.00', 'DEVOLUCIÓN: Chupa chus 40', NULL, NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('231', '79', '-2.0000', '280.00', 'DEVOLUCIÓN: Energizante', NULL, NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('238', '86', '9.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('239', '86', '8.0000', '180.00', 'jugo cajita 200ml', '660036', NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('240', '87', '2.0000', '520.00', 'Leche condensada', '660025', NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('241', '88', '1.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('242', '88', '1.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('243', '89', '20.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('244', '89', '2.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('245', '89', '2.0000', '360.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('246', '89', '1.0000', '150.00', 'Galletas Rellenitas', '660009', NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('247', '89', '1.0000', '280.00', 'Pqt de 4 panques', '660093', NULL, '0.00', '0.00', '0', '660093');
INSERT INTO `ventas_detalle` VALUES ('248', '89', '2.0000', '160.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('249', '90', '17.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('250', '91', '1.0000', '1300.00', 'lomo en bandeja 1lb', '660090', NULL, '0.00', '0.00', '0', '660090');
INSERT INTO `ventas_detalle` VALUES ('251', '92', '2.0000', '30.00', 'Caldo de pollo sobrecito', '660088', NULL, '0.00', '0.00', '0', '660088');
INSERT INTO `ventas_detalle` VALUES ('252', '93', '2.0000', '40.00', 'pastillita pollo con tomate', '660089', NULL, '0.00', '0.00', '0', '660089');
INSERT INTO `ventas_detalle` VALUES ('253', '94', '3.0000', '200.00', 'Galletas Saltitacos', '660087', NULL, '0.00', '0.00', '0', '660087');
INSERT INTO `ventas_detalle` VALUES ('254', '95', '3.0000', '80.00', 'ojitos gummy gum', '660100', NULL, '0.00', '0.00', '0', '660100');
INSERT INTO `ventas_detalle` VALUES ('255', '96', '2.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('256', '97', '1.0000', '200.00', 'Jabon de carbon', '660102', NULL, '0.00', '0.00', '0', '660102');
INSERT INTO `ventas_detalle` VALUES ('257', '97', '1.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('258', '98', '1.0000', '280.00', 'Espagetis 500g', '660006', NULL, '0.00', '0.00', '0', '660006');
INSERT INTO `ventas_detalle` VALUES ('259', '99', '2.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('260', '99', '1.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('261', '100', '1.0000', '280.00', 'Energizante', '660011', NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('262', '100', '2.0000', '240.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('263', '100', '1.0000', '240.00', 'Cerveza La Fria', '660037', NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('264', '101', '1.0000', '240.00', 'Cerveza Presidente', '990091', NULL, '0.00', '0.00', '0', '990091');
INSERT INTO `ventas_detalle` VALUES ('265', '102', '1.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('266', '102', '6.0000', '180.00', 'jugo cajita 200ml', '660036', NULL, '0.00', '0.00', '0', '660036');
INSERT INTO `ventas_detalle` VALUES ('267', '102', '2.0000', '520.00', 'Leche condensada', '660025', NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('268', '102', '4.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('269', '103', '4.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('270', '103', '5.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('271', '103', '3.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('272', '103', '1.0000', '360.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('273', '104', '1.0000', '30.00', 'chicle 30', '660035', NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('274', '105', '12.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('275', '106', '1.0000', '30.00', 'Caldo de pollo sobrecito', '660088', NULL, '0.00', '0.00', '0', '660088');
INSERT INTO `ventas_detalle` VALUES ('276', '107', '1.0000', '200.00', 'Galletas Saltitacos', '660087', NULL, '0.00', '0.00', '0', '660087');
INSERT INTO `ventas_detalle` VALUES ('277', '107', '1.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('278', '107', '11.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('279', '108', '8.0000', '130.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('280', '109', '6.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('281', '109', '1.0000', '680.00', 'Azucar 1kg pqt', '660018', NULL, '0.00', '0.00', '0', '660018');
INSERT INTO `ventas_detalle` VALUES ('282', '109', '5.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('283', '109', '1.0000', '150.00', 'Galletas Rellenitas', '660009', NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('284', '109', '2.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('285', '109', '3.0000', '80.00', 'ojitos gummy gum', '660100', NULL, '0.00', '0.00', '0', '660100');
INSERT INTO `ventas_detalle` VALUES ('286', '109', '1.0000', '1300.00', 'lomo en bandeja 1lb', '660090', NULL, '0.00', '0.00', '0', '660090');
INSERT INTO `ventas_detalle` VALUES ('287', '110', '4.0000', '80.00', 'Cabezote', '660013', NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('288', '110', '10.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('289', '110', '1.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('290', '111', '16.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('291', '111', '1.0000', '440.00', 'Pure de tomate 400g lata', '660003', NULL, '0.00', '0.00', '0', '660003');
INSERT INTO `ventas_detalle` VALUES ('292', '112', '1.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('293', '112', '5.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('294', '113', '1.0000', '180.00', 'Galleta Biskiato minion', '660008', NULL, '0.00', '0.00', '0', '660008');
INSERT INTO `ventas_detalle` VALUES ('295', '113', '2.0000', '280.00', 'Energizante', '660011', NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('296', '114', '4.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('297', '115', '1.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('298', '116', '7.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('299', '117', '7.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('300', '118', '3.0000', '200.00', 'Galletas Saltitacos', '660087', NULL, '0.00', '0.00', '0', '660087');
INSERT INTO `ventas_detalle` VALUES ('301', '119', '1.0000', '160.00', 'Donas Donuts', '660104', NULL, '0.00', '0.00', '0', '660104');
INSERT INTO `ventas_detalle` VALUES ('302', '119', '3.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('303', '119', '4.0000', '130.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('304', '119', '1.0000', '360.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('305', '119', '5.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('306', '119', '7.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('307', '120', '-5.0000', '150.00', 'DEVOLUCIÓN: Croquetas pollo pqt', NULL, NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('308', '121', '4.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('309', '122', '2.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('310', '122', '4.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('311', '123', '3.0000', '580.00', 'Fanguito', '660026', NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('312', '123', '4.0000', '230.00', 'Cerveza Esple', '660032', NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('313', '123', '1.0000', '520.00', 'Leche condensada', '660025', NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('314', '123', '10.0000', '80.00', 'Cabezote', '660013', NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('315', '123', '1.0000', '220.00', 'pqt torticas 6u', '660096', NULL, '0.00', '0.00', '0', '660096');
INSERT INTO `ventas_detalle` VALUES ('316', '123', '1.0000', '360.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('317', '124', '1.0000', '160.00', 'Croquetas Buffet', '660031', NULL, '0.00', '0.00', '0', '660031');
INSERT INTO `ventas_detalle` VALUES ('318', '125', '1.0000', '280.00', 'Espagetis 500g', '660006', NULL, '0.00', '0.00', '0', '660006');
INSERT INTO `ventas_detalle` VALUES ('319', '126', '2.0000', '180.00', 'Galletas Porleo', '660005', NULL, '0.00', '0.00', '0', '660005');
INSERT INTO `ventas_detalle` VALUES ('320', '127', '2.0000', '280.00', 'Energizante', '660011', NULL, '0.00', '0.00', '0', '660011');
INSERT INTO `ventas_detalle` VALUES ('321', '128', '9.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('322', '128', '5.0000', '230.00', 'Cerveza Esple', '660032', NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('323', '128', '24.0000', '240.00', 'Cerveza La Fria', '660037', NULL, '0.00', '0.00', '0', '660037');
INSERT INTO `ventas_detalle` VALUES ('324', '129', '1.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('325', '130', '1.0000', '680.00', 'Azucar 1kg pqt', '660018', NULL, '0.00', '0.00', '0', '660018');
INSERT INTO `ventas_detalle` VALUES ('326', '130', '1.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('327', '130', '6.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('328', '130', '29.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('329', '131', '1.0000', '220.00', 'pqt torticas 6u', '660096', NULL, '0.00', '0.00', '0', '660096');
INSERT INTO `ventas_detalle` VALUES ('330', '131', '14.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('331', '131', '2.0000', '360.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('332', '131', '7.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('333', '132', '1.0000', '160.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('334', '133', '4.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('335', '133', '4.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('336', '133', '1.0000', '180.00', 'Galletas Porleo', '660005', NULL, '0.00', '0.00', '0', '660005');
INSERT INTO `ventas_detalle` VALUES ('337', '133', '2.0000', '80.00', 'Cabezote', '660013', NULL, '0.00', '0.00', '0', '660013');
INSERT INTO `ventas_detalle` VALUES ('338', '133', '23.0000', '10.00', 'Caramelos 10', '660034', NULL, '0.00', '0.00', '0', '660034');
INSERT INTO `ventas_detalle` VALUES ('339', '133', '14.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('340', '134', '2.0000', '30.00', 'chicle 30', '660035', NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('341', '134', '1.0000', '220.00', 'pqt torticas 6u', '660096', NULL, '0.00', '0.00', '0', '660096');
INSERT INTO `ventas_detalle` VALUES ('342', '134', '2.0000', '730.00', 'Higado de pollo pqt', '660016', NULL, '0.00', '0.00', '0', '660016');
INSERT INTO `ventas_detalle` VALUES ('343', '134', '1.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('344', '135', '1.0000', '370.00', 'Albondigas pqt', '660014', NULL, '0.00', '0.00', '0', '660014');
INSERT INTO `ventas_detalle` VALUES ('345', '135', '1.0000', '480.00', 'Hamburguesas pollo', '881108', NULL, '0.00', '0.00', '0', '881108');
INSERT INTO `ventas_detalle` VALUES ('346', '136', '1.0000', '160.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('347', '136', '23.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('348', '137', '4.0000', '240.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('349', '137', '1.0000', '480.00', 'Hamburguesas pollo', '881108', NULL, '0.00', '0.00', '0', '881108');
INSERT INTO `ventas_detalle` VALUES ('350', '138', '2.0000', '120.00', '', '756058841446', '', '0.00', '0.00', '0', '756058841446');
INSERT INTO `ventas_detalle` VALUES ('351', '139', '1.0000', '150.00', 'COCA COLA GRANDE', '756058841446', '', '0.00', '0.00', '0', '756058841446');
INSERT INTO `ventas_detalle` VALUES ('352', '140', '1.0000', '150.00', 'COCA COLA GRANDE', '756058841446', '', '0.00', '0.00', '0', '756058841446');
INSERT INTO `ventas_detalle` VALUES ('357', '145', '1.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('358', '146', '-1.0000', '500.00', 'DEVOLUCIÓN: Hamgurgesa 5u pqt', NULL, NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('359', '147', '5.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('361', '149', '-4.0000', '240.00', 'DEVOLUCIÓN: Refresco cola lata 300ml', NULL, NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('362', '150', '4.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('363', '151', '-1.0000', '480.00', 'DEVOLUCIÓN: Hamburguesas pollo', NULL, NULL, '0.00', '0.00', '0', '881108');
INSERT INTO `ventas_detalle` VALUES ('364', '152', '-1.0000', '480.00', 'DEVOLUCIÓN: Hamburguesas pollo', NULL, NULL, '0.00', '0.00', '0', '881108');
INSERT INTO `ventas_detalle` VALUES ('365', '153', '1.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('366', '154', '1.0000', '40.00', 'Cafe en sobre', '660101', NULL, '0.00', '0.00', '0', '660101');
INSERT INTO `ventas_detalle` VALUES ('367', '155', '2.0000', '40.00', 'Chupa chus 40', '660033', NULL, '0.00', '0.00', '0', '660033');
INSERT INTO `ventas_detalle` VALUES ('368', '155', '4.0000', '150.00', 'Galletas Porleo', '660005', NULL, '0.00', '0.00', '0', '660005');
INSERT INTO `ventas_detalle` VALUES ('369', '155', '2.0000', '230.00', 'Cerveza Esple', '660032', NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('370', '155', '1.0000', '240.00', 'Cerveza Shekels', '660023', NULL, '0.00', '0.00', '0', '660023');
INSERT INTO `ventas_detalle` VALUES ('371', '155', '2.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('372', '155', '2.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('373', '156', '1.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('374', '156', '9.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('375', '156', '1.0000', '30.00', 'chicle 30', '660035', NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('376', '156', '2.0000', '220.00', 'pqt torticas 6u', '660096', NULL, '0.00', '0.00', '0', '660096');
INSERT INTO `ventas_detalle` VALUES ('377', '156', '3.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('378', '156', '3.0000', '160.00', 'Donas Donuts', '660104', NULL, '0.00', '0.00', '0', '660104');
INSERT INTO `ventas_detalle` VALUES ('379', '157', '6.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('380', '158', '3.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('381', '158', '1.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('382', '158', '2.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('383', '159', '1.0000', '280.00', 'San jacobo', '660030', NULL, '0.00', '0.00', '0', '660030');
INSERT INTO `ventas_detalle` VALUES ('384', '159', '2.0000', '150.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('385', '160', '1.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('386', '160', '2.0000', '40.00', 'pastillita pollo con tomate', '660089', NULL, '0.00', '0.00', '0', '660089');
INSERT INTO `ventas_detalle` VALUES ('387', '160', '1.0000', '230.00', 'Cerveza Esple', '660032', NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('388', '160', '1.0000', '240.00', 'Cerveza star lager', '440002', NULL, '0.00', '0.00', '0', '440002');
INSERT INTO `ventas_detalle` VALUES ('389', '160', '5.0000', '140.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('390', '161', '5.0000', '230.00', 'Cerveza Esple', '660032', NULL, '0.00', '0.00', '0', '660032');
INSERT INTO `ventas_detalle` VALUES ('391', '161', '5.0000', '240.00', 'Cerveza star lager', '440002', NULL, '0.00', '0.00', '0', '440002');
INSERT INTO `ventas_detalle` VALUES ('392', '161', '5.0000', '60.00', 'Pinguinos gelatina', '660019', NULL, '0.00', '0.00', '0', '660019');
INSERT INTO `ventas_detalle` VALUES ('393', '161', '2.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('394', '162', '4.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('395', '162', '2.0000', '30.00', 'chicle 30', '660035', NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('396', '162', '1.0000', '150.00', 'Galletas Rellenitas', '660009', NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('397', '162', '1.0000', '1300.00', 'lomo en bandeja 1lb', '660090', NULL, '0.00', '0.00', '0', '660090');
INSERT INTO `ventas_detalle` VALUES ('398', '162', '1.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('399', '163', '3.0000', '280.00', 'San jacobo', '660030', NULL, '0.00', '0.00', '0', '660030');
INSERT INTO `ventas_detalle` VALUES ('400', '163', '1.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('401', '163', '2.0000', '40.00', 'Carritos chocolate', '660002', NULL, '0.00', '0.00', '0', '660002');
INSERT INTO `ventas_detalle` VALUES ('402', '163', '1.0000', '140.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('403', '163', '1.0000', '580.00', 'Fanguito', '660026', NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('420', '180', '9.0000', '240.00', 'Cerveza star lager', '440002', NULL, '0.00', '0.00', '0', '440002');
INSERT INTO `ventas_detalle` VALUES ('421', '181', '1.0000', '240.00', 'Cerveza star lager', '440002', NULL, '0.00', '0.00', '0', '440002');
INSERT INTO `ventas_detalle` VALUES ('422', '182', '1.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('423', '183', '-1.0000', '40.00', 'Cafe en sobre (DEV)', '660101', NULL, '0.00', '0.00', '0', '660101');
INSERT INTO `ventas_detalle` VALUES ('425', '185', '-1.0000', '40.00', 'Cafe en sobre', '660101', NULL, '0.00', '0.00', '0', '660101');
INSERT INTO `ventas_detalle` VALUES ('427', '187', '1.0000', '240.00', 'Marranetas', '660027', NULL, '0.00', '0.00', '0', '660027');
INSERT INTO `ventas_detalle` VALUES ('428', '187', '7.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('429', '187', '2.0000', '30.00', 'chicle 30', '660035', NULL, '0.00', '0.00', '0', '660035');
INSERT INTO `ventas_detalle` VALUES ('430', '187', '1.0000', '40.00', 'Cafe en sobre', '660101', NULL, '0.00', '0.00', '0', '660101');
INSERT INTO `ventas_detalle` VALUES ('431', '187', '3.0000', '80.00', 'ojitos gummy gum', '660100', NULL, '0.00', '0.00', '0', '660100');
INSERT INTO `ventas_detalle` VALUES ('432', '187', '1.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('433', '188', '7.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('434', '188', '1.0000', '480.00', 'Hamburguesas pollo', '881108', NULL, '0.00', '0.00', '0', '881108');
INSERT INTO `ventas_detalle` VALUES ('435', '189', '3.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('436', '189', '2.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('437', '190', '1.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('438', '191', '5.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('439', '191', '1.0000', '150.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('440', '191', '9.0000', '140.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('441', '192', '8.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('442', '193', '1.0000', '520.00', 'Leche condensada', '660025', NULL, '0.00', '0.00', '0', '660025');
INSERT INTO `ventas_detalle` VALUES ('443', '194', '18.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('444', '195', '2.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('445', '195', '8.0000', '240.00', 'Cerveza star lager', '440002', NULL, '0.00', '0.00', '0', '440002');
INSERT INTO `ventas_detalle` VALUES ('446', '195', '3.0000', '15.00', 'Caramelos de 15', '660029', NULL, '0.00', '0.00', '0', '660029');
INSERT INTO `ventas_detalle` VALUES ('447', '195', '2.0000', '150.00', 'Galletas Rellenitas', '660009', NULL, '0.00', '0.00', '0', '660009');
INSERT INTO `ventas_detalle` VALUES ('448', '195', '2.0000', '30.00', 'Caldo de pollo sobrecito', '660088', NULL, '0.00', '0.00', '0', '660088');
INSERT INTO `ventas_detalle` VALUES ('449', '195', '2.0000', '80.00', 'ojitos gummy gum', '660100', NULL, '0.00', '0.00', '0', '660100');
INSERT INTO `ventas_detalle` VALUES ('450', '195', '1.0000', '150.00', 'jabon de bano', '660103', NULL, '0.00', '0.00', '0', '660103');
INSERT INTO `ventas_detalle` VALUES ('451', '195', '2.0000', '280.00', 'Espagetis 500g', '660006', NULL, '0.00', '0.00', '0', '660006');
INSERT INTO `ventas_detalle` VALUES ('452', '195', '5.0000', '40.00', 'Refresco en polvo', '660007', NULL, '0.00', '0.00', '0', '660007');
INSERT INTO `ventas_detalle` VALUES ('453', '195', '2.0000', '250.00', 'Refresco cola lata 300ml', '660021', NULL, '0.00', '0.00', '0', '660021');
INSERT INTO `ventas_detalle` VALUES ('454', '196', '2.0000', '500.00', 'Hamgurgesa 5u pqt', '660015', NULL, '0.00', '0.00', '0', '660015');
INSERT INTO `ventas_detalle` VALUES ('455', '196', '1.0000', '2000.00', 'minicake 2000', '440003', NULL, '0.00', '0.00', '0', '440003');
INSERT INTO `ventas_detalle` VALUES ('456', '196', '1.0000', '140.00', 'Donas Grandes', '440001', NULL, '0.00', '0.00', '0', '440001');
INSERT INTO `ventas_detalle` VALUES ('457', '196', '9.0000', '150.00', 'Croquetas pollo pqt', '660017', NULL, '0.00', '0.00', '0', '660017');
INSERT INTO `ventas_detalle` VALUES ('458', '196', '1.0000', '580.00', 'Fanguito', '660026', NULL, '0.00', '0.00', '0', '660026');
INSERT INTO `ventas_detalle` VALUES ('459', '196', '2.0000', '100.00', 'Tartaleta', '660012', NULL, '0.00', '0.00', '0', '660012');
INSERT INTO `ventas_detalle` VALUES ('460', '197', '1.0000', '70.00', 'Chupa chus grandes', '660001', NULL, '0.00', '0.00', '0', '660001');
INSERT INTO `ventas_detalle` VALUES ('461', '198', '2.0000', '150.00', 'Galletas Blackout azul', '660010', NULL, '0.00', '0.00', '0', '660010');
INSERT INTO `ventas_detalle` VALUES ('462', '198', '1.0000', '650.00', 'Arroz 1kg pqt', '660020', NULL, '0.00', '0.00', '0', '660020');
INSERT INTO `ventas_detalle` VALUES ('463', '198', '1.0000', '680.00', 'Azucar 1kg pqt', '660018', NULL, '0.00', '0.00', '0', '660018');

DROP TABLE IF EXISTS `ventas_pagos`;
CREATE TABLE `ventas_pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venta_cabecera` int(10) unsigned NOT NULL,
  `metodo_pago` varchar(50) NOT NULL,
  `monto` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_venta` (`id_venta_cabecera`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ventas_pagos` VALUES ('1', '1', 'Transferencia', '2280.00');
INSERT INTO `ventas_pagos` VALUES ('2', '2', 'Efectivo', '5010.00');
INSERT INTO `ventas_pagos` VALUES ('3', '3', 'Efectivo', '3160.00');
INSERT INTO `ventas_pagos` VALUES ('4', '4', 'Transferencia', '70.00');
INSERT INTO `ventas_pagos` VALUES ('5', '5', 'Efectivo', '4475.00');
INSERT INTO `ventas_pagos` VALUES ('6', '6', 'Devolución', '-600.00');
INSERT INTO `ventas_pagos` VALUES ('7', '7', 'Efectivo', '840.00');
INSERT INTO `ventas_pagos` VALUES ('8', '8', 'Efectivo', '800.00');
INSERT INTO `ventas_pagos` VALUES ('9', '9', 'Transferencia', '4090.00');
INSERT INTO `ventas_pagos` VALUES ('10', '10', 'Efectivo', '10225.00');
INSERT INTO `ventas_pagos` VALUES ('11', '11', 'Devolución', '-80.00');
INSERT INTO `ventas_pagos` VALUES ('12', '12', 'Efectivo', '4210.00');
INSERT INTO `ventas_pagos` VALUES ('13', '13', 'Efectivo', '1100.00');
INSERT INTO `ventas_pagos` VALUES ('14', '14', 'Transferencia', '1260.00');
INSERT INTO `ventas_pagos` VALUES ('15', '15', 'Efectivo', '4855.00');
INSERT INTO `ventas_pagos` VALUES ('16', '16', 'Transferencia', '1000.00');
INSERT INTO `ventas_pagos` VALUES ('17', '17', 'Efectivo', '2020.00');
INSERT INTO `ventas_pagos` VALUES ('18', '18', 'Efectivo', '3235.00');
INSERT INTO `ventas_pagos` VALUES ('19', '19', 'Efectivo', '400.00');
INSERT INTO `ventas_pagos` VALUES ('20', '20', 'Efectivo', '360.00');
INSERT INTO `ventas_pagos` VALUES ('21', '21', 'Transferencia', '650.00');
INSERT INTO `ventas_pagos` VALUES ('22', '22', 'Devolución', '-360.00');
INSERT INTO `ventas_pagos` VALUES ('23', '23', 'Devolución', '-650.00');
INSERT INTO `ventas_pagos` VALUES ('24', '24', 'Transferencia', '2030.00');
INSERT INTO `ventas_pagos` VALUES ('25', '25', 'Efectivo', '3850.00');
INSERT INTO `ventas_pagos` VALUES ('26', '26', 'Efectivo', '2980.00');
INSERT INTO `ventas_pagos` VALUES ('27', '27', 'Efectivo', '4080.00');
INSERT INTO `ventas_pagos` VALUES ('28', '28', 'Transferencia', '1830.00');
INSERT INTO `ventas_pagos` VALUES ('29', '29', 'Transferencia', '4400.00');
INSERT INTO `ventas_pagos` VALUES ('30', '30', 'Transferencia', '240.00');
INSERT INTO `ventas_pagos` VALUES ('31', '31', 'Efectivo', '3550.00');
INSERT INTO `ventas_pagos` VALUES ('32', '32', 'Efectivo', '3230.00');
INSERT INTO `ventas_pagos` VALUES ('33', '33', 'Efectivo', '4440.00');
INSERT INTO `ventas_pagos` VALUES ('34', '34', 'Efectivo', '15.00');
INSERT INTO `ventas_pagos` VALUES ('35', '35', 'Transferencia', '2800.00');
INSERT INTO `ventas_pagos` VALUES ('36', '36', 'Transferencia', '400.00');
INSERT INTO `ventas_pagos` VALUES ('37', '37', 'Efectivo', '12250.00');
INSERT INTO `ventas_pagos` VALUES ('38', '38', 'Efectivo', '320.00');
INSERT INTO `ventas_pagos` VALUES ('39', '39', 'Efectivo', '3340.00');
INSERT INTO `ventas_pagos` VALUES ('40', '40', 'Efectivo', '7840.00');
INSERT INTO `ventas_pagos` VALUES ('41', '41', 'Efectivo', '5440.00');
INSERT INTO `ventas_pagos` VALUES ('42', '42', 'Efectivo', '2180.00');
INSERT INTO `ventas_pagos` VALUES ('43', '43', 'Efectivo', '1660.00');
INSERT INTO `ventas_pagos` VALUES ('44', '44', 'Efectivo', '140.00');
INSERT INTO `ventas_pagos` VALUES ('45', '70', 'Efectivo', '80.00');
INSERT INTO `ventas_pagos` VALUES ('46', '71', 'Efectivo', '560.00');
INSERT INTO `ventas_pagos` VALUES ('47', '72', 'Efectivo', '3520.00');
INSERT INTO `ventas_pagos` VALUES ('48', '73', 'Efectivo', '1920.00');
INSERT INTO `ventas_pagos` VALUES ('49', '78', 'Devolución', '-80.00');
INSERT INTO `ventas_pagos` VALUES ('50', '79', 'Devolución', '-560.00');
INSERT INTO `ventas_pagos` VALUES ('51', '86', 'Efectivo', '3600.00');
INSERT INTO `ventas_pagos` VALUES ('52', '87', 'Efectivo', '1040.00');
INSERT INTO `ventas_pagos` VALUES ('53', '88', 'Efectivo', '890.00');
INSERT INTO `ventas_pagos` VALUES ('54', '89', 'Efectivo', '2670.00');
INSERT INTO `ventas_pagos` VALUES ('55', '90', 'Efectivo', '1700.00');
INSERT INTO `ventas_pagos` VALUES ('56', '91', 'Efectivo', '1300.00');
INSERT INTO `ventas_pagos` VALUES ('57', '92', 'Efectivo', '60.00');
INSERT INTO `ventas_pagos` VALUES ('58', '93', 'Transferencia', '80.00');
INSERT INTO `ventas_pagos` VALUES ('59', '94', 'Efectivo', '600.00');
INSERT INTO `ventas_pagos` VALUES ('60', '95', 'Efectivo', '240.00');
INSERT INTO `ventas_pagos` VALUES ('61', '96', 'Transferencia', '80.00');
INSERT INTO `ventas_pagos` VALUES ('62', '97', 'Efectivo', '350.00');
INSERT INTO `ventas_pagos` VALUES ('63', '98', 'Efectivo', '280.00');
INSERT INTO `ventas_pagos` VALUES ('64', '99', 'Efectivo', '180.00');
INSERT INTO `ventas_pagos` VALUES ('65', '100', 'Transferencia', '1000.00');
INSERT INTO `ventas_pagos` VALUES ('66', '101', 'Efectivo', '240.00');
INSERT INTO `ventas_pagos` VALUES ('67', '102', 'Efectivo', '2600.00');
INSERT INTO `ventas_pagos` VALUES ('68', '103', 'Efectivo', '1970.00');
INSERT INTO `ventas_pagos` VALUES ('69', '104', 'Efectivo', '30.00');
INSERT INTO `ventas_pagos` VALUES ('70', '105', 'Efectivo', '1200.00');
INSERT INTO `ventas_pagos` VALUES ('71', '106', 'Transferencia', '30.00');
INSERT INTO `ventas_pagos` VALUES ('72', '107', 'Efectivo', '790.00');
INSERT INTO `ventas_pagos` VALUES ('73', '108', 'Efectivo', '1040.00');
INSERT INTO `ventas_pagos` VALUES ('74', '109', 'Transferencia', '6590.00');
INSERT INTO `ventas_pagos` VALUES ('75', '110', 'Transferencia', '1470.00');
INSERT INTO `ventas_pagos` VALUES ('76', '111', 'Transferencia', '680.00');
INSERT INTO `ventas_pagos` VALUES ('77', '112', 'Efectivo', '270.00');
INSERT INTO `ventas_pagos` VALUES ('78', '113', 'Efectivo', '740.00');
INSERT INTO `ventas_pagos` VALUES ('79', '114', 'Efectivo', '960.00');
INSERT INTO `ventas_pagos` VALUES ('80', '115', 'Efectivo', '60.00');
INSERT INTO `ventas_pagos` VALUES ('81', '116', 'Efectivo', '1680.00');
INSERT INTO `ventas_pagos` VALUES ('82', '117', 'Efectivo', '70.00');
INSERT INTO `ventas_pagos` VALUES ('83', '118', 'Efectivo', '600.00');
INSERT INTO `ventas_pagos` VALUES ('84', '119', 'Efectivo', '2610.00');
INSERT INTO `ventas_pagos` VALUES ('85', '120', 'Devolución', '-750.00');
INSERT INTO `ventas_pagos` VALUES ('86', '121', 'Efectivo', '600.00');
INSERT INTO `ventas_pagos` VALUES ('87', '122', 'Efectivo', '300.00');
INSERT INTO `ventas_pagos` VALUES ('88', '123', 'Transferencia', '4560.00');
INSERT INTO `ventas_pagos` VALUES ('89', '124', 'Transferencia', '160.00');
INSERT INTO `ventas_pagos` VALUES ('90', '125', 'Transferencia', '280.00');
INSERT INTO `ventas_pagos` VALUES ('91', '126', 'Efectivo', '360.00');
INSERT INTO `ventas_pagos` VALUES ('92', '127', 'Efectivo', '560.00');
INSERT INTO `ventas_pagos` VALUES ('93', '128', 'Efectivo', '9070.00');
INSERT INTO `ventas_pagos` VALUES ('94', '129', 'Efectivo', '650.00');
INSERT INTO `ventas_pagos` VALUES ('95', '130', 'Efectivo', '2470.00');
INSERT INTO `ventas_pagos` VALUES ('96', '131', 'Efectivo', '2550.00');
INSERT INTO `ventas_pagos` VALUES ('97', '132', 'Efectivo', '160.00');
INSERT INTO `ventas_pagos` VALUES ('98', '133', 'Efectivo', '1220.00');
INSERT INTO `ventas_pagos` VALUES ('99', '134', 'Efectivo', '1890.00');
INSERT INTO `ventas_pagos` VALUES ('100', '135', 'Efectivo', '850.00');
INSERT INTO `ventas_pagos` VALUES ('101', '136', 'Efectivo', '5680.00');
INSERT INTO `ventas_pagos` VALUES ('102', '137', 'Efectivo', '1440.00');
INSERT INTO `ventas_pagos` VALUES ('103', '138', 'Efectivo', '300.00');
INSERT INTO `ventas_pagos` VALUES ('104', '139', 'Transferencia', '150.00');
INSERT INTO `ventas_pagos` VALUES ('128', '140', 'Efectivo', '100.00');
INSERT INTO `ventas_pagos` VALUES ('129', '140', 'Transferencia', '50.00');
INSERT INTO `ventas_pagos` VALUES ('130', '183', 'Efectivo', '40.00');
INSERT INTO `ventas_pagos` VALUES ('131', '185', 'Efectivo', '40.00');
INSERT INTO `ventas_pagos` VALUES ('132', '187', 'Efectivo', '835.00');
INSERT INTO `ventas_pagos` VALUES ('133', '188', 'Efectivo', '760.00');
INSERT INTO `ventas_pagos` VALUES ('134', '189', 'Transferencia', '1050.00');
INSERT INTO `ventas_pagos` VALUES ('135', '190', 'Transferencia', '250.00');
INSERT INTO `ventas_pagos` VALUES ('136', '191', 'Efectivo', '2660.00');
INSERT INTO `ventas_pagos` VALUES ('137', '192', 'Efectivo', '190.00');
INSERT INTO `ventas_pagos` VALUES ('138', '192', 'Transferencia', '1010.00');
INSERT INTO `ventas_pagos` VALUES ('139', '193', 'Efectivo', '520.00');
INSERT INTO `ventas_pagos` VALUES ('140', '194', 'Efectivo', '1800.00');
INSERT INTO `ventas_pagos` VALUES ('141', '195', 'Efectivo', '1735.00');
INSERT INTO `ventas_pagos` VALUES ('142', '195', 'Transferencia', '2300.00');
INSERT INTO `ventas_pagos` VALUES ('143', '196', 'Efectivo', '5270.00');
INSERT INTO `ventas_pagos` VALUES ('144', '197', 'Efectivo', '70.00');
INSERT INTO `ventas_pagos` VALUES ('145', '198', 'Efectivo', '1630.00');

DROP TABLE IF EXISTS `vistas_productos`;
CREATE TABLE `vistas_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(50) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `vistas_productos` VALUES ('1', '660021', '152.206.234.128', '2026-02-13 21:27:34');
INSERT INTO `vistas_productos` VALUES ('2', '660021', '152.206.234.128', '2026-02-13 21:27:39');
INSERT INTO `vistas_productos` VALUES ('3', '660101', '152.206.234.128', '2026-02-13 21:27:46');
INSERT INTO `vistas_productos` VALUES ('4', '660026', '152.206.234.128', '2026-02-13 21:27:53');
INSERT INTO `vistas_productos` VALUES ('5', '660023', '152.206.210.128', '2026-02-13 21:31:36');
INSERT INTO `vistas_productos` VALUES ('6', '660023', '152.206.210.128', '2026-02-13 21:31:40');
INSERT INTO `vistas_productos` VALUES ('7', '660038', '152.206.210.128', '2026-02-13 21:31:52');
INSERT INTO `vistas_productos` VALUES ('8', '660015', '129.222.0.124', '2026-02-13 21:35:30');
INSERT INTO `vistas_productos` VALUES ('9', '660025', '129.222.0.124', '2026-02-13 21:37:52');

DROP TABLE IF EXISTS `web_stats`;
CREATE TABLE `web_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` timestamp NULL DEFAULT current_timestamp(),
  `ip` varchar(45) DEFAULT NULL,
  `pagina` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `producto_codigo` varchar(50) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `cliente_id` (`cliente_id`,`producto_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `wishlist` VALUES ('1', '2', '660096', '2026-02-13 21:49:28');
INSERT INTO `wishlist` VALUES ('2', '2', '881101', '2026-02-13 21:49:32');
INSERT INTO `wishlist` VALUES ('3', '2', '881106', '2026-02-13 21:49:33');
INSERT INTO `wishlist` VALUES ('4', '2', '660043', '2026-02-13 21:49:34');
INSERT INTO `wishlist` VALUES ('5', '2', '660021', '2026-02-13 21:49:54');

SET FOREIGN_KEY_CHECKS=1;
